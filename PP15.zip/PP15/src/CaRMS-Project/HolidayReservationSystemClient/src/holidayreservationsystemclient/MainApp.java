/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidayreservationsystemclient;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import ws.client.partnerreservation.CarCategory;
import ws.client.partnerreservation.CarCategoryNotFoundException_Exception;
import ws.client.partnerreservation.CarModel;
import ws.client.partnerreservation.CarModelNotFoundException_Exception;
import ws.client.partnerreservation.CustomerNotFoundException_Exception;
import ws.client.partnerreservation.InputDataValidationException_Exception;
import ws.client.partnerreservation.InvalidLoginCredentialException_Exception;
import ws.client.partnerreservation.NoAvailableRentalRateException_Exception;
import ws.client.partnerreservation.Outlet;
import ws.client.partnerreservation.OutletNotFoundException_Exception;
import ws.client.partnerreservation.Partner;
import ws.client.partnerreservation.PartnerCustomer;
import ws.client.partnerreservation.PartnerNotFoundException_Exception;
import ws.client.partnerreservation.PartnerReservationWebService;
import ws.client.partnerreservation.PartnerReservationWebService_Service;
import ws.client.partnerreservation.RentalRate;
import ws.client.partnerreservation.RentalRateNotFoundException_Exception;
import ws.client.partnerreservation.RentalReservation;
import ws.client.partnerreservation.RentalReservationNotFoundException_Exception;
import ws.client.partnerreservation.UnknownPersistenceException_Exception;

/**
 *
 * @author aaronf
 */
//added comment to commit
class MainApp {

    private ws.client.partnerreservation.Partner currentPartner;
    private ws.client.partnerreservation.PartnerCustomer partnerCustomer;

    void runApp() {
        PartnerReservationWebService_Service pwss = new PartnerReservationWebService_Service();
        PartnerReservationWebService port = pwss.getPartnerReservationWebServicePort();
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("\n*** Welcome to Holiday Reservation System ***\n");
            System.out.println("1: Login");
            System.out.println("2: Search Car");
            System.out.println("3: Exit\n");

            response = 0;

            OUTER:
            while (response < 1 || response > 3) {
                System.out.print("> ");
                response = scanner.nextInt();
                switch (response) {
                    case 1:
                        doPartnerLogin(port);
                        System.out.println("\nLogin successful\n");
                        menuMain(port);

                    case 2:
                        doSearchCar(port);
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Invalid option, please try again\n");
                        break;
                }
            }
            if (response == 3) {
                break;
            }
        }
    }

    //throw the Exception class
    private void doPartnerLogin(PartnerReservationWebService port) {
        Scanner scanner = new Scanner(System.in);
        String username = "";
        String password = "";

        System.out.println("*** Holiday Reservation System :: Login ***\n");
        System.out.print("Enter username> ");
        username = scanner.nextLine().trim();
        System.out.print("Enter password> ");
        password = scanner.nextLine().trim();
        try {
            if (username.length() > 0 && password.length() > 0) {
                port.partnerLogin(username, password);
            } else {
                System.out.println("Username or password was not entered!");
            }
        } catch (InvalidLoginCredentialException_Exception ex) {
            System.out.println("Missing Login Credential!");
        } catch (PartnerNotFoundException_Exception ex) {
            System.out.println("Partner Not Found!");
        }

    }

    private void doSearchCar(PartnerReservationWebService port) {

        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Long carCategoryId = new Long(-1);
        Long carModelId = new Long(-1);
        Date pickUpDateTime;
        Date returnDateTime;
        Long pickUpOutletId;
        Long returnOutletId;

        System.out.println("\n*** Holiday Reservation System :: Search Car ***\n");
        Boolean canReserve = false;

        try {
            System.out.print("Enter Pickup Date & Time (DD/MM/YYYY HH:MM)> ");
            pickUpDateTime = inputDateFormat.parse(scanner.nextLine().trim());

            System.out.print("Enter Return Date & Time (DD/MM/YYYY HH:MM)> ");
            returnDateTime = inputDateFormat.parse(scanner.nextLine().trim());

            if (returnDateTime.before(pickUpDateTime)) {
                throw new ReturnDateBeforePickupDateException();
            }

            List<Outlet> outlets = port.retrieveAllOutlets();
            System.out.printf("%4s%64s%20s%20s\n", "ID", "Outlet Name", "Opening Hour", "Closing Hour");

            SimpleDateFormat operatingHours = new SimpleDateFormat("HH:mm");

            for (Outlet outlet : outlets) {
                String openingHours = "";
                String closingHours = "";

                if (outlet.getOpeningHours() != null) {
                    openingHours = operatingHours.format(outlet.getOpeningHours());
                }

                if (outlet.getClosingHours() != null) {
                    closingHours = operatingHours.format(outlet.getClosingHours());
                }
                System.out.printf("%4s%64s%20s%20s\n", outlet.getOutletId(), outlet.getOutletName(),
                        openingHours, closingHours);
            }

            System.out.print("Enter Pickup Outlet ID> ");
            pickUpOutletId = scanner.nextLong();
            System.out.print("Enter Return Outlet ID> ");
            returnOutletId = scanner.nextLong();

            Outlet pickUpOutlet = port.retrieveOutletByOutletId(pickUpOutletId);
            LocalDateTime pickUpDateTimeConverted = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
            LocalDateTime returnDateTimeConverted = LocalDateTime.ofInstant(returnDateTime.toInstant(), ZoneId.systemDefault());

            if (pickUpOutlet.getOpeningHours() != null && pickUpOutlet.getClosingHours() != null) {
                //need to ask aaron
//                LocalDateTime openingHoursConverted = LocalDateTime.ofInstant(pickUpOutlet.getOpeningHours().toInstant(), ZoneId.systemDefault());
//                LocalDateTime closingHoursConverted = LocalDateTime.ofInstant(pickUpOutlet.getClosingHours().toInstant(), ZoneId.systemDefault());
//
//                if ((pickUpDateTimeConverted.getHour() < openingHoursConverted.getHour())
//                        || (pickUpDateTimeConverted.getHour() == openingHoursConverted.getHour()
//                        && pickUpDateTimeConverted.getMinute() < openingHoursConverted.getMinute())) {
//                    throw new OutsideOperatingHoursException("Pickup time is before opening hours of the pickup outlet. Please try again!\n");
//                } else if ((pickUpDateTimeConverted.getHour() > closingHoursConverted.getHour())
//                        || (pickUpDateTimeConverted.getHour() == closingHoursConverted.getHour()
//                        && pickUpDateTimeConverted.getMinute() > closingHoursConverted.getMinute())) {
//                    throw new OutsideOperatingHoursException("Pickup time is after closing hours of the pickup outlet. Please try again!\n");
//                }
            }

            Outlet returnOutlet = port.retrieveOutletByOutletId(returnOutletId);

            if (returnOutlet.getOpeningHours() != null && returnOutlet.getClosingHours() != null) {
                //ask aaron
//                LocalDateTime openingHoursConverted = LocalDateTime.ofInstant(returnOutlet.getOpeningHours().toInstant(), ZoneId.systemDefault());
//                LocalDateTime closingHoursConverted = LocalDateTime.ofInstant(returnOutlet.getClosingHours().toInstant(), ZoneId.systemDefault());
//
//                if ((returnDateTimeConverted.getHour() < openingHoursConverted.getHour())
//                        || (returnDateTimeConverted.getHour() == openingHoursConverted.getHour()
//                        && returnDateTimeConverted.getMinute() < openingHoursConverted.getMinute())) {
//                    throw new OutsideOperatingHoursException("Return time is before opening hours of the return outlet. Please try again!\n");
//                } else if ((returnDateTimeConverted.getHour() > closingHoursConverted.getHour())
//                        || (returnDateTimeConverted.getHour() == closingHoursConverted.getHour()
//                        && returnDateTimeConverted.getMinute() > closingHoursConverted.getMinute())) {
//                    throw new OutsideOperatingHoursException("Return time is after closing hours of the return outlet. Please try again!\n");
//                }
            }

            while (true) {
                System.out.println("\n*** Search by Car Category or Car Model? ***\n");
                System.out.println("1: Search by Car Category");
                System.out.println("2: Search by Car Model");
                System.out.println("3: Back\n");
                response = 0;
                while (response < 1 || response > 3) {
                    System.out.print("> ");
                    response = scanner.nextInt();

                    if (response == 1) {
                        List<CarCategory> carCategories = port.retrieveAllCarCategories();
                        System.out.printf("%4s%64s\n", "ID", "Car Category Name");

                        for (CarCategory carCategory : carCategories) {
                            System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
                        }
                        System.out.print("Choose Car Category ID> ");
                        carCategoryId = scanner.nextLong();
                        canReserve = port.partnerSearchCarCategory(carCategoryId, convertDate(pickUpDateTime), convertDate(returnDateTime), pickUpOutletId, returnOutletId);
                        break;
                    } else if (response == 2) {
                        List<CarModel> carModels = port.retrieveAllCarModels();
                        System.out.printf("%4s%64s%32s%32s\n", "ID", "Car Category Name", "Make", "Model");
                        for (CarModel carModel : carModels) {
                            System.out.printf("%4s%64s%32s%32s\n", carModel.getCarModelId(), carModel.getCarCategory().getCarCategoryName(), carModel.getMakeName(), carModel.getModelName());
                        }
                        System.out.print("Enter Car Model ID> ");
                        carModelId = scanner.nextLong();
                        CarModel carModel = port.retrieveCarModelByCarModelId(carModelId);
                        carCategoryId = carModel.getCarCategory().getCarCategoryId();
                        //converted the date from date to XML 
                        canReserve = port.partnerSearchCarModel(carModelId, convertDate(pickUpDateTime), convertDate(returnDateTime), pickUpOutletId, returnOutletId);
                        break;
                    } else if (response == 3) {
                        break;
                    } else {
                        System.out.println("\nInvalid option, please try again\n");
                    }
                }
                if (response == 3) {
                    break;
                }

                scanner.nextLine();
                Boolean isCarCategory = false;

                if (response == 1) {
                    isCarCategory = true;
                } else {
                    isCarCategory = false;
                }

                if (!canReserve) {
                    System.out.println("\nNo cars are available tentatively!");
                } else {
                    BigDecimal totalRentalFee = port.calculateTotalRentalPrice(carCategoryId, convertDate(pickUpDateTime), convertDate(returnDateTime));
                    List<RentalRate> rentalRatesUsed = port.retrieveRentalRatesUsed(carCategoryId, convertDate(pickUpDateTime), convertDate(returnDateTime));
                    System.out.println("\nThere are cars available! Total rental fee is SGD" + totalRentalFee + ". ");
                    if (currentPartner != null) {
                        System.out.print("Would you like to reserve a car? (Enter 'Y' to reserve a car)> ");
                        String input = scanner.nextLine().trim();

                        if (input.equals("Y") && isCarCategory) {
                            //not sure how to catch and throw
                            doReserveCarUsingCarCategory(port, currentPartner.getPartnerId(), carCategoryId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId, totalRentalFee, rentalRatesUsed);
                            break;
                        } else if (input.equals("Y") && !isCarCategory) {
                            //not sure how to catch and throw
                            doReserveCarUsingCarModel(port, carModelId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId, totalRentalFee, rentalRatesUsed);
                            break;
                        } else {
                            break;
                        }
                    } else {
                        System.out.println("\nPlease login to reserve the car! Would you like to login?\n");
                        System.out.print("Would you like to login? (Enter 'Y' to go to login page)> ");
                        String input = scanner.nextLine().trim();
                        if (input.equals("Y")) {
                            break;
                        } else {
                            break;
                        }
                    }
                }
            }
        } catch (ParseException ex) {
            System.out.println("\nInvalid date input!\n");
        } catch (NoAvailableRentalRateException_Exception ex) {
            System.out.println("\nThere are no available rental rates for the period!\n");
        } catch (CarCategoryNotFoundException_Exception ex) {
            System.out.println("\nCar Category not found for ID: " + carCategoryId + "\n");
        } catch (CarModelNotFoundException_Exception ex) {
            System.out.println("\nCar Model not found for ID: " + carModelId + "\n");
        } catch (OutletNotFoundException_Exception ex) {
            System.out.println("\nOutlet not found!");
//        } catch (OutsideOperatingHoursException ex) {
//            System.out.println("\n" + ex.getMessage());
        } catch (ReturnDateBeforePickupDateException ex) {
            System.out.println("\nReturn date entered is before pick up date!");
        } catch (DatatypeConfigurationException ex) {
            System.out.println(ex.getMessage());
        }

    }

    private void doReserveCarUsingCarCategory(PartnerReservationWebService port,
            Long partnerId, Long carCategoryId, Date pickUpDateTime, Date returnDateTime,
            Long pickupOutletId, Long returnOutletId, BigDecimal totalRentalFee, List<RentalRate> rentalRatesUsed) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation newRentalReservation = new RentalReservation();
        System.out.println("\n*** CaRMS Reservation Client :: Reserve Car Using Car Category ***\n");
        //need to resolve the Data error
        try {
            XMLGregorianCalendar xmlpickUpDateTime = convertDate(pickUpDateTime);
            XMLGregorianCalendar xmlreturnDateTime = convertDate(returnDateTime);
            newRentalReservation.setStartDate(xmlpickUpDateTime);
            newRentalReservation.setEndDate(xmlreturnDateTime);

        } catch (DatatypeConfigurationException ex) {
            System.out.println(ex.getMessage());
        }
        newRentalReservation.setRentalPrice(totalRentalFee);
        //need to pull before this is resolved
        newRentalReservation.setRentalRates(rentalRatesUsed);

        System.out.print("Enter Customer's First Name > ");
        partnerCustomer.setFirstName(scanner.nextLine().trim());
        System.out.print("Enter Customer's Last Name > ");
        partnerCustomer.setLastName(scanner.nextLine().trim());
        System.out.print("Enter Customer's Email > ");
        partnerCustomer.setEmail(scanner.nextLine().trim());

        newRentalReservation.setCustomer(partnerCustomer);
        System.out.print("Enter Credit Card Number> ");
        String creditCardNumber = scanner.nextLine().trim();
        newRentalReservation.setCreditCardNumber(creditCardNumber);
        System.out.print("Would you like to pay now? (Enter 'Y' to pay now)> ");
        String input = scanner.nextLine().trim();
        if (input.equals("Y")) {
            newRentalReservation.setIsPaid(true);
        } else {
            newRentalReservation.setIsPaid(false);
        }
        try {
            Long rentalReservationId = port.partnerCreateNewRentalReservationUsingCarCategory(newRentalReservation, partnerId, partnerCustomer.getCustomerId(), carCategoryId, pickupOutletId, returnOutletId, rentalRatesUsed);
            //again need to pull first
            if (newRentalReservation.isIsPaid()) {
                System.out.println("\nCharged " + totalRentalFee.toString() + " to credit card: " + creditCardNumber);
            } else {
                System.out.println("\nPlease pay " + totalRentalFee.toString() + " when picking up the car");
            }
            System.out.println("\nRental reservation created with ID: " + rentalReservationId);
        } catch (CarCategoryNotFoundException_Exception ex) {
            System.out.println("\nCar Category not found for ID: " + carCategoryId + "\n");
        } catch (OutletNotFoundException_Exception ex) {
            System.out.println("\nOutlet not found!\n");

        } catch (CustomerNotFoundException_Exception
                | InputDataValidationException_Exception
                | InvalidLoginCredentialException_Exception
                | PartnerNotFoundException_Exception
                | RentalRateNotFoundException_Exception
                | UnknownPersistenceException_Exception ex) {
            System.out.println("\n" + ex.getMessage());
        }
    }

    private void menuMain(PartnerReservationWebService port) {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("\n*** Holiday Reservation System ***\n");
            System.out.println("You are login as " + partnerCustomer.getFirstName() + " " + partnerCustomer.getLastName() + "\n");
            System.out.println("1: Search Car");
            System.out.println("2: View Reservation Details");
            System.out.println("3: View All My Reservations");
            System.out.println("4: Logout\n");
            response = 0;

            OUTER:
            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();
                switch (response) {
                    case 1:
                        doSearchCar(port);
                        break;
                    case 2:
                        doViewReservationDetails(port);
                        break;
                    case 3:
                        doViewAllReservations(port);
                        break;
                    case 4:
                        break OUTER;
                    default:
                        System.out.println("\nInvalid option, please try again!\n");
                        break;
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private XMLGregorianCalendar convertDate(Date date) throws DatatypeConfigurationException {
        GregorianCalendar gc = new GregorianCalendar();
        // giving current date and time to gc
        gc.setTime(date);
        XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
        return xmlDate;
    }

    private void doReserveCarUsingCarModel(PartnerReservationWebService port, Long carModelId, Date pickUpDateTime, Date returnDateTime,
            Long pickUpOutletId, Long returnOutletId, BigDecimal totalRentalFee, List<RentalRate> rentalRatesUsed) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation newRentalReservation = new RentalReservation();
        System.out.println("\n*** Holiday Reservation System :: Reserve Car Using Car Model ***\n");
        //need to resolve the Data error
        try {
            XMLGregorianCalendar xmlpickUpDateTime = convertDate(pickUpDateTime);
            XMLGregorianCalendar xmlreturnDateTime = convertDate(returnDateTime);
            newRentalReservation.setStartDate(xmlpickUpDateTime);
            newRentalReservation.setEndDate(xmlreturnDateTime);

        } catch (DatatypeConfigurationException ex) {
            System.out.println(ex.getMessage());
        }

        newRentalReservation.setRentalPrice(totalRentalFee);
        //aaron: not sure how to resolve this error

        newRentalReservation.setRentalRates(rentalRatesUsed);

        System.out.print("Enter Customer's First Name > ");
        partnerCustomer.setFirstName(scanner.nextLine().trim());
        System.out.print("Enter Customer's Last Name > ");
        partnerCustomer.setLastName(scanner.nextLine().trim());
        System.out.print("Enter Customer's Email > ");
        partnerCustomer.setEmail(scanner.nextLine().trim());

        System.out.print("Enter Credit Card Number> ");
        String creditCardNumber = scanner.nextLine().trim();
        newRentalReservation.setCreditCardNumber(creditCardNumber);
        System.out.print("Would you like to pay now? (Enter 'Y' to pay now)> ");
        String input = scanner.nextLine().trim();
        if (input.equals("Y")) {
            newRentalReservation.setIsPaid(true);
            System.out.println("\nCharged " + totalRentalFee.toString() + " to credit card: " + creditCardNumber);
        } else {
            newRentalReservation.setIsPaid(false);
            System.out.println("\nPlease pay " + totalRentalFee.toString() + " when picking up the car.");
        }

        try {
            Long rentalReservationId = port.partnerCreateNewRentalReservationUsingCarModel(newRentalReservation,
                    partnerCustomer.getCustomerId(), carModelId, pickUpOutletId, returnOutletId, rentalRatesUsed);
            System.out.println("\nRental reservation created with ID: " + rentalReservationId);
        } catch (InvalidLoginCredentialException_Exception ex) {
            System.out.println("Invalid Credentials !");
        } catch (CarModelNotFoundException_Exception ex) {
            System.out.println("\nCar Model not found for ID: " + carModelId + "\n");
        } catch (OutletNotFoundException_Exception ex) {
            System.out.println("\nOutlet not found!\n");
        } catch (PartnerNotFoundException_Exception ex) {
            System.out.println("Partner Not Found !");
        } catch (CustomerNotFoundException_Exception | RentalRateNotFoundException_Exception
                | InputDataValidationException_Exception | UnknownPersistenceException_Exception ex) {
            System.out.println("\n" + ex.getMessage());
        }

    }

    private void doViewReservationDetails(PartnerReservationWebService port) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** Holiday Reservation System :: View Reservation Details ***\n");
        List<RentalReservation> rentalReservations = port.retrievePartnerRentalReservations(currentPartner.getPartnerId());
        System.out.printf("%4s%20s%20s%16s%16s\n", "ID", "Start Date", "End Date", "Pick Up Outlet", "Return Outlet");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (RentalReservation rentalReservation : rentalReservations) {
            System.out.printf("%4s%20s%20s%16s%16s\n", rentalReservation.getRentalReservationId(),
                    sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()),
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName());
        }
        System.out.print("Enter Reservation ID> ");
        Long rentalReservationId = scanner.nextLong();
        scanner.nextLine();

        try {
            RentalReservation rentalReservation = port.retrievePartnerRentalReservationsById(rentalReservationId);
            System.out.printf("%4s%20s%20s%20s%12s%12s%32s%32s%16s%16s\n",
                    "ID", "Start Date",
                    "End Date", "Rental Fee",
                    "Paid?", "Cancelled?",
                    "Car Category", "Car Make and Model", "Pick Up Outlet", "Return Outlet");
            String makeAndModelName = "";
            if (rentalReservation.getCarModel() != null) {
                makeAndModelName = rentalReservation.getCarModel().getMakeName() + " " + rentalReservation.getCarModel().getModelName();
            }
            System.out.printf("%4s%20s%20s%20s%12s%12s%32s%32s%16s%16s\n",
                    rentalReservation.getRentalReservationId(), sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()), rentalReservation.getRentalPrice().toString(),
                    rentalReservation.isIsPaid().toString(), rentalReservation.isIsCancelled().toString(),
                    rentalReservation.getCarCategory().getCarCategoryName(), makeAndModelName,
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName());
            if (rentalReservation.isIsCancelled() || (rentalReservation.isIsPickedUp() && !rentalReservation.isIsCompleted()) || rentalReservation.isIsCompleted()) {
                System.out.print("Press any key to continue...> ");
            } else {
                System.out.print("Would you like to cancel the reservation? (Enter 'Y' to enter cancel the reservation)> ");
                String input = scanner.nextLine().trim();
                if (input.equals("Y")) {
                    doCancelReservation(port, rentalReservationId);
                } else {
                    System.out.print("Press any key to continue...> ");
                }
            }
        } catch (RentalReservationNotFoundException_Exception ex) {
            System.out.println("\nRental Reservation not found for ID " + rentalReservationId);
        }
    }

    private void doViewAllReservations(PartnerReservationWebService port) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** Holiday Reservation System :: View All Reservations ***\n");
        List<RentalReservation> rentalReservations = port.retrievePartnerRentalReservations(partnerCustomer.getCustomerId());
        System.out.printf("%4s%20s%20s%32s%32s%8s%16s%16s\n", "ID", "Start Date", "End Date", "Pick Up Outlet", "Return Outlet", "Paid?", "Cancelled?", "Completed?");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (RentalReservation rentalReservation : rentalReservations) {
            System.out.printf("%4s%20s%20s%32s%32s%8s%16s%16s\n", rentalReservation.getRentalReservationId(),
                    sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()),
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName(),
                    rentalReservation.isIsPaid().toString(),
                    rentalReservation.isIsCancelled().toString(),
                    rentalReservation.isIsCompleted().toString());
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doCancelReservation(PartnerReservationWebService port, Long rentalReservationId) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation rentalReservation;

        System.out.println("\n*** Holiday Reservation System :: Cancel Reservation ***\n");
        try {
            BigDecimal penalty = port.cancelReservation(rentalReservationId);
            rentalReservation = port.retrievePartnerRentalReservationsById(rentalReservationId);

            System.out.println("\nReservation successfully cancelled!");

            if (rentalReservation.isIsPaid()) {
                System.out.println("\nYou have been refunded SGD $"
                        + rentalReservation.getRentalPrice().subtract(penalty) + " to your card "
                        + rentalReservation.getCreditCardNumber()
                        + " after deducting cancellation penalty of SGD" + penalty + ".");
            } else {
                System.out.println("\nYour card : " + rentalReservation.getCreditCardNumber() + " has been charged SGD $" + penalty + " as a cancellation penalty.");
            }

        } catch (RentalReservationNotFoundException_Exception ex) {
            System.out.println("Rental Reservation not found for ID " + rentalReservationId);
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void showInputDataValidationErrorsForRentalReservation(Set<ConstraintViolation<RentalReservation>> constraintViolations) {
        System.out.println("\nInput data validation error!:");

        for (ConstraintViolation constraintViolation : constraintViolations) {
            System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage());
        }

        System.out.println("\nPlease try again......\n");
    }

    private class OutsideOperatingHoursException extends Exception {

        public OutsideOperatingHoursException(String message) {
        }
    }

    private class ReturnDateBeforePickupDateException extends Exception {

        public ReturnDateBeforePickupDateException() {
        }
    }
}
