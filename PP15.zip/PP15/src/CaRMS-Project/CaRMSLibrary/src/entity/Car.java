/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import util.enumeration.CarStatusEnum;

/**
 *
 * @author aaronf
 */
@Entity
public class Car implements Serializable {

    /*
    Attributes
    */
    
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long carId;
    
    @Column(nullable = false, length = 8, unique = true)
    @NotNull
    @Size(min = 7, max = 8) // Singapore license plate
    private String licensePlate;
    
    @Column(nullable = false, length = 32)
    @NotNull
    @Size(max = 32)
    private String colour;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @NotNull
    private CarStatusEnum carStatus;
    
    @Column(nullable = false)
    @NotNull
    private Boolean isEnabled;
    
    @ManyToOne(optional = false) // Mandatory to have car model
    @JoinColumn(nullable = false) // Mandatory to have car model
    private CarModel carModel;
    
    @ManyToOne // Not mandatory to have outlet
    private Outlet outlet;
    
    @OneToOne // Not mandatory to have rental reservation
    @JoinColumn // Owning side with reference to rentalReservation's primary key
    private RentalReservation rentalReservation;

    
    
    /*
    Constructors
    */
    
    public Car() {
        this.carStatus = CarStatusEnum.AVAILABLE;
        this.isEnabled = true;
    }

    public Car(String licensePlate, String colour) {
        this();
        
        this.licensePlate = licensePlate;
        this.colour = colour;
    }

    public Car(String licensePlate, String colour, CarStatusEnum carStatus) {
        this();
        
        this.licensePlate = licensePlate;
        this.colour = colour;
        this.carStatus = carStatus;
    }
    
    
    
    /*
    Getters and Setters
    */
    
    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }
    
    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public CarStatusEnum getCarStatus() {
        return carStatus;
    }

    public void setCarStatus(CarStatusEnum carStatus) {
        this.carStatus = carStatus;
    }

    public Boolean getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    public CarModel getCarModel() {
        return carModel;
    }

    public void setCarModel(CarModel carModel) {
        this.carModel = carModel;
    }

    public Outlet getOutlet() {
        return outlet;
    }

    public void setOutlet(Outlet outlet) {
        this.outlet = outlet;
    }

    public RentalReservation getRentalReservation() {
        return rentalReservation;
    }

    public void setRentalReservation(RentalReservation rentalReservation) {
        this.rentalReservation = rentalReservation;
    }
    
    
    
    /*
    Auto-generated codes
    */
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (carId != null ? carId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the carId fields are not set
        if (!(object instanceof Car)) {
            return false;
        }
        Car other = (Car) object;
        if ((this.carId == null && other.carId != null) || (this.carId != null && !this.carId.equals(other.carId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Car[ id=" + carId + " ]";
    }
    
}
