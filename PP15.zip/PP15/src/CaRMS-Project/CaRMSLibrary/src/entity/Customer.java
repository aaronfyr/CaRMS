/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author aaronf
 */
@Entity
public class Customer implements Serializable {

    /*
    Attributes
    */
    
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long customerId;
    
    @Column(nullable = false, length = 64)
    @NotNull
    @Size(max = 64)
    protected String firstName;
    
    @Column(nullable = false, length = 64)
    @NotNull
    @Size(max = 64)
    protected String lastName;
    
    @Column(nullable = false, length = 32, unique = true)
    @NotNull
    @Size(max = 32)
    protected String email;

    @OneToMany(mappedBy = "customer")
    protected List<RentalReservation> rentalReservations;

    
    
    /*
    Constructors
    */
    
    public Customer() {
        this.rentalReservations = new ArrayList<>();
    }

    public Customer(String firstName, String lastName, String email) {
        this();
        
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }
    
    
    /*
    Getters and setters
     */
    
    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<RentalReservation> getRentalReservations() {
        return rentalReservations;
    }

    public void setRentalReservations(List<RentalReservation> rentalReservations) {
        this.rentalReservations = rentalReservations;
    }

    
    
    /*
    Auto-generated codes
    */
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerId != null ? customerId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the customerId fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.customerId == null && other.customerId != null) || (this.customerId != null && !this.customerId.equals(other.customerId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Customer[ id=" + customerId + " ]";
    }
    
}
