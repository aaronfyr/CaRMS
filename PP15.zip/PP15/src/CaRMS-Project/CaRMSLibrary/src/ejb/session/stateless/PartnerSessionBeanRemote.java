/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Partner;
import entity.PartnerCustomer;
import entity.RentalReservation;
import javax.ejb.Remote;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.PartnerCustomerAlreadyRegisteredWithPartnerException;
import util.exception.PartnerNotFoundException;
import util.exception.PartnerUsernameExistException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface PartnerSessionBeanRemote {

    public Long partnerLogin(String username, String password) throws PartnerNotFoundException, InvalidLoginCredentialException;

    public Long createNewPartner(Partner newPartner) throws PartnerUsernameExistException, UnknownPersistenceException, InputDataValidationException;

    public Partner retrievePartnerByPartnerId(Long partnerId) throws PartnerNotFoundException;

    public Partner retrievePartnerByUsername(String username) throws PartnerNotFoundException;

    public void addPartnerCustomerToPartner(Partner partner, PartnerCustomer partnerCustomer) throws PartnerCustomerAlreadyRegisteredWithPartnerException;

    public void addRentalReservationToPartner(Partner partner, RentalReservation rentalReservation);
    
}
