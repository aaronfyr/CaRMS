/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.CaRMSCustomer;
import javax.ejb.Remote;
import util.exception.CaRMSCustomerEmailExistException;
import util.exception.CaRMSCustomerNotFoundException;
import util.exception.CaRMSCustomerPassportNumberExistException;
import util.exception.CaRMSCustomerPhoneNumberExistException;
import util.exception.CaRMSCustomerUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.InvalidLoginDetailsException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author jeantay
 */
@Remote
public interface CaRMSCustomerSessionBeanRemote {
    //register new customer
    public Long createNewCaRMSCustomer(CaRMSCustomer caRMSCustomer) throws CaRMSCustomerUsernameExistException, UnknownPersistenceException, CaRMSCustomerPhoneNumberExistException, CaRMSCustomerEmailExistException, InputDataValidationException;
    
    public CaRMSCustomer customerLogin(String username, String password) throws CaRMSCustomerNotFoundException, InvalidLoginCredentialException;

    public Boolean isPhoneNumberAvailable(String phoneNumber);

    public Boolean isPassportNumberAvailable(String passportNumber);
    
    public Boolean isEmailAvailable(String email);

    public Boolean isUsernameAvailable(String username);

}
