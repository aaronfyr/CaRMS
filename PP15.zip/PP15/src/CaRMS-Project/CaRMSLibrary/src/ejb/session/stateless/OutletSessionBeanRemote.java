/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.Employee;
import entity.Outlet;
import entity.TransitDriverDispatchRecord;
import java.util.List;
import javax.ejb.Remote;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarNotFoundException;
import util.exception.EmployeeAlreadyExistInOutletException;
import util.exception.InputDataValidationException;
import util.exception.OutletNameExistException;
import util.exception.OutletNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface OutletSessionBeanRemote {

    public Long createNewOutlet(Outlet newOutlet) throws OutletNameExistException, UnknownPersistenceException, InputDataValidationException;

    public Outlet retrieveOutletByOutletId(Long outletId) throws OutletNotFoundException;

    public List<Outlet> retrieveAllOutlets();

    public void addCarToOutlet(Outlet outlet, Car car) throws CarAlreadyExistInOutletException;

    public void addEmployeeToOutlet(Outlet outlet, Employee employee) throws EmployeeAlreadyExistInOutletException;

    public void addTransitDriverDispatchRecordToOutlet(Outlet outlet, TransitDriverDispatchRecord transitDriverDispatchRecord) throws TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;

}
