/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.RentalRate;
import entity.RentalReservation;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarHasNotTransitToOutletException;
import util.exception.CarIsNotPickedUpException;
import util.exception.CarIsPickedUpException;
import util.exception.CarModelNotFoundException;
import util.exception.CustomerNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.RentalRateNotFoundException;
import util.exception.RentalReservationCompletedException;
import util.exception.RentalReservationIsCancelledException;
import util.exception.RentalReservationNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface RentalReservationSessionBeanRemote {
    
    public Long customerCreateNewRentalReservationUsingCarCategory(RentalReservation newRentalReservation, Long customerId, Long carCategoryId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, CarCategoryNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException;

    public Long customerCreateNewRentalReservationUsingCarModel(RentalReservation newRentalReservation, Long customerId, Long carModelId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, CarModelNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException;

    public Long partnerCreateNewRentalReservationUsingCarCategory(RentalReservation newRentalReservation, Long customerId, Long partnerId, Long carCategoryId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, PartnerNotFoundException, CarCategoryNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException;

    public Long partnerCreateNewRentalReservationUsingCarModel(RentalReservation newRentalReservation, Long customerId, Long partnerId, Long carModelId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, PartnerNotFoundException, CarModelNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException;

    public RentalReservation retrieveRentalReservationByRentalReservationId(Long rentalReservationId) throws RentalReservationNotFoundException;

    public List<RentalReservation> retrieveCustomerRentalReservations(Long customerId);

    public List<RentalReservation> retrievePartnerRentalReservations(Long partnerId);
    
    public List<RentalReservation> retrieveAllRentalReservations();

    public List<RentalReservation> retrieveCustomerRentalReservationsByPickupOutletId(Long outletId);

    public List<RentalReservation> retrieveCustomerRentalReservationsByReturnOutletId(Long outletId);

    public void pickUpCar(Long rentalReservationId) throws RentalReservationNotFoundException, CarHasNotTransitToOutletException, RentalReservationCompletedException, CarIsPickedUpException, RentalReservationIsCancelledException;

    public void returnCar(Long rentalReservationId) throws CarAlreadyExistInOutletException, RentalReservationNotFoundException, RentalReservationCompletedException, CarIsNotPickedUpException, RentalReservationIsCancelledException, RentalRateNotFoundException;
    
    public BigDecimal cancelReservation(Long rentalReservationId) throws RentalReservationNotFoundException;

    public Boolean areThereAvailableCarsByCarCategory(Long carCategoryId, Date pickUpDateTime, Date returnDateTime, Long pickUpOutletId, Long returnOutletId) throws NoAvailableRentalRateException, CarCategoryNotFoundException, OutletNotFoundException;

    public Boolean areThereAvailableCarsByCarModel(Long carModelId, Date pickUpDateTime, Date returnDateTime, Long pickUpOutletId, Long returnOutletId) throws CarCategoryNotFoundException, OutletNotFoundException, CarModelNotFoundException;
    
}
