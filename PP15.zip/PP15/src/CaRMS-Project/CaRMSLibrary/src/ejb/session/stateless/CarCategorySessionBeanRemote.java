/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.CarCategory;
import entity.RentalRate;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;
import util.exception.CarCategoryExistException;
import util.exception.CarCategoryNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface CarCategorySessionBeanRemote {

    public Long createNewCarCategory(CarCategory newCarCategory) throws CarCategoryExistException, UnknownPersistenceException, InputDataValidationException;

    public CarCategory retrieveCarCategoryByCarCategoryId(Long carCategoryId) throws CarCategoryNotFoundException;

    public List<CarCategory> retrieveAllCarCategories();

    public void addRentalRateToCarCategory(CarCategory carCategory, RentalRate rentalRate) throws RentalRateExistInCarCategoryException;
    
    public BigDecimal calculateTotalRentalPrice(Long carCategoryId, Date pickUpDateTime, Date returnDateTime) throws NoAvailableRentalRateException;

    public List<RentalRate> retrieveRentalRatesUsed(Long carCategoryId, Date pickUpDateTime, Date returnDateTime) throws NoAvailableRentalRateException;

    public int retrieveCarCategoryCountByOutletId(Long carCategoryId, Long outletId) throws OutletNotFoundException;
    
}
