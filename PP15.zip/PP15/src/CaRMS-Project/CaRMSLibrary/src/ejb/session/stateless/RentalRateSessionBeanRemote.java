/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.RentalRate;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;
import util.exception.CarCategoryNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.RentalRateExistException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.RentalRateNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface RentalRateSessionBeanRemote {
    
    public Long createNewRentalRate(RentalRate newRentalRate, Long carCategoryId) throws CarCategoryNotFoundException, RentalRateExistInCarCategoryException, RentalRateExistException, UnknownPersistenceException, InputDataValidationException;

    public List<RentalRate> retrieveAllRentalRates();

    public RentalRate retrieveRentalRateByRentalRateId(Long rentalRateId) throws RentalRateNotFoundException;

    public void updateRentalRate(RentalRate rentalRate) throws RentalRateNotFoundException, InputDataValidationException;

    public Boolean deleteRentalRate(Long rentalRateId) throws RentalRateNotFoundException;

    public List<RentalRate> retrieveDefaultRentalRates(Long carCategoryId, Date checkingDate);

    public List<RentalRate> retrievePeakRentalRates(Long carCategoryId, Date checkingDate);

    public List<RentalRate> retrievePromoRentalRates(Long carCategoryId, Date checkingDate);
    
}
