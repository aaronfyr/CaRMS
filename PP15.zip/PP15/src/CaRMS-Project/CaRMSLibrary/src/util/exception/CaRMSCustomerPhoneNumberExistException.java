/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class CaRMSCustomerPhoneNumberExistException extends Exception {

    /**
     * Creates a new instance of
     * <code>CaRMSCustomerPhoneNumberExistException</code> without detail
     * message.
     */
    public CaRMSCustomerPhoneNumberExistException() {
    }

    /**
     * Constructs an instance of
     * <code>CaRMSCustomerPhoneNumberExistException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public CaRMSCustomerPhoneNumberExistException(String msg) {
        super(msg);
    }
}
