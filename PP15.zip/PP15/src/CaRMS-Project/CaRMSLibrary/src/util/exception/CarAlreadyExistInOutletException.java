/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class CarAlreadyExistInOutletException extends Exception {

    /**
     * Creates a new instance of <code>CarAlreadyExistInOutletException</code>
     * without detail message.
     */
    public CarAlreadyExistInOutletException() {
    }

    /**
     * Constructs an instance of <code>CarAlreadyExistInOutletException</code>
     * with the specified detail message.
     *
     * @param msg the detail message.
     */
    public CarAlreadyExistInOutletException(String msg) {
        super(msg);
    }
}
