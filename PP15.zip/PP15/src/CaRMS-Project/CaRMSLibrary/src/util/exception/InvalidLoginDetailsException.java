/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author jeantay
 */
public class InvalidLoginDetailsException extends Exception {

    /**
     * Creates a new instance of <code>InvalidLoginDetailsException</code>
     * without detail message.
     */
    public InvalidLoginDetailsException() {
    }

    /**
     * Constructs an instance of <code>InvalidLoginDetailsException</code> with
     * the specified detail message.
     *
     * @param msg the detail message.
     */
    public InvalidLoginDetailsException(String msg) {
        super(msg);
    }
}
