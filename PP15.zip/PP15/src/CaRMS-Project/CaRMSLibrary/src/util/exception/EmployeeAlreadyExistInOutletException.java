/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class EmployeeAlreadyExistInOutletException extends Exception {

    /**
     * Creates a new instance of
     * <code>EmployeeAlreadyExistInOutletException</code> without detail
     * message.
     */
    public EmployeeAlreadyExistInOutletException() {
    }

    /**
     * Constructs an instance of
     * <code>EmployeeAlreadyExistInOutletException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public EmployeeAlreadyExistInOutletException(String msg) {
        super(msg);
    }
}
