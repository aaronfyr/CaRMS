/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class CaRMSCustomerPassportNumberExistException extends Exception {

    /**
     * Creates a new instance of
     * <code>CaRMSCustomerPassportNumberExistException</code> without detail
     * message.
     */
    public CaRMSCustomerPassportNumberExistException() {
    }

    /**
     * Constructs an instance of
     * <code>CaRMSCustomerPassportNumberExistException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public CaRMSCustomerPassportNumberExistException(String msg) {
        super(msg);
    }
}
