/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carmsreservationclient;

import ejb.session.stateless.CaRMSCustomerSessionBeanRemote;
import ejb.session.stateless.CarCategorySessionBeanRemote;
import ejb.session.stateless.CarModelSessionBeanRemote;
import ejb.session.stateless.OutletSessionBeanRemote;
import ejb.session.stateless.RentalReservationSessionBeanRemote;
import entity.CaRMSCustomer;
import entity.CarCategory;
import entity.CarModel;
import entity.Customer;
import entity.Outlet;
import entity.RentalRate;
import entity.RentalReservation;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CaRMSCustomerEmailExistException;
import util.exception.CaRMSCustomerNotFoundException;
import util.exception.CaRMSCustomerPassportNumberExistException;
import util.exception.CaRMSCustomerPhoneNumberExistException;
import util.exception.CaRMSCustomerUsernameExistException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelNotFoundException;
import util.exception.CustomerNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.OutsideOfOperatingHoursClientException;
import util.exception.RentalRateNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.ReturnDateBeforePickUpDateClientException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
public class MainApp {

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    private RentalReservationSessionBeanRemote rentalReservationSessionBeanRemote;

    private OutletSessionBeanRemote outletSessionBeanRemote;

    private CarModelSessionBeanRemote carModelSessionBeanRemote;

    private CarCategorySessionBeanRemote carCategorySessionBeanRemote;

    private CaRMSCustomerSessionBeanRemote caRMSCustomerSessionBeanRemote;

    private Customer currentCustomer;

    public MainApp() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    public MainApp(RentalReservationSessionBeanRemote rentalReservationSessionBeanRemote, OutletSessionBeanRemote outletSessionBeanRemote, CarModelSessionBeanRemote carModelSessionBeanRemote, CarCategorySessionBeanRemote carCategorySessionBeanRemote, CaRMSCustomerSessionBeanRemote caRMSCustomerSessionBeanRemote) {
        this();

        this.rentalReservationSessionBeanRemote = rentalReservationSessionBeanRemote;
        this.outletSessionBeanRemote = outletSessionBeanRemote;
        this.carModelSessionBeanRemote = carModelSessionBeanRemote;
        this.carCategorySessionBeanRemote = carCategorySessionBeanRemote;
        this.caRMSCustomerSessionBeanRemote = caRMSCustomerSessionBeanRemote;
    }

    public void runApp() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("\n*** Welcome to CaRMS Reservation Client ***\n");
            System.out.println("1: Login");
            System.out.println("2: Register as customer");
            System.out.println("3: Search Car");
            System.out.println("4: Exit\n");

            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    try {
                        doLogin();
                        System.out.println("\nLogin successful\n");
                        menuMain();
                    } catch (CaRMSCustomerNotFoundException ex) {
                        System.out.println("\nCaRMS Customer not found: " + ex.getMessage());
                    } catch (InvalidLoginCredentialException ex) {
                        System.out.println("\nInvalid login credential: " + ex.getMessage());
                    }
                } else if (response == 2) {
                    doRegisterCustomer();
                } else if (response == 3) {
                    doSearchCar();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.println("Invalid option, please try again\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void doLogin() throws CaRMSCustomerNotFoundException, InvalidLoginCredentialException {
        Scanner scanner = new Scanner(System.in);
        String username = "";
        String password = "";

        System.out.println("*** CarMS Reservation Client :: Login ***\n");
        System.out.print("Enter username> ");
        username = scanner.nextLine().trim();
        System.out.print("Enter password> ");
        password = scanner.nextLine().trim();

        if (username.length() > 0 && password.length() > 0) {
            currentCustomer = caRMSCustomerSessionBeanRemote.customerLogin(username, password);
        } else {
            throw new InvalidLoginCredentialException("Missing login credential!");
        }
    }

    private void doRegisterCustomer() {
        Scanner scanner = new Scanner(System.in);
        CaRMSCustomer newCaRMSCustomer = new CaRMSCustomer();

        System.out.println("\n*** CarMS Reservation Client :: Register ***\n");
        System.out.print("Enter username> ");
        newCaRMSCustomer.setUsername(scanner.nextLine().trim());
        System.out.print("Enter password> ");
        newCaRMSCustomer.setPassword(scanner.nextLine().trim());
        System.out.print("Enter first name> ");
        newCaRMSCustomer.setFirstName(scanner.nextLine().trim());
        System.out.print("Enter last name> ");
        newCaRMSCustomer.setLastName(scanner.nextLine().trim());
        System.out.print("Enter email> ");
        newCaRMSCustomer.setEmail(scanner.nextLine().trim());
        
        int response;
        
        while (true) {
            System.out.println("Please choose whether to key in your phone number or passport number for verification purposes.");
            System.out.println("1: Phone Number");
            System.out.println("2: Passport Number");
            
            response = 0;

            while (response < 1 || response > 2) {
                System.out.print("> ");

                response = scanner.nextInt();
                scanner.nextLine();

                if (response == 1) {
                    System.out.print("Enter phone number> ");
                    newCaRMSCustomer.setPhoneNumber(scanner.nextLine().trim());
                    break;
                } else if (response == 2) {
                    System.out.print("Enter passport number> ");
                    newCaRMSCustomer.setPassportNumber(scanner.nextLine().trim());
                    break;
                } else {
                    System.out.println("Invalid option, please try again\n");
                }
            }
            break;
        }

        Set<ConstraintViolation<CaRMSCustomer>> constraintViolations = validator.validate(newCaRMSCustomer);

        if (constraintViolations.isEmpty()) {
            try {
                Long caRMSCustomerId = caRMSCustomerSessionBeanRemote.createNewCaRMSCustomer(newCaRMSCustomer);
                System.out.println("\nCustomer successful registered!: " + caRMSCustomerId);
            } catch (CaRMSCustomerUsernameExistException ex) {
                System.out.println("\nAn error has occurred while creating the customer!: The username already exist\n");
            } catch (CaRMSCustomerPhoneNumberExistException ex) {
                System.out.println("\nAn error has occurred while creating the customer!: The phone number or passport number entered is taken\n");
            } catch (CaRMSCustomerEmailExistException ex) {
                System.out.println("\nAn error has occurred while creating the customer!: The email address already exist\n");
            } catch (UnknownPersistenceException ex) {
                System.out.println("\nAn unknown error has occurred while creating the new customer!: " + ex.getMessage() + "\n");
            } catch (InputDataValidationException ex) {
                System.out.println("\n" + ex.getMessage() + "\n");
            }
        } else {
            showInputDataValidationErrorsForCustomer(constraintViolations);
        }
    }

    private void menuMain() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("\n*** CaRMS Reservation Client ***\n");
            System.out.println("You are login as " + currentCustomer.getFirstName() + " " + currentCustomer.getLastName() + "\n");
            System.out.println("1: Search Car");
            System.out.println("2: View Reservation Details");
            System.out.println("3: View All My Reservations");
            System.out.println("4: Logout\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    doSearchCar();
                } else if (response == 2) {
                    doViewReservationDetails();
                } else if (response == 3) {
                    doViewAllReservations();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void doSearchCar() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Long carCategoryId = new Long(-1);
        Long carModelId = new Long(-1);
        Date pickUpDateTime;
        Date returnDateTime;
        Long pickUpOutletId;
        Long returnOutletId;

        System.out.println("\n*** CaRMS Reservation Client :: Search Car ***\n");
        Boolean canReserve = false;

        try {
            System.out.print("Enter Pickup Date & Time (DD/MM/YYYY HH:MM)> ");
            pickUpDateTime = inputDateFormat.parse(scanner.nextLine().trim());

            System.out.print("Enter Return Date & Time (DD/MM/YYYY HH:MM)> ");
            returnDateTime = inputDateFormat.parse(scanner.nextLine().trim());

            if (returnDateTime.before(pickUpDateTime)) {
                throw new ReturnDateBeforePickUpDateClientException();
            }

            List<Outlet> outlets = outletSessionBeanRemote.retrieveAllOutlets();
            System.out.printf("%4s%64s%20s%20s\n", "ID", "Outlet Name", "Opening Hour", "Closing Hour");

            SimpleDateFormat operatingHours = new SimpleDateFormat("HH:mm");

            for (Outlet outlet : outlets) {
                String openingHours = "";
                String closingHours = "";

                if (outlet.getOpeningHours() != null) {
                    openingHours = operatingHours.format(outlet.getOpeningHours());
                }

                if (outlet.getClosingHours() != null) {
                    closingHours = operatingHours.format(outlet.getClosingHours());
                }
                System.out.printf("%4s%64s%20s%20s\n", outlet.getOutletId(), outlet.getOutletName(),
                        openingHours, closingHours);
            }

            System.out.print("Enter Pickup Outlet ID> ");
            pickUpOutletId = scanner.nextLong();
            System.out.print("Enter Return Outlet ID> ");
            returnOutletId = scanner.nextLong();

            Outlet pickUpOutlet = outletSessionBeanRemote.retrieveOutletByOutletId(pickUpOutletId);
            LocalDateTime pickUpDateTimeConverted = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
            LocalDateTime returnDateTimeConverted = LocalDateTime.ofInstant(returnDateTime.toInstant(), ZoneId.systemDefault());

            if (pickUpOutlet.getOpeningHours() != null && pickUpOutlet.getClosingHours() != null) {

                LocalDateTime openingHoursConverted = LocalDateTime.ofInstant(pickUpOutlet.getOpeningHours().toInstant(), ZoneId.systemDefault());
                LocalDateTime closingHoursConverted = LocalDateTime.ofInstant(pickUpOutlet.getClosingHours().toInstant(), ZoneId.systemDefault());

                if ((pickUpDateTimeConverted.getHour() < openingHoursConverted.getHour())
                        || (pickUpDateTimeConverted.getHour() == openingHoursConverted.getHour()
                        && pickUpDateTimeConverted.getMinute() < openingHoursConverted.getMinute())) {
                    throw new OutsideOfOperatingHoursClientException("Pickup time is before opening hours of the pickup outlet. Please try again!\n");
                } else if ((pickUpDateTimeConverted.getHour() > closingHoursConverted.getHour())
                        || (pickUpDateTimeConverted.getHour() == closingHoursConverted.getHour()
                        && pickUpDateTimeConverted.getMinute() > closingHoursConverted.getMinute())) {
                    throw new OutsideOfOperatingHoursClientException("Pickup time is after closing hours of the pickup outlet. Please try again!\n");
                }
            }

            Outlet returnOutlet = outletSessionBeanRemote.retrieveOutletByOutletId(returnOutletId);

            if (returnOutlet.getOpeningHours() != null && returnOutlet.getClosingHours() != null) {

                LocalDateTime openingHoursConverted = LocalDateTime.ofInstant(returnOutlet.getOpeningHours().toInstant(), ZoneId.systemDefault());
                LocalDateTime closingHoursConverted = LocalDateTime.ofInstant(returnOutlet.getClosingHours().toInstant(), ZoneId.systemDefault());

                if ((returnDateTimeConverted.getHour() < openingHoursConverted.getHour())
                        || (returnDateTimeConverted.getHour() == openingHoursConverted.getHour()
                        && returnDateTimeConverted.getMinute() < openingHoursConverted.getMinute())) {
                    throw new OutsideOfOperatingHoursClientException("Return time is before opening hours of the return outlet. Please try again!\n");
                } else if ((returnDateTimeConverted.getHour() > closingHoursConverted.getHour())
                        || (returnDateTimeConverted.getHour() == closingHoursConverted.getHour()
                        && returnDateTimeConverted.getMinute() > closingHoursConverted.getMinute())) {
                    throw new OutsideOfOperatingHoursClientException("Return time is after closing hours of the return outlet. Please try again!\n");
                }
            }

            while (true) {
                System.out.println("\n*** Search by Car Category or Car Model? ***\n");
                System.out.println("1: Search by Car Category");
                System.out.println("2: Search by Car Model");
                System.out.println("3: Back\n");
                response = 0;
                while (response < 1 || response > 3) {
                    System.out.print("> ");
                    response = scanner.nextInt();

                    if (response == 1) {
                        List<CarCategory> carCategories = carCategorySessionBeanRemote.retrieveAllCarCategories();
                        System.out.printf("%4s%64s\n", "ID", "Car Category Name");

                        for (CarCategory carCategory : carCategories) {
                            System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
                        }
                        System.out.print("Choose Car Category ID> ");
                        carCategoryId = scanner.nextLong();
                        canReserve = rentalReservationSessionBeanRemote.areThereAvailableCarsByCarCategory(carCategoryId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId);
                        break;
                    } else if (response == 2) {
                        List<CarModel> carModels = carModelSessionBeanRemote.retrieveAllCarModels();
                        System.out.printf("%4s%64s%32s%32s\n", "ID", "Car Category Name", "Make", "Model");
                        for (CarModel carModel : carModels) {
                            System.out.printf("%4s%64s%32s%32s\n", carModel.getCarModelId(), carModel.getCarCategory().getCarCategoryName(), carModel.getMakeName(), carModel.getModelName());
                        }
                        System.out.print("Enter Car Model ID> ");
                        carModelId = scanner.nextLong();
                        CarModel carModel = carModelSessionBeanRemote.retrieveCarModelByCarModelId(carModelId);
                        carCategoryId = carModel.getCarCategory().getCarCategoryId();
                        canReserve = rentalReservationSessionBeanRemote.areThereAvailableCarsByCarModel(carModelId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId);
                        break;
                    } else if (response == 3) {
                        break;
                    } else {
                        System.out.println("\nInvalid option, please try again\n");
                    }
                }
                if (response == 3) {
                    break;
                }

                scanner.nextLine();
                Boolean isCarCategory = false;

                if (response == 1) {
                    isCarCategory = true;
                } else {
                    isCarCategory = false;
                }

                if (!canReserve) {
                    System.out.println("\nNo cars are available tentatively!");
                } else {
                    BigDecimal totalRentalFee = carCategorySessionBeanRemote.calculateTotalRentalPrice(carCategoryId, pickUpDateTime, returnDateTime);
                    List<RentalRate> rentalRatesUsed = carCategorySessionBeanRemote.retrieveRentalRatesUsed(carCategoryId, pickUpDateTime, returnDateTime);
                    System.out.println("\nThere are cars available! Total rental fee is SGD" + totalRentalFee + ". ");
                    if (currentCustomer != null) {
                        System.out.print("Would you like to reserve a car? (Enter 'Y' to reserve a car)> ");
                        String input = scanner.nextLine().trim();
                        if (input.equals("Y") && isCarCategory) {
                            doReserveCarUsingCarCategory(carCategoryId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId, totalRentalFee, rentalRatesUsed);
                            break;
                        } else if (input.equals("Y") && !isCarCategory) {
                            doReserveCarUsingCarModel(carModelId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId, totalRentalFee, rentalRatesUsed);
                            break;
                        } else {
                            break;
                        }
                    } else {
                        System.out.println("\nPlease login to reserve the car! Would you like to login?\n");
                        System.out.print("Would you like to login? (Enter 'Y' to go to login page)> ");
                        String input = scanner.nextLine().trim();
                        if (input.equals("Y")) {
                            break;
                        } else {
                            break;
                        }
                    }
                }
            }
        } catch (ParseException ex) {
            System.out.println("\nInvalid date input!\n");
        } catch (NoAvailableRentalRateException ex) {
            System.out.println("\nThere are no available rental rates for the period!\n");
        } catch (CarCategoryNotFoundException ex) {
            System.out.println("\nCar Category not found for ID: " + carCategoryId + "\n");
        } catch (CarModelNotFoundException ex) {
            System.out.println("\nCar Model not found for ID: " + carModelId + "\n");
        } catch (OutletNotFoundException ex) {
            System.out.println("\nOutlet not found!");
        } catch (OutsideOfOperatingHoursClientException ex) {
            System.out.println("\n" + ex.getMessage());
        } catch (ReturnDateBeforePickUpDateClientException ex) {
            System.out.println("\nReturn date entered is before pick up date!");
        }

    }

    private void doReserveCarUsingCarCategory(Long carCategoryId, Date pickUpDateTime, Date returnDateTime, Long pickupOutletId, Long returnOutletId, BigDecimal totalRentalFee, List<RentalRate> rentalRatesUsed) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation newRentalReservation = new RentalReservation();

        System.out.println("\n*** CaRMS Reservation Client :: Reserve Car Using Car Category ***\n");

        newRentalReservation.setStartDate(pickUpDateTime);
        newRentalReservation.setEndDate(returnDateTime);
        newRentalReservation.setRentalPrice(totalRentalFee);
        newRentalReservation.setRentalRates(rentalRatesUsed);

        System.out.print("Enter Credit Card Number> ");
        String creditCardNumber = scanner.nextLine().trim();
        newRentalReservation.setCreditCardNumber(creditCardNumber);

        System.out.print("Would you like to pay now? (Enter 'Y' to pay now)> ");
        String input = scanner.nextLine().trim();
        if (input.equals("Y")) {
            newRentalReservation.setIsPaid(true);
        } else {
            newRentalReservation.setIsPaid(false);
        }

        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);

        if (constraintViolations.isEmpty()) {

            try {
                Long rentalReservationId = rentalReservationSessionBeanRemote.customerCreateNewRentalReservationUsingCarCategory(newRentalReservation, currentCustomer.getCustomerId(), carCategoryId, pickupOutletId, returnOutletId, rentalRatesUsed);
                if (newRentalReservation.getIsPaid()) {
                    System.out.println("\nCharged " + totalRentalFee.toString() + " to credit card: " + creditCardNumber);
                } else {
                    System.out.println("\nPlease pay " + totalRentalFee.toString() + " when picking up the car");
                }
                System.out.println("\nRental reservation created with ID: " + rentalReservationId);
            } catch (CarCategoryNotFoundException ex) {
                System.out.println("\nCar Category not found for ID: " + carCategoryId + "\n");
            } catch (OutletNotFoundException ex) {
                System.out.println("\nOutlet not found!\n");
            } catch (CustomerNotFoundException | RentalRateNotFoundException | InputDataValidationException | UnknownPersistenceException ex) {
                System.out.println("\n" + ex.getMessage());
            }

        } else {
            showInputDataValidationErrorsForRentalReservation(constraintViolations);
        }
    }

    private void doReserveCarUsingCarModel(Long carModelId, Date pickUpDateTime, Date returnDateTime, Long pickupOutletId, Long returnOutletId, BigDecimal totalRentalFee, List<RentalRate> rentalRatesUsed) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation newRentalReservation = new RentalReservation();

        System.out.println("\n*** CaRMS Reservation Client :: Reserve Car Using Car Model ***\n");

        newRentalReservation.setStartDate(pickUpDateTime);
        newRentalReservation.setEndDate(returnDateTime);
        newRentalReservation.setRentalPrice(totalRentalFee);
        newRentalReservation.setRentalRates(rentalRatesUsed);

        System.out.print("Enter Credit Card Number> ");
        String creditCardNumber = scanner.nextLine().trim();
        newRentalReservation.setCreditCardNumber(creditCardNumber);

        System.out.print("Would you like to pay now? (Enter 'Y' to pay now)> ");
        String input = scanner.nextLine().trim();
        if (input.equals("Y")) {
            newRentalReservation.setIsPaid(true);
            System.out.println("\nCharged " + totalRentalFee.toString() + " to credit card: " + creditCardNumber);
        } else {
            newRentalReservation.setIsPaid(false);
            System.out.println("\nPlease pay " + totalRentalFee.toString() + " when picking up the car.");
        }

        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);
        if (constraintViolations.isEmpty()) {
            try {
                Long rentalReservationId = rentalReservationSessionBeanRemote.customerCreateNewRentalReservationUsingCarModel(newRentalReservation, currentCustomer.getCustomerId(), carModelId, pickupOutletId, returnOutletId, rentalRatesUsed);
                System.out.println("\nRental reservation created with ID: " + rentalReservationId);
            } catch (CarModelNotFoundException ex) {
                System.out.println("\nCar Model not found for ID: " + carModelId + "\n");
            } catch (OutletNotFoundException ex) {
                System.out.println("\nOutlet not found!\n");
            } catch (CustomerNotFoundException | RentalRateNotFoundException | InputDataValidationException | UnknownPersistenceException ex) {
                System.out.println("\n" + ex.getMessage());
            }
        } else {
            showInputDataValidationErrorsForRentalReservation(constraintViolations);
        }
    }

    private void doViewAllReservations() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** CaRMS Reservation Client :: View All Reservations ***\n");
        List<RentalReservation> rentalReservations = rentalReservationSessionBeanRemote.retrieveCustomerRentalReservations(currentCustomer.getCustomerId());
        System.out.printf("%4s%20s%20s%32s%32s%8s%16s%16s\n", "ID", "Start Date", "End Date", "Pick Up Outlet", "Return Outlet", "Paid?", "Cancelled?", "Completed?");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (RentalReservation rentalReservation : rentalReservations) {
            System.out.printf("%4s%20s%20s%32s%32s%8s%16s%16s\n", rentalReservation.getRentalReservationId(),
                    sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()),
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName(),
                    rentalReservation.getIsPaid().toString(),
                    rentalReservation.getIsCancelled().toString(),
                    rentalReservation.getIsCompleted().toString());
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doViewReservationDetails() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** CaRMS Reservation Client :: View Reservation Details ***\n");
        List<RentalReservation> rentalReservations = rentalReservationSessionBeanRemote.retrieveCustomerRentalReservations(currentCustomer.getCustomerId());
        System.out.printf("%4s%20s%20s%16s%16s\n", "ID", "Start Date", "End Date", "Pick Up Outlet", "Return Outlet");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (RentalReservation rentalReservation : rentalReservations) {
            System.out.printf("%4s%20s%20s%16s%16s\n", rentalReservation.getRentalReservationId(),
                    sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()),
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName());
        }
        System.out.print("Enter Reservation ID> ");
        Long rentalReservationId = scanner.nextLong();
        scanner.nextLine();

        try {
            RentalReservation rentalReservation = rentalReservationSessionBeanRemote.retrieveRentalReservationByRentalReservationId(rentalReservationId);
            System.out.printf("%4s%20s%20s%20s%12s%12s%32s%32s%16s%16s\n",
                    "ID", "Start Date",
                    "End Date", "Rental Fee",
                    "Paid?", "Cancelled?",
                    "Car Category", "Car Make and Model", "Pick Up Outlet", "Return Outlet");
            String makeAndModelName = "";
            if (rentalReservation.getCarModel() != null) {
                makeAndModelName = rentalReservation.getCarModel().getMakeName() + " " + rentalReservation.getCarModel().getModelName();
            }
            System.out.printf("%4s%20s%20s%20s%12s%12s%32s%32s%16s%16s\n",
                    rentalReservation.getRentalReservationId(), sdf.format(rentalReservation.getStartDate()),
                    sdf.format(rentalReservation.getEndDate()), rentalReservation.getRentalPrice().toString(),
                    rentalReservation.getIsPaid().toString(), rentalReservation.getIsCancelled().toString(),
                    rentalReservation.getCarCategory().getCarCategoryName(), makeAndModelName,
                    rentalReservation.getPickUpOutlet().getOutletName(),
                    rentalReservation.getReturnOutlet().getOutletName());
            if (rentalReservation.getIsCancelled() || (rentalReservation.getIsPickedUp() && !rentalReservation.getIsCompleted()) || rentalReservation.getIsCompleted()) {
                System.out.print("Press any key to continue...> ");
            } else {
                System.out.print("Would you like to cancel the reservation? (Enter 'Y' to enter cancel the reservation)> ");
                String input = scanner.nextLine().trim();
                if (input.equals("Y")) {
                    doCancelReservation(rentalReservationId);
                } else {
                    System.out.print("Press any key to continue...> ");
                }
            }
        } catch (RentalReservationNotFoundException ex) {
            System.out.println("\nRental Reservation not found for ID " + rentalReservationId);
        }
    }

    private void doCancelReservation(Long rentalReservationId) {
        Scanner scanner = new Scanner(System.in);
        RentalReservation rentalReservation;

        System.out.println("\n*** CaRMS Reservation Client :: Cancel Reservation ***\n");
        try {
            BigDecimal penalty = rentalReservationSessionBeanRemote.cancelReservation(rentalReservationId);
            rentalReservation = rentalReservationSessionBeanRemote.retrieveRentalReservationByRentalReservationId(rentalReservationId);

            System.out.println("\nReservation successfully cancelled!");

            if (rentalReservation.getIsPaid()) {
                System.out.println("\nYou have been refunded SGD $"
                        + rentalReservation.getRentalPrice().subtract(penalty) + " to your card "
                        + rentalReservation.getCreditCardNumber()
                        + " after deducting cancellation penalty of SGD" + penalty + ".");
            } else {
                System.out.println("\nYour card : " + rentalReservation.getCreditCardNumber() + " has been charged SGD $" + penalty + " as a cancellation penalty.");
            }

        } catch (RentalReservationNotFoundException ex) {
            System.out.println("Rental Reservation not found for ID " + rentalReservationId);
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void showInputDataValidationErrorsForCustomer(Set<ConstraintViolation<CaRMSCustomer>> constraintViolations) {
        System.out.println("\nInput data validation error!:");

        for (ConstraintViolation constraintViolation : constraintViolations) {
            System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage());
        }

        System.out.println("\nPlease try again......\n");
    }

    private void showInputDataValidationErrorsForRentalReservation(Set<ConstraintViolation<RentalReservation>> constraintViolations) {
        System.out.println("\nInput data validation error!:");

        for (ConstraintViolation constraintViolation : constraintViolations) {
            System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage());
        }

        System.out.println("\nPlease try again......\n");
    }
}
