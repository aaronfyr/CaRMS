/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carmsreservationclient;

import ejb.session.stateless.CaRMSCustomerSessionBeanRemote;
import ejb.session.stateless.CarCategorySessionBeanRemote;
import ejb.session.stateless.CarModelSessionBeanRemote;
import ejb.session.stateless.OutletSessionBeanRemote;
import ejb.session.stateless.RentalReservationSessionBeanRemote;
import java.text.ParseException;
import javax.ejb.EJB;
import util.exception.OutsideOfOperatingHoursClientException;
import util.exception.ReturnDateBeforePickUpDateClientException;

/**
 *
 * @author jeantay
 */
public class Main {

    @EJB(name = "RentalReservationSessionBeanRemote")
    private static RentalReservationSessionBeanRemote rentalReservationSessionBeanRemote;

    @EJB(name = "OutletSessionBeanRemote")
    private static OutletSessionBeanRemote outletSessionBeanRemote;

    @EJB(name = "CarModelSessionBeanRemote")
    private static CarModelSessionBeanRemote carModelSessionBeanRemote;

    @EJB(name = "CarCategorySessionBeanRemote")
    private static CarCategorySessionBeanRemote carCategorySessionBeanRemote;

    @EJB(name = "CaRMSCustomerSessionBeanRemote")
    private static CaRMSCustomerSessionBeanRemote caRMSCustomerSessionBeanRemote;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException, ReturnDateBeforePickUpDateClientException, OutsideOfOperatingHoursClientException {
        // TODO code application logic here
        MainApp mainApp = new MainApp(rentalReservationSessionBeanRemote, outletSessionBeanRemote, carModelSessionBeanRemote, carCategorySessionBeanRemote, caRMSCustomerSessionBeanRemote);
        mainApp.runApp();
    }
    
}
