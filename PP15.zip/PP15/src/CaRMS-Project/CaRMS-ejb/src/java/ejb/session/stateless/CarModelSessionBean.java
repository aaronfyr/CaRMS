/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.CarCategory;
import entity.CarModel;
import java.util.List;
import java.util.Set;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelNameExistException;
import util.exception.CarModelNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class CarModelSessionBean implements CarModelSessionBeanRemote, CarModelSessionBeanLocal {

    @EJB(name = "CarCategorySessionBeanLocal")
    private CarCategorySessionBeanLocal carCategorySessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    public CarModelSessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public Long createNewCarModel(CarModel newCarModel, Long carCategoryId) throws CarCategoryNotFoundException, CarModelNameExistException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<CarModel>> constraintViolations = validator.validate(newCarModel);

        if (constraintViolations.isEmpty()) {
            try {
                CarCategory carCategory = carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId);
                newCarModel.setCarCategory(carCategory);
                carCategory.getCarModels().add(newCarModel);
                em.persist(newCarModel);
                em.flush();
                return newCarModel.getCarModelId();
            } catch (CarCategoryNotFoundException ex) {
                throw new CarCategoryNotFoundException("Car Category not found for ID: " + carCategoryId);
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new CarModelNameExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    
    
    @Override
    public CarModel retrieveCarModelByCarModelId(Long carModelId) throws CarModelNotFoundException {
        CarModel carModel = em.find(CarModel.class, carModelId);

        if (carModel != null) {
            return carModel;
        } else {
            throw new CarModelNotFoundException("Car Model ID " + carModelId + " does not exist!");
        }
    }

    
    
    @Override
    public List<CarModel> retrieveAllCarModels() {
        // should be sorted in ascending order by car category, make and model.
        Query query = em.createQuery("SELECT cm FROM CarModel cm ORDER BY cm.carCategory.carCategoryName, cm.makeName, cm.modelName ASC");
        return query.getResultList();
    }

    
    
    @Override
    public void updateModel(CarModel carModel, Long carCategoryId) throws CarCategoryNotFoundException, CarModelNotFoundException, InputDataValidationException {
        if (carModel != null && carModel.getCarModelId() != null) {

            Set<ConstraintViolation<CarModel>> constraintViolations = validator.validate(carModel);

            if (constraintViolations.isEmpty()) {
                CarModel carModelToUpdate = retrieveCarModelByCarModelId(carModel.getCarModelId()); // no unique identifier for car model since can edit car model so no need if else
                carModelToUpdate.setMakeName(carModel.getMakeName());
                carModelToUpdate.setModelName(carModel.getModelName());
                carModelToUpdate.setCars(carModel.getCars());
                CarCategory carCategory = carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId); // might need to do try statement
                carModelToUpdate.setCarCategory(carCategory);
            } else {
                throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
            }

        } else {
            throw new CarModelNotFoundException("Car Model ID not provided for rental rate to be updated");
        }
    }

    
    
    @Override
    public Boolean deleteCarModel(Long carModelId) throws CarModelNotFoundException {
        try {
            CarModel carModelToRemove = retrieveCarModelByCarModelId(carModelId);
            for (Car car : carModelToRemove.getCars()) {
                System.out.println("Car ID: " + car.getLicensePlate() + " is still linked!");
            }
            if (carModelToRemove.getCars().isEmpty()) {
                em.remove(carModelToRemove);
                return true;
            } else {
                carModelToRemove.setIsEnabled(false);
                return false;
            }
        } catch (CarModelNotFoundException ex) {
            throw new CarModelNotFoundException("Unable to delete car model as provided car model ID: " + carModelId + " does not exist");
        }
    }

    
    
    @Override
    public void addCarToCarModel(CarModel carModel, Car car) throws CarAlreadyRegisteredWithCarModelException {
        if (!carModel.getCars().contains(car)) {
            carModel.getCars().add(car);
        } else {
            throw new CarAlreadyRegisteredWithCarModelException("Car already registered with the car model!");
        }
    }

    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<CarModel>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }
}
