/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.CarModel;
import entity.Outlet;
import entity.RentalReservation;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarModelDisabledException;
import util.exception.CarModelNotFoundException;
import util.exception.CarNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InsufficientCarsForRentalReservationException;
import util.exception.LicensePlateExistException;
import util.exception.OutletNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class CarSessionBean implements CarSessionBeanRemote, CarSessionBeanLocal {

    @EJB(name = "CarSessionBeanLocal")
    private CarSessionBeanLocal carSessionBeanLocal;

    @EJB(name = "RentalReservationSessionBeanLocal")
    private RentalReservationSessionBeanLocal rentalReservationSessionBeanLocal;
    
    @EJB(name = "CarModelSessionBeanLocal")
    private CarModelSessionBeanLocal carModelSessionBeanLocal;
    
    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;
    
    
    
    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;
    
    private final ValidatorFactory validatorFactory;
    private final Validator validator;
    
    public CarSessionBean() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Long createNewCar(Car newCar, Long outletId, Long carModelId) throws LicensePlateExistException, OutletNotFoundException, CarModelNotFoundException, CarAlreadyExistInOutletException, CarAlreadyRegisteredWithCarModelException, CarModelDisabledException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<Car>> constraintViolations = validator.validate(newCar);
        
        if (constraintViolations.isEmpty()) {
            try {
                Outlet outlet = outletSessionBeanLocal.retrieveOutletByOutletId(outletId);
                CarModel carModel = carModelSessionBeanLocal.retrieveCarModelByCarModelId(carModelId);
                if (carModel.getIsEnabled()) {
                    newCar.setCarModel(carModel);
                    newCar.setOutlet(outlet);
                    outletSessionBeanLocal.addCarToOutlet(outlet, newCar);
                    carModelSessionBeanLocal.addCarToCarModel(carModel, newCar);
                    em.persist(newCar);
                    em.flush();
                    return newCar.getCarId();
                } else {
                    throw new CarModelDisabledException();
                }
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Outlet not found for ID: " + outletId);
            } catch (CarModelNotFoundException ex) {
                throw new CarModelNotFoundException("Car Model not found for ID: " + carModelId);
            } catch (CarAlreadyExistInOutletException ex) {
                throw new CarAlreadyExistInOutletException("Car with license plate: " + newCar.getLicensePlate() + " already exist in outlet!");
            } catch (CarAlreadyRegisteredWithCarModelException ex) {
                throw new CarAlreadyRegisteredWithCarModelException("Car with license plate: " + newCar.getLicensePlate() + " is already registered with the car model!");
            } catch (CarModelDisabledException ex) {
                throw new CarModelDisabledException("Car Model is disabled. Please enable the Car Model.");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new LicensePlateExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }
    
    @Override
    public Car retrieveCarByCarId(Long carId) throws CarNotFoundException {
        Car car = em.find(Car.class, carId);
        
        if (car != null) {
            return car;
        } else {
            throw new CarNotFoundException("Car ID " + carId + " does not exist!");
        }
    }
    
    @Override
    public List<Car> retrieveCarsByCarModelId(Long carModelId) {
        Query query = em.createQuery("SELECT c FROM Car c WHERE c.carModel.carModelId = :inModelId");
        query.setParameter("inModelId", carModelId);
        return query.getResultList();
    }
    
    @Override
    public List<Car> retrieveCarsByCarCategoryId(Long carCategoryId) {
        Query query = em.createQuery("SELECT c FROM Car c WHERE c.carModel.carCategory.carCategoryId = :inCarCategoryId");
        query.setParameter("inCarCategoryId", carCategoryId);
        return query.getResultList();
    }
    
    @Override
    public void updateCar(Car car) throws CarNotFoundException, InputDataValidationException {
        if (car != null && car.getCarId() != null) {
            Set<ConstraintViolation<Car>> constraintViolations = validator.validate(car);
            
            if (constraintViolations.isEmpty()) {
                Car carToUpdate = retrieveCarByCarId(car.getCarId());
                carToUpdate.setLicensePlate(car.getLicensePlate());
                carToUpdate.setColour(car.getColour());
                carToUpdate.setCarStatus(car.getCarStatus());
            } else {
                throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
            }
        } else {
            throw new CarNotFoundException("Car ID not provided for rental rate to be updated");
        }
    }
    
    @Override
    public Boolean deleteCar(Long carId) throws CarNotFoundException, InsufficientCarsForRentalReservationException {
        try {
            Car carToRemove = retrieveCarByCarId(carId);
            List<RentalReservation> rentalReservations = rentalReservationSessionBeanLocal.retrieveAllRentalReservations();
            int countOfRentalReservationsNeedThisCarCategory = 0;
            List<Car> sameCategoryCars = carSessionBeanLocal.retrieveCarsByCarCategoryId(carId);
            int countOfSameCategoryCars = sameCategoryCars.size();
            
            for (RentalReservation rentalReservation : rentalReservations) {
                if (rentalReservation.getCarCategory().getCarCategoryId() == carId) {
                    countOfRentalReservationsNeedThisCarCategory += 1;
                }
            }
            
            if (countOfRentalReservationsNeedThisCarCategory > 0 && countOfSameCategoryCars < 2) { //at least one reservation needs this car category and you only have 1 car of this category
                throw new InsufficientCarsForRentalReservationException();
            } else if (carToRemove.getRentalReservation() == null) {
                carToRemove.getCarModel().getCars().remove(carToRemove);
                carToRemove.getOutlet().getCars().remove(carToRemove);
                em.remove(carToRemove);
                return true;
            } else {
                carToRemove.setOutlet(null);
                carToRemove.setIsEnabled(false);
                return false;
            }
        } catch (CarNotFoundException ex) {
            throw new CarNotFoundException("Unable to delete car as provided car ID: " + carId + " does not exist");
        } catch (InsufficientCarsForRentalReservationException ex) {
            throw new InsufficientCarsForRentalReservationException("Unable to delete car ID: " + carId + " as there will be no cars for rental reservations made for this Car Category!");
        }
    }
    
    @Override
    public List<Car> retrieveCarsByOutletId(Long outletId) {
        Query query = em.createQuery("SELECT c FROM Car c WHERE c.outlet.outletId = :inOutletId");
        query.setParameter("inOutletId", outletId);
        return query.getResultList();
    }
    
    @Override
    public List<Car> retrieveAllCars() {
        Query query = em.createQuery("SELECT c FROM Car c ORDER BY c.carModel.carCategory.carCategoryName, c.carModel.makeName, c.carModel.modelName, c.licensePlate ASC");
        return query.getResultList();
    }
    
    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<Car>> constraintViolations) {
        String msg = "Input data validation error!:";
        
        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }
        
        return msg;
    }
}
