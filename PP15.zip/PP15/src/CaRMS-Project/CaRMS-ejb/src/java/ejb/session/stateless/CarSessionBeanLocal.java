/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import java.util.List;
import javax.ejb.Local;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarModelDisabledException;
import util.exception.CarModelNotFoundException;
import util.exception.CarNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InsufficientCarsForRentalReservationException;
import util.exception.LicensePlateExistException;
import util.exception.OutletNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Local
public interface CarSessionBeanLocal {

    public Long createNewCar(Car newCar, Long outletId, Long carModelId) throws LicensePlateExistException, OutletNotFoundException, CarModelNotFoundException, CarAlreadyExistInOutletException, CarAlreadyRegisteredWithCarModelException, CarModelDisabledException, UnknownPersistenceException, InputDataValidationException;

    public Car retrieveCarByCarId(Long carId) throws CarNotFoundException;

    public List<Car> retrieveCarsByCarModelId(Long carModelId);

    public List<Car> retrieveCarsByCarCategoryId(Long carCategoryId);

    public void updateCar(Car car) throws CarNotFoundException, InputDataValidationException;

    public Boolean deleteCar(Long carId) throws CarNotFoundException, InsufficientCarsForRentalReservationException;

    public List<Car> retrieveCarsByOutletId(Long outletId);

    public List<Car> retrieveAllCars();
    
}
