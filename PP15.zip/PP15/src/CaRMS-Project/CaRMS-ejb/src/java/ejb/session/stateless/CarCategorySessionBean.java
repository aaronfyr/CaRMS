/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.CarCategory;
import entity.Outlet;
import entity.RentalRate;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CarCategoryExistException;
import util.exception.CarCategoryNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class CarCategorySessionBean implements CarCategorySessionBeanRemote, CarCategorySessionBeanLocal {

    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;

    @EJB(name = "CarSessionBeanLocal")
    private CarSessionBeanLocal carSessionBeanLocal;

    @EJB(name = "RentalRateSessionBeanLocal")
    private RentalRateSessionBeanLocal rentalRateSessionBeanLocal;
    
    

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;
    private static final int FIRST_ELEMENT = 0;

    public CarCategorySessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public Long createNewCarCategory(CarCategory newCarCategory) throws CarCategoryExistException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<CarCategory>> constraintViolations = validator.validate(newCarCategory);

        if (constraintViolations.isEmpty()) {
            try {
                em.persist(newCarCategory);
                em.flush();
                return newCarCategory.getCarCategoryId();
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new CarCategoryExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public CarCategory retrieveCarCategoryByCarCategoryId(Long carCategoryId) throws CarCategoryNotFoundException {
        CarCategory carCategory = em.find(CarCategory.class, carCategoryId);

        if (carCategory != null) {
            return carCategory;
        } else {
            throw new CarCategoryNotFoundException("Car Category ID " + carCategoryId + " does not exist!");
        }
    }

    @Override
    public List<CarCategory> retrieveAllCarCategories() {
        Query query = em.createQuery("SELECT c FROM CarCategory c ORDER BY c.carCategoryId ASC");
        return query.getResultList();
    }

    @Override
    public void addRentalRateToCarCategory(CarCategory carCategory, RentalRate rentalRate) throws RentalRateExistInCarCategoryException {
        if (!carCategory.getRentalRates().contains(rentalRate)) {
            carCategory.getRentalRates().add(rentalRate);
        } else {
            throw new RentalRateExistInCarCategoryException("Rental rate already exists in the car category!");
        }
    }

    @Override
    public BigDecimal calculateTotalRentalPrice(Long carCategoryId, Date pickUpDateTime, Date returnDateTime) throws NoAvailableRentalRateException {
        BigDecimal totalRentalPrice = new BigDecimal(0);
        LocalDateTime pickUpDateTimeConverted = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
        LocalDateTime returnDateTimeConverted = LocalDateTime.ofInstant(returnDateTime.toInstant(), ZoneId.systemDefault());
        returnDateTimeConverted.withHour(pickUpDateTimeConverted.getHour()).withMinute(pickUpDateTimeConverted.getMinute());
        
        try {
            Long numberOfRentalDays = ChronoUnit.DAYS.between(pickUpDateTimeConverted, returnDateTimeConverted);
            int hourDifferential = returnDateTimeConverted.getHour() - pickUpDateTimeConverted.getHour();
            System.out.println("Hour differential is " + hourDifferential);
            int minuteDifferential = returnDateTimeConverted.getMinute() - pickUpDateTimeConverted.getMinute();
            System.out.println("Minute differential is " + minuteDifferential);
            if (hourDifferential != 0 || (hourDifferential == 0 && minuteDifferential > 0)) {
                numberOfRentalDays += 1;
            }
            
            Date rentalDate = Date.from(pickUpDateTimeConverted.atZone(ZoneId.systemDefault()).toInstant());

            for (int i = 0; i < numberOfRentalDays; i++) {
                System.out.println("Current Checking Rental Date is: " + rentalDate);
                List<RentalRate> cheapestDefaultRentalRate = rentalRateSessionBeanLocal.retrieveDefaultRentalRates(carCategoryId, rentalDate);
                List<RentalRate> cheapestPeakRentalRate = rentalRateSessionBeanLocal.retrievePeakRentalRates(carCategoryId, rentalDate);
                List<RentalRate> cheapestPromoRentalRate = rentalRateSessionBeanLocal.retrievePromoRentalRates(carCategoryId, rentalDate);
                BigDecimal dailyCheapestRentalRate = new BigDecimal(0);
                if (!cheapestPromoRentalRate.isEmpty()) {
                    dailyCheapestRentalRate = cheapestPromoRentalRate.get(FIRST_ELEMENT).getRatePerDay();
                } else if (!cheapestPeakRentalRate.isEmpty()) {
                    dailyCheapestRentalRate = cheapestPeakRentalRate.get(FIRST_ELEMENT).getRatePerDay();
                } else if (!cheapestDefaultRentalRate.isEmpty()) {
                    dailyCheapestRentalRate = cheapestDefaultRentalRate.get(FIRST_ELEMENT).getRatePerDay();
                } else {
                    throw new NoAvailableRentalRateException("No available rental rates!");
                }
                totalRentalPrice = totalRentalPrice.add(dailyCheapestRentalRate);
                System.out.println("Rental Fee is " + dailyCheapestRentalRate + " " + rentalDate.toString());
                pickUpDateTimeConverted = pickUpDateTimeConverted.plusDays(1);
                rentalDate = Date.from(pickUpDateTimeConverted.atZone(ZoneId.systemDefault()).toInstant());
            }

            return totalRentalPrice;
        } catch (NoAvailableRentalRateException ex) {
            throw new NoAvailableRentalRateException("No available rental rates!");
        }
    }
        
    @Override
    public List<RentalRate> retrieveRentalRatesUsed(Long carCategoryId, Date pickUpDateTime, Date returnDateTime) throws NoAvailableRentalRateException {
        List<RentalRate> rentalRatesUsed = new ArrayList<>();
        LocalDateTime pickUpDateTimeConverted = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
        LocalDateTime returnDateTimeConverted = LocalDateTime.ofInstant(returnDateTime.toInstant(), ZoneId.systemDefault());
        returnDateTimeConverted.withHour(pickUpDateTimeConverted.getHour()).withMinute(pickUpDateTimeConverted.getMinute());
        
        try {
            Long numberOfRentalDays = ChronoUnit.DAYS.between(pickUpDateTimeConverted, returnDateTimeConverted);
            int hourDifferential = returnDateTimeConverted.getHour() - pickUpDateTimeConverted.getHour();
            System.out.println("Hour differential is " + hourDifferential);
            int minuteDifferential = returnDateTimeConverted.getMinute() - pickUpDateTimeConverted.getMinute();
            System.out.println("Minute differential is " + minuteDifferential);
            if (hourDifferential != 0 || (hourDifferential == 0 && minuteDifferential > 0)) {
                numberOfRentalDays += 1;
            }
            
            Date rentalDate = Date.from(pickUpDateTimeConverted.atZone(ZoneId.systemDefault()).toInstant());

            for (int i = 0; i < numberOfRentalDays; i++) {
                System.out.println("Current Checking Rental Date is: " + rentalDate);
                List<RentalRate> defaultRentalRates = rentalRateSessionBeanLocal.retrieveDefaultRentalRates(carCategoryId, rentalDate);
                List<RentalRate> peakRentalRates = rentalRateSessionBeanLocal.retrievePeakRentalRates(carCategoryId, rentalDate);
                List<RentalRate> promoRentalRates = rentalRateSessionBeanLocal.retrievePromoRentalRates(carCategoryId, rentalDate);
 
                if (!promoRentalRates.isEmpty()) {
                    if (!rentalRatesUsed.contains(promoRentalRates.get(FIRST_ELEMENT))) { // Have not saved this rental rate before
                        rentalRatesUsed.add(promoRentalRates.get(FIRST_ELEMENT));
                        System.out.println("Rental Rate Used for " + rentalDate + "is " + promoRentalRates.get(FIRST_ELEMENT));
                    }
                } else if (!peakRentalRates.isEmpty()) {
                    if (!rentalRatesUsed.contains(peakRentalRates.get(FIRST_ELEMENT))) { // Have not saved this rental rate before
                        rentalRatesUsed.add(peakRentalRates.get(FIRST_ELEMENT));
                        System.out.println("Rental Rate Used for " + rentalDate + "is " + peakRentalRates.get(FIRST_ELEMENT));
                    }
                } else if (!defaultRentalRates.isEmpty()) {
                    if (!rentalRatesUsed.contains(defaultRentalRates.get(FIRST_ELEMENT))) { // Have not saved this rental rate before
                        rentalRatesUsed.add(defaultRentalRates.get(FIRST_ELEMENT));
                        System.out.println("Rental Rate Used for " + rentalDate + "is " + defaultRentalRates.get(FIRST_ELEMENT));
                    }
                } else {
                    throw new NoAvailableRentalRateException("No available rental rates!");
                }
                pickUpDateTimeConverted = pickUpDateTimeConverted.plusDays(1);
                rentalDate = Date.from(pickUpDateTimeConverted.atZone(ZoneId.systemDefault()).toInstant());
            }

            return rentalRatesUsed;
        } catch (NoAvailableRentalRateException ex) {
            throw new NoAvailableRentalRateException("No available rental rates!");
        }
    }
    
    @Override
    public int retrieveCarCategoryCountByOutletId(Long carCategoryId, Long outletId) throws OutletNotFoundException {
        Outlet outlet = outletSessionBeanLocal.retrieveOutletByOutletId(outletId);
        List<Car> carsInOutlet = outlet.getCars();
        int availableCarCategoryCount = 0;
        for (Car car : carsInOutlet) {
            if (car.getCarModel().getCarCategory().getCarCategoryId() == carCategoryId) {
                availableCarCategoryCount += 1;
            }
        }
        return availableCarCategoryCount;
    }

    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<CarCategory>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }

}
