/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Employee;
import entity.Outlet;
import entity.RentalReservation;
import entity.TransitDriverDispatchRecord;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.DriverNotWorkingInSameOutletException;
import util.exception.EmployeeNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.OutletNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;
import util.exception.TransitDriverDispatchRecordIsNotAssignedException;
import util.exception.TransitDriverDispatchRecordNotFoundException;

/**
 *
 * @author jeantay
 */
@Stateless
public class TransitDriverDispatchRecordSessionBean implements TransitDriverDispatchRecordSessionBeanRemote, TransitDriverDispatchRecordSessionBeanLocal {

    @EJB(name = "RentalReservationSessionBeanLocal")
    private RentalReservationSessionBeanLocal rentalReservationSessionBeanLocal;

    @EJB(name = "EmployeeSessionBeanLocal")
    private EmployeeSessionBeanLocal employeeSessionBeanLocal;

    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    public TransitDriverDispatchRecordSessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    //25. generate transit driver dispatch records for current day reservations
    //ask aaron to check: need to 
    @Override
    public Long createNewTransitDriverDispatchRecord(Long destinationOutletId, Long rentalReservationId, Date transitDate) throws RentalReservationNotFoundException, OutletNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException {
        TransitDriverDispatchRecord transitDriverDispatchRecord = new TransitDriverDispatchRecord(transitDate);
        Set<ConstraintViolation<TransitDriverDispatchRecord>> constraintViolations = validator.validate(transitDriverDispatchRecord);

        if (constraintViolations.isEmpty()) {
            try {
                Outlet destinationOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(destinationOutletId);
                RentalReservation rentalReservation = rentalReservationSessionBeanLocal.retrieveRentalReservationByRentalReservationId(rentalReservationId);
                //set the outlet relationship
                transitDriverDispatchRecord.setDestinationOutlet(destinationOutlet);
                outletSessionBeanLocal.addTransitDriverDispatchRecordToOutlet(destinationOutlet, transitDriverDispatchRecord);
                //how about employee? (assign driver)
                //tag rental reservation to the trans, this is unidirectional
                rentalReservation.setTransitDriverDispatchRecord(transitDriverDispatchRecord);
                em.persist(transitDriverDispatchRecord);
                em.flush();
                return transitDriverDispatchRecord.getTransitDriverDispatchRecordId();
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Outlet ID: " + destinationOutletId + " not found!");
            } catch (RentalReservationNotFoundException ex) {
                throw new RentalReservationNotFoundException("Rental Reservation ID: " + rentalReservationId + " not found!");
            } catch (TransitDriverDispatchRecordAlreadyRegisteredWithOutletException ex) {
                throw new TransitDriverDispatchRecordAlreadyRegisteredWithOutletException("Transit Driver Dispatch Record ID: " + transitDriverDispatchRecord.getTransitDriverDispatchRecordId() + " already registered with outlet!");
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public List<TransitDriverDispatchRecord> retrieveTransitDriverDispatchRecordByOutletId(Date date, Long outletId) {
        LocalDateTime pickUpDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        pickUpDate = pickUpDate.plusDays(1);
        Date nextDay = Date.from(pickUpDate.atZone(ZoneId.systemDefault()).toInstant());

        Query query = em.createQuery("SELECT t FROM TransitDriverDispatchRecord t WHERE t.destinationOutlet.outletId = :inOutletId AND t.transitDate >= :inToday AND t.transitDate < :inNextDay");
        query.setParameter("inOutletId", outletId);
        query.setParameter("inToday", date);
        query.setParameter("inNextDay", nextDay);
        return query.getResultList();
    }

    @Override
    public TransitDriverDispatchRecord retrieveTransitDriverDispatchRecordByTransitDriverDispatchRecordId(Long transitDriverDispatchRecordId) throws TransitDriverDispatchRecordNotFoundException {
        TransitDriverDispatchRecord transitDriverDispatchRecord = em.find(TransitDriverDispatchRecord.class, transitDriverDispatchRecordId);

        if (transitDriverDispatchRecord != null) {
            return transitDriverDispatchRecord;
        } else {
            throw new TransitDriverDispatchRecordNotFoundException("Transit Driver Dispatch Record ID " + transitDriverDispatchRecordId + " does not exist!");
        }
    }

    @Override
    public void updateTransitAsCompleted(Long transitDriverDispatchRecordId) throws TransitDriverDispatchRecordNotFoundException, TransitDriverDispatchRecordIsNotAssignedException {
        try {
            TransitDriverDispatchRecord transitDriverDispatchRecord = retrieveTransitDriverDispatchRecordByTransitDriverDispatchRecordId(transitDriverDispatchRecordId);
            if (transitDriverDispatchRecord.getTransitDispatchDriver() != null) {
                transitDriverDispatchRecord.setIsCompleted(true);
            } else {
                throw new TransitDriverDispatchRecordIsNotAssignedException();
            }
        } catch (TransitDriverDispatchRecordNotFoundException ex) {
            throw new TransitDriverDispatchRecordNotFoundException("Transit Driver Dispatch Record ID: " + transitDriverDispatchRecordId + " not found!");
        } catch (TransitDriverDispatchRecordIsNotAssignedException ex) {
            throw new TransitDriverDispatchRecordIsNotAssignedException("Transit Driver Dispatch Record ID: " + transitDriverDispatchRecordId + " has no assigned employee yet!");
        }
    }

    @Override
    public void assignDriver(Long employeeId, Long transitDriverDispatchRecordId) throws DriverNotWorkingInSameOutletException, TransitDriverDispatchRecordNotFoundException, EmployeeNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException {
        try {
            TransitDriverDispatchRecord transitDriverDispatchRecord = retrieveTransitDriverDispatchRecordByTransitDriverDispatchRecordId(transitDriverDispatchRecordId);
            Employee transitDriver = employeeSessionBeanLocal.retrieveEmployeeByEmployeeId(employeeId);
            if (transitDriver.getOutlet().getOutletName().equals(transitDriverDispatchRecord.getDestinationOutlet().getOutletName())) {
                transitDriverDispatchRecord.setTransitDispatchDriver(transitDriver);
                employeeSessionBeanLocal.addTransitDriverDispatchRecordToEmployee(transitDriver, transitDriverDispatchRecord);
            } else {
                throw new DriverNotWorkingInSameOutletException("Employee is not working in the current outlet");
            }
        } catch (EmployeeNotFoundException ex) {
            throw new EmployeeNotFoundException("Employee ID: " + employeeId + " not found!");
        } catch (TransitDriverDispatchRecordNotFoundException ex) {
            throw new TransitDriverDispatchRecordNotFoundException("Transit Driver Dispatch Record ID: " + transitDriverDispatchRecordId + " not found!");
        } catch (TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException ex) {
            throw new TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException("Transit Driver Dispatch Record ID: " + transitDriverDispatchRecordId + " already registered with employee!");
        }
    }

    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<TransitDriverDispatchRecord>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }
}
