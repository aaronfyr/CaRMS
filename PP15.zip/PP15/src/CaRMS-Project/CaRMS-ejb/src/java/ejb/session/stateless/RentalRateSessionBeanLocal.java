/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.RentalRate;
import entity.RentalReservation;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelNotFoundException;
import util.exception.CustomerNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.RentalRateExistException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.RentalRateNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Local
public interface RentalRateSessionBeanLocal {
    
    public Long createNewRentalRate(RentalRate newRentalRate, Long carCategoryId) throws CarCategoryNotFoundException, RentalRateExistInCarCategoryException, RentalRateExistException, UnknownPersistenceException, InputDataValidationException;

    public List<RentalRate> retrieveAllRentalRates();

    public RentalRate retrieveRentalRateByRentalRateId(Long rentalRateId) throws RentalRateNotFoundException;

    public void updateRentalRate(RentalRate rentalRate) throws RentalRateNotFoundException, InputDataValidationException;

    public Boolean deleteRentalRate(Long rentalRateId) throws RentalRateNotFoundException;

    public List<RentalRate> retrieveDefaultRentalRates(Long carCategoryId, Date checkingDate);

    public List<RentalRate> retrievePeakRentalRates(Long carCategoryId, Date checkingDate);

    public List<RentalRate> retrievePromoRentalRates(Long carCategoryId, Date checkingDate);

}
