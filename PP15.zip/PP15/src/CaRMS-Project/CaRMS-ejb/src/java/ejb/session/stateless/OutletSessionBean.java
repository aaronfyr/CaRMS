/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.Employee;
import entity.Outlet;
import entity.TransitDriverDispatchRecord;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.EmployeeAlreadyExistInOutletException;
import util.exception.InputDataValidationException;
import util.exception.OutletNameExistException;
import util.exception.OutletNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class OutletSessionBean implements OutletSessionBeanRemote, OutletSessionBeanLocal {

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    public OutletSessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Long createNewOutlet(Outlet newOutlet) throws OutletNameExistException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<Outlet>> constraintViolations = validator.validate(newOutlet);

        if (constraintViolations.isEmpty()) {
            try {
                em.persist(newOutlet);
                em.flush();
                return newOutlet.getOutletId();
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new OutletNameExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public Outlet retrieveOutletByOutletId(Long outletId) throws OutletNotFoundException {
        Outlet outlet = em.find(Outlet.class, outletId);

        if (outlet != null) { // outlet exists
            return outlet;
        } else {
            throw new OutletNotFoundException("Outlet ID " + outletId + " does not exist!");
        }
    }
    
    @Override
    public List<Outlet> retrieveAllOutlets() {
        Query query = em.createQuery("SELECT o FROM Outlet o");
        return query.getResultList();
    }

    @Override
    public void addCarToOutlet(Outlet outlet, Car car) throws CarAlreadyExistInOutletException {
        if (!outlet.getCars().contains(car)) {
            outlet.getCars().add(car);
        } else {
            throw new CarAlreadyExistInOutletException("Car already exists in the outlet!");
        }
    }
    
    
    @Override
    public void addTransitDriverDispatchRecordToOutlet(Outlet outlet, TransitDriverDispatchRecord transitDriverDispatchRecord) throws TransitDriverDispatchRecordAlreadyRegisteredWithOutletException {
        if (!outlet.getTransitDriverDispatchRecords().contains(transitDriverDispatchRecord)) {
            outlet.getTransitDriverDispatchRecords().add(transitDriverDispatchRecord);
        } else {
            throw new TransitDriverDispatchRecordAlreadyRegisteredWithOutletException("Transit Driver Dispatch Record already registered with the outlet!");
        }
    }

    @Override
    public void addEmployeeToOutlet(Outlet outlet, Employee employee) throws EmployeeAlreadyExistInOutletException {
        if (!outlet.getEmployees().contains(employee)) {
            outlet.getEmployees().add(employee);
        } else {
            throw new EmployeeAlreadyExistInOutletException("Employee already exists in the outlet!");
        }
    }
    
    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<Outlet>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }
}
