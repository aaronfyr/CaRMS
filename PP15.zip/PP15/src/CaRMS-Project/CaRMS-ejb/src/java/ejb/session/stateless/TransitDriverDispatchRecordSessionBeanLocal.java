/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Employee;
import entity.TransitDriverDispatchRecord;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;
import util.exception.DriverNotWorkingInSameOutletException;
import util.exception.EmployeeNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.OutletNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;
import util.exception.TransitDriverDispatchRecordIsNotAssignedException;
import util.exception.TransitDriverDispatchRecordNotFoundException;

/**
 *
 * @author jeantay
 */
@Local
public interface TransitDriverDispatchRecordSessionBeanLocal {
    
    //23. transit dispatch driver records <-r/s-> destinationOutlet
    public List<TransitDriverDispatchRecord> retrieveTransitDriverDispatchRecordByOutletId(Date date, Long outletId);

    //6. rental reservation session bean uses this to get the transit driver dispatch record id
    public TransitDriverDispatchRecord retrieveTransitDriverDispatchRecordByTransitDriverDispatchRecordId(Long transitDriverDispatchRecordId) throws TransitDriverDispatchRecordNotFoundException;
    
    //25. update transit as completed
    public void updateTransitAsCompleted(Long transitDriverDispatchRecordId) throws TransitDriverDispatchRecordNotFoundException, TransitDriverDispatchRecordIsNotAssignedException;
    
    //24. assign transit driver
    public void assignDriver(Long employeeId, Long transitDriverDispatchRecordId) throws DriverNotWorkingInSameOutletException, TransitDriverDispatchRecordNotFoundException, EmployeeNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException;
    
    //25. generate transit driver dispatch records for current day reservations
    public Long createNewTransitDriverDispatchRecord(Long destinationOutletId, Long rentalReservationId, Date transitDate) throws RentalReservationNotFoundException, OutletNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException;
 
}
