/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.singleton;

import ejb.session.stateless.CaRMSCustomerSessionBeanLocal;
import ejb.session.stateless.CarCategorySessionBeanLocal;
import ejb.session.stateless.CarModelSessionBeanLocal;
import ejb.session.stateless.CarSessionBeanLocal;
import ejb.session.stateless.EmployeeSessionBeanLocal;
import ejb.session.stateless.OutletSessionBeanLocal;
import ejb.session.stateless.PartnerSessionBeanLocal;
import ejb.session.stateless.RentalRateSessionBeanLocal;
import entity.CaRMSCustomer;
import entity.Car;
import entity.CarCategory;
import entity.CarModel;
import entity.Employee;
import entity.Outlet;
import entity.Partner;
import entity.RentalRate;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import util.enumeration.CarStatusEnum;
import util.enumeration.EmployeeRoleEnum;
import util.enumeration.RentalRateTypeEnum;
import util.exception.CaRMSCustomerUsernameExistException;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarCategoryExistException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelDisabledException;
import util.exception.CarModelNameExistException;
import util.exception.CarModelNotFoundException;
import util.exception.EmployeeAlreadyExistInOutletException;
import util.exception.EmployeeUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.LicensePlateExistException;
import util.exception.OutletNameExistException;
import util.exception.OutletNotFoundException;
import util.exception.PartnerUsernameExistException;
import util.exception.RentalRateExistException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author jeantay
 */
@Singleton
@LocalBean
@Startup
public class DataInitSessionBean {

    // Customer for testing, can remove for submission
    @EJB(name = "CaRMSCustomerSessionBeanLocal")
    private CaRMSCustomerSessionBeanLocal caRMSCustomerSessionBeanLocal;

    @EJB(name = "CarSessionBeanLocal")
    private CarSessionBeanLocal carSessionBeanLocal;

    @EJB(name = "CarCategorySessionBeanLocal")
    private CarCategorySessionBeanLocal carCategorySessionBeanLocal;

    @EJB(name = "CarModelSessionBeanLocal")
    private CarModelSessionBeanLocal carModelSessionBeanLocal;

    @EJB(name = "EmployeeSessionBeanLocal")
    private EmployeeSessionBeanLocal employeeSessionBeanLocal;

    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;

    @EJB(name = "PartnerSessionBeanLocal")
    private PartnerSessionBeanLocal partnerSessionBeanLocal;

    @EJB(name = "RentalRateSessionBeanLocal")
    private RentalRateSessionBeanLocal rentalRateSessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @PostConstruct
    public void postConstruct() {
        if (em.find(Outlet.class, 1l) == null && em.find(Employee.class, 1l) == null && em.find(CarCategory.class, 1l) == null && em.find(CarModel.class, 1l) == null && em.find(Car.class, 1l) == null && em.find(RentalRate.class, 1l) == null && em.find(Partner.class, 1l) == null) {
            System.out.println("###adding data");
            initialiseData();
        }
    }

    private void initialiseData() {
        Date openingHours = new Date();
        LocalDateTime openHoursDateTimeConvert = LocalDateTime.ofInstant(openingHours.toInstant(), ZoneId.systemDefault());
        openHoursDateTimeConvert = openHoursDateTimeConvert.withYear(2022).withMonth(11).withDayOfMonth(12).withHour(8).withMinute(0).withSecond(0);
        openingHours = Date.from(openHoursDateTimeConvert.atZone(ZoneId.systemDefault()).toInstant());
        Date closingHours = new Date();
        LocalDateTime closingHoursDateTimeConvert = LocalDateTime.ofInstant(closingHours.toInstant(), ZoneId.systemDefault());
        closingHoursDateTimeConvert = closingHoursDateTimeConvert.withYear(2022).withMonth(11).withDayOfMonth(12).withHour(22).withMinute(0).withSecond(0);
        closingHours = Date.from(closingHoursDateTimeConvert.atZone(ZoneId.systemDefault()).toInstant());

        Outlet outletA = new Outlet("Outlet A", "Woodlands Avenue 5");
        Outlet outletB = new Outlet("Outlet B", "10 Jalan Besar");
        Outlet outletC = new Outlet("Outlet C", "Orchard Gateway Road", openingHours, closingHours);

        try {
            Long outletAId = outletSessionBeanLocal.createNewOutlet(outletA);
            Long outletBId = outletSessionBeanLocal.createNewOutlet(outletB);
            Long outletCId = outletSessionBeanLocal.createNewOutlet(outletC);
            
//            CaRMSCustomer aaron = new CaRMSCustomer("yizzie", "123", "12345678", "", "Aaron", "Foo", "aaron@hotmail.com");
//            
//            caRMSCustomerSessionBeanLocal.createNewCaRMSCustomer(aaron);
            
            Employee a1 = new Employee("Employee", "A1", "1sales", "123", EmployeeRoleEnum.SALES_MANAGER);
            Employee b1 = new Employee("Employee", "B1", "2sales", "123", EmployeeRoleEnum.SALES_MANAGER);
            Employee c1 = new Employee("Employee", "C1", "3sales", "123", EmployeeRoleEnum.SALES_MANAGER);

            Employee a2 = new Employee("Employee", "A2", "1ops", "123", EmployeeRoleEnum.OPERATIONS_MANAGER);
            Employee b2 = new Employee("Employee", "B2", "2ops", "123", EmployeeRoleEnum.OPERATIONS_MANAGER);
            Employee c2 = new Employee("Employee", "C2", "3ops", "123", EmployeeRoleEnum.OPERATIONS_MANAGER);

            Employee a3 = new Employee("Employee", "A3", "1cust", "123", EmployeeRoleEnum.CUSTOMER_SERVICE_EXECUTIVE);
            Employee b3 = new Employee("Employee", "B3", "2cust", "123", EmployeeRoleEnum.CUSTOMER_SERVICE_EXECUTIVE);
            Employee c3 = new Employee("Employee", "C3", "3cust", "123", EmployeeRoleEnum.CUSTOMER_SERVICE_EXECUTIVE);

            Employee a4 = new Employee("Employee", "A4", "1employee1", "123", EmployeeRoleEnum.EMPLOYEE);
            Employee a5 = new Employee("Employee", "A5", "1employee2", "123", EmployeeRoleEnum.EMPLOYEE);

            employeeSessionBeanLocal.createNewEmployee(a1, outletAId);
            employeeSessionBeanLocal.createNewEmployee(a2, outletAId);
            employeeSessionBeanLocal.createNewEmployee(a3, outletAId);
            employeeSessionBeanLocal.createNewEmployee(a4, outletAId);
            employeeSessionBeanLocal.createNewEmployee(a5, outletAId);

            employeeSessionBeanLocal.createNewEmployee(b1, outletBId);
            employeeSessionBeanLocal.createNewEmployee(b2, outletBId);
            employeeSessionBeanLocal.createNewEmployee(b3, outletBId);

            employeeSessionBeanLocal.createNewEmployee(c1, outletCId);
            employeeSessionBeanLocal.createNewEmployee(c2, outletCId);
            employeeSessionBeanLocal.createNewEmployee(c3, outletCId);
            
            Partner holidayDotCom = new Partner("Holiday.com", "123");
            partnerSessionBeanLocal.createNewPartner(holidayDotCom);

            CarCategory standardSedan = new CarCategory("Standard Sedan");
            CarCategory familySedan = new CarCategory("Family Sedan");
            CarCategory luxurySedan = new CarCategory("Luxury Sedan");
            CarCategory suvMinivan = new CarCategory("SUV and Minivan");

            Long standardSedanId = carCategorySessionBeanLocal.createNewCarCategory(standardSedan);
            Long familySedanId = carCategorySessionBeanLocal.createNewCarCategory(familySedan);
            Long luxurySedanId = carCategorySessionBeanLocal.createNewCarCategory(luxurySedan);
            Long suvMinivanId = carCategorySessionBeanLocal.createNewCarCategory(suvMinivan);

            CarModel toyotaCorolla = new CarModel("Toyota", "Corolla");
            CarModel hondaCivic = new CarModel("Honda", "Civic");
            CarModel nissanSunny = new CarModel("Nissan", "Sunny");
            CarModel mercedesEclass = new CarModel("Mercedes", "E Class");
            CarModel bmw5Series = new CarModel("BMW", "5 Series");
            CarModel audiA6 = new CarModel("Audi", "A6");

            Long toyotaCorollaId = carModelSessionBeanLocal.createNewCarModel(toyotaCorolla, standardSedanId);
            Long hondaCivicId = carModelSessionBeanLocal.createNewCarModel(hondaCivic, standardSedanId);
            Long nissanSunnyId = carModelSessionBeanLocal.createNewCarModel(nissanSunny, standardSedanId);
            Long mercedesEclassId = carModelSessionBeanLocal.createNewCarModel(mercedesEclass, luxurySedanId);
            Long bmw5SeriesId = carModelSessionBeanLocal.createNewCarModel(bmw5Series, luxurySedanId);
            Long audiA6Id = carModelSessionBeanLocal.createNewCarModel(audiA6, luxurySedanId);

            Car car1 = new Car("SS00A1TC", "BLACK", CarStatusEnum.AVAILABLE);
            Car car2 = new Car("SS00A2TC", "WHITE", CarStatusEnum.AVAILABLE);
            Car car3 = new Car("SS00A3TC", "RED", CarStatusEnum.AVAILABLE);

            Car car4 = new Car("SS00B1HC", "BLACK", CarStatusEnum.AVAILABLE);
            Car car5 = new Car("SS00B2HC", "WHITE", CarStatusEnum.AVAILABLE);
            Car car6 = new Car("SS00B3HC", "RED", CarStatusEnum.AVAILABLE);

            Car car7 = new Car("SS00C1NS", "BLACK", CarStatusEnum.AVAILABLE);
            Car car8 = new Car("SS00C2NS", "WHITE", CarStatusEnum.AVAILABLE);
            Car car9 = new Car("SS00C3NS", "RED", CarStatusEnum.REPAIR);

            Car car10 = new Car("LS00A4ME", "BLACK", CarStatusEnum.AVAILABLE);
            //have not added 
            Car car11 = new Car("LS00B4B5", "WHITE", CarStatusEnum.AVAILABLE);
            Car car12 = new Car("LS00C4A6", "RED", CarStatusEnum.AVAILABLE);

            carSessionBeanLocal.createNewCar(car1, outletAId, toyotaCorollaId);
            carSessionBeanLocal.createNewCar(car2, outletAId, toyotaCorollaId);
            carSessionBeanLocal.createNewCar(car3, outletAId, toyotaCorollaId);

            carSessionBeanLocal.createNewCar(car4, outletBId, hondaCivicId);
            carSessionBeanLocal.createNewCar(car5, outletBId, hondaCivicId);
            carSessionBeanLocal.createNewCar(car6, outletBId, hondaCivicId);

            carSessionBeanLocal.createNewCar(car7, outletCId, nissanSunnyId);
            carSessionBeanLocal.createNewCar(car8, outletCId, nissanSunnyId);
            carSessionBeanLocal.createNewCar(car9, outletCId, nissanSunnyId);

            carSessionBeanLocal.createNewCar(car10, outletAId, mercedesEclassId);
            //have not add
            carSessionBeanLocal.createNewCar(car11, outletBId, bmw5SeriesId);
            carSessionBeanLocal.createNewCar(car12, outletCId, audiA6Id);

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            
            //Standard Sedan - Default, Default, Standard Sedan, 100, null, null (always valid)
            RentalRate standardSedanDefault = new RentalRate("Standard Sedan - Default", RentalRateTypeEnum.DEFAULT, BigDecimal.valueOf(100.0));
            
            //Standard Sedan - Weekend Promo, Promotion, Standard Sedan, 80, 09/12/2022 12:00, 11/12/2022 00:00
            Date startDateTime = sdf.parse("09/12/2022 12:00");
            Date endDateTime = sdf.parse("11/12/2022 00:00");
            RentalRate standardSedanWeekendPromo = new RentalRate("Standard Sedan - Weekend Promo", RentalRateTypeEnum.PROMO, BigDecimal.valueOf(80.0));
            standardSedanWeekendPromo.setStartDate(startDateTime);
            standardSedanWeekendPromo.setEndDate(endDateTime);
            
            //Family Sedan - Default, Default, Family Sedan, 200, null, null (always valid)
            RentalRate familySedanDefault = new RentalRate("Family Sedan - Default", RentalRateTypeEnum.DEFAULT, BigDecimal.valueOf(200.0));
            //Luxury Sedan - Default, Default, Luxury Sedan, 300, null, null (always valid)
            RentalRate luxurySedanDefault = new RentalRate("Luxury Sedan - Default", RentalRateTypeEnum.DEFAULT, BigDecimal.valueOf(300.0));
            
            //Luxury Sedan - Monday, Peak, Luxury Sedan, 310, 05/12/2022 00:00, 05/12/2022 23:59
            startDateTime = sdf.parse("05/12/2022 00:00");
            endDateTime = sdf.parse("05/12/2022 23:59");
            RentalRate luxurySedanMonday = new RentalRate("Luxury Sedan - Monday", RentalRateTypeEnum.PEAK, BigDecimal.valueOf(310.0));
            luxurySedanMonday.setStartDate(startDateTime);
            luxurySedanMonday.setEndDate(endDateTime);
            
            
            //Luxury Sedan - Tuesday, Peak, Luxury Sedan, 320, 06/12/2022 00:00, 06/12/2022 23:59
            startDateTime = sdf.parse("06/12/2022 00:00");
            endDateTime = sdf.parse("06/12/2022 23:59");
            RentalRate luxurySedanTuesday = new RentalRate("Luxury Sedan - Tuesday", RentalRateTypeEnum.PEAK, BigDecimal.valueOf(320.0));
            luxurySedanTuesday.setStartDate(startDateTime);
            luxurySedanTuesday.setEndDate(endDateTime);

            //Luxury Sedan - Wednesday, Peak, Luxury Sedan, 330, 07/12/2022 00:00, 07/12/2022 23:59
            startDateTime = sdf.parse("07/12/2022 00:00");
            endDateTime = sdf.parse("07/12/2022 23:59");
            RentalRate luxurySedanWednesday = new RentalRate("Luxury Sedan - Wednesday", RentalRateTypeEnum.PEAK, BigDecimal.valueOf(330.0));
            luxurySedanWednesday.setStartDate(startDateTime);
            luxurySedanWednesday.setEndDate(endDateTime);

            //Luxury Sedan - Weekday Promo, Promotion, Luxury Sedan, 250, 07/12/2022 12:00, 08/12/2022 12:00
            startDateTime = sdf.parse("07/12/2022 12:00");
            endDateTime = sdf.parse("08/12/2022 12:00");
            RentalRate luxurySedanWeekdayPromo = new RentalRate("Luxury Sedan - Weekday Promo", RentalRateTypeEnum.PROMO, BigDecimal.valueOf(250.0));
            luxurySedanWeekdayPromo.setStartDate(startDateTime);
            luxurySedanWeekdayPromo.setEndDate(endDateTime);
            
            
            //SUV and Minivan - Default, Default, SUV and Minivan, 400, null, null (always valid)
            RentalRate suvAndMinivanDefault = new RentalRate("SUV and Minivan - Default", RentalRateTypeEnum.DEFAULT, BigDecimal.valueOf(400.0));

            
            rentalRateSessionBeanLocal.createNewRentalRate(standardSedanDefault, standardSedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(standardSedanWeekendPromo, standardSedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(familySedanDefault, familySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(luxurySedanDefault, luxurySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(luxurySedanMonday, luxurySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(luxurySedanTuesday, luxurySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(luxurySedanWednesday, luxurySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(luxurySedanWeekdayPromo, luxurySedanId);
            rentalRateSessionBeanLocal.createNewRentalRate(suvAndMinivanDefault, suvMinivanId);
            

        } catch (ParseException ex) {
            System.out.println(ex.getMessage());
        } catch (CarCategoryNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (UnknownPersistenceException ex) {
            System.out.println(ex.getMessage());
        } catch (InputDataValidationException ex) {
            System.out.println(ex.getMessage());
        } catch (CarModelDisabledException ex) {
            System.out.println(ex.getMessage());
        } catch (CarModelNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (OutletNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (LicensePlateExistException ex) {
            System.out.println(ex.getMessage());
        } catch (CarModelNameExistException ex) {
            System.out.println(ex.getMessage());
        } catch (CarCategoryExistException ex) {
            System.out.println("Car Category already exists in the database!");
        } catch (PartnerUsernameExistException ex) {
            System.out.println("Partner name already exists in the database!");
        } catch (OutletNameExistException ex) {
            System.out.println("Outlet name already exists in the database!");
        } catch (EmployeeUsernameExistException ex) {
            System.out.println(ex.getMessage());
        } catch (EmployeeAlreadyExistInOutletException ex) {
            System.out.println("Employee already exists in outlet!");
        } catch (CarAlreadyExistInOutletException ex) {
            System.out.println("Car already exists in outlet!");
        } catch (CarAlreadyRegisteredWithCarModelException ex) {
            System.out.println("Car already exists in outlet!");
        } catch (RentalRateExistInCarCategoryException ex) {
            System.out.println("Rental rate already exists in car category!");
        } catch (RentalRateExistException ex) {
            System.out.println("Rental rate already exists in car category!");
        } 

    }

}
