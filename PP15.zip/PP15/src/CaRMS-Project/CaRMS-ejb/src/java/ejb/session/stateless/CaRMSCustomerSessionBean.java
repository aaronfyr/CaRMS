/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.CaRMSCustomer;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.CaRMSCustomerEmailExistException;
import util.exception.CaRMSCustomerNotFoundException;
import util.exception.CaRMSCustomerPassportNumberExistException;
import util.exception.CaRMSCustomerPhoneNumberExistException;
import util.exception.CaRMSCustomerUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author jeantay
 */
@Stateless
public class CaRMSCustomerSessionBean implements CaRMSCustomerSessionBeanRemote, CaRMSCustomerSessionBeanLocal {

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    public CaRMSCustomerSessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    @Override
    public Long createNewCaRMSCustomer(CaRMSCustomer caRMSCustomer) throws CaRMSCustomerUsernameExistException, UnknownPersistenceException, CaRMSCustomerPhoneNumberExistException, CaRMSCustomerEmailExistException, InputDataValidationException {
        Set<ConstraintViolation<CaRMSCustomer>> constraintViolations = validator.validate(caRMSCustomer);
        if (constraintViolations.isEmpty()) {
            try {
                if (isUsernameAvailable(caRMSCustomer.getUsername())) {
                    if (isEmailAvailable(caRMSCustomer.getEmail())) {
                        System.out.println("TESTING1");
                        if ((caRMSCustomer.getPassportNumber() != null && isPassportNumberAvailable(caRMSCustomer.getPassportNumber()))
                                || (caRMSCustomer.getPhoneNumber() != null && isPhoneNumberAvailable(caRMSCustomer.getPhoneNumber()))) {
                            System.out.println("TESTING2");
                            em.persist(caRMSCustomer);
                            em.flush();
                        } else {
                            throw new CaRMSCustomerPhoneNumberExistException();
                        }
                    } else {
                        throw new CaRMSCustomerEmailExistException();
                    }
                } else {
                    throw new CaRMSCustomerUsernameExistException();
                }

                return caRMSCustomer.getCustomerId();

            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new CaRMSCustomerUsernameExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            } catch (CaRMSCustomerPhoneNumberExistException ex) {
                throw new CaRMSCustomerPhoneNumberExistException();
            } catch (CaRMSCustomerEmailExistException ex) {
                throw new CaRMSCustomerEmailExistException();
            } catch (CaRMSCustomerUsernameExistException ex) {
                throw new CaRMSCustomerUsernameExistException();
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public CaRMSCustomer customerLogin(String username, String password) throws CaRMSCustomerNotFoundException, InvalidLoginCredentialException {
        //get the username using JPQL queries
        try {
            Query query = em.createQuery("SELECT c FROM CaRMSCustomer c WHERE c.username = :inUsername");
            query.setParameter("inUsername", username);
            CaRMSCustomer caRMSCustomer = (CaRMSCustomer) query.getSingleResult();

            if (caRMSCustomer != null) {

                if (caRMSCustomer.getPassword().equals(password)) {
                    return caRMSCustomer;
                } else {
                    throw new InvalidLoginCredentialException("Invalid login credential for: " + username);
                }
            } else {
                throw new CaRMSCustomerNotFoundException("CaRMS Customer with username " + username + " not found!");
            }
        } catch (NoResultException ex) {
            throw new CaRMSCustomerNotFoundException("CaRMS Customer with username " + username + " not found!");
        }
    }

    @Override
    public Boolean isUsernameAvailable(String username) {
        Query query = em.createQuery("SELECT c FROM CaRMSCustomer c WHERE c.username = :inUsername");
        query.setParameter("inUsername", username);
        List<CaRMSCustomer> caRMSCustomers = query.getResultList();

        return caRMSCustomers.isEmpty();
    }

    @Override
    public Boolean isPhoneNumberAvailable(String phoneNumber) {
        Query query = em.createQuery("SELECT c FROM CaRMSCustomer c WHERE c.phoneNumber = :inPhoneNumber");
        query.setParameter("inPhoneNumber", phoneNumber);
        List<CaRMSCustomer> caRMSCustomers = query.getResultList();

        return caRMSCustomers.isEmpty();
    }

    @Override
    public Boolean isPassportNumberAvailable(String passportNumber
    ) {
        Query query = em.createQuery("SELECT c FROM CaRMSCustomer c WHERE c.passportNumber = :inPassportNumber");
        query.setParameter("inPassportNumber", passportNumber);
        List<CaRMSCustomer> caRMSCustomers = query.getResultList();

        return caRMSCustomers.isEmpty();
    }

    @Override
    public Boolean isEmailAvailable(String email
    ) {
        Query query = em.createQuery("SELECT c FROM CaRMSCustomer c WHERE c.email = :inEmail");
        query.setParameter("inEmail", email);
        List<CaRMSCustomer> caRMSCustomers = query.getResultList();

        return caRMSCustomers.isEmpty();
    }
    //for InputDataValidationException

    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<CaRMSCustomer>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }

}
