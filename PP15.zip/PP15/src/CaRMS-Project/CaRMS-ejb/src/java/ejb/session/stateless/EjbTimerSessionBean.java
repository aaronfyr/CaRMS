/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.RentalReservation;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.CarStatusEnum;
import util.exception.InputDataValidationException;
import util.exception.NoAllocatableCarClientException;
import util.exception.OutletNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;

/**
 *
 * @author aaronf
 */
@Stateless
public class EjbTimerSessionBean implements EjbTimerSessionBeanRemote, EjbTimerSessionBeanLocal {

    @EJB(name = "RentalRateSessionBeanLocal")
    private RentalRateSessionBeanLocal rentalRateSessionBeanLocal;

    @EJB(name = "CarSessionBeanLocal")
    private CarSessionBeanLocal carSessionBeanLocal;

    @EJB(name = "TransitDriverDispatchRecordSessionBeanLocal")
    private TransitDriverDispatchRecordSessionBeanLocal transitDriverDispatchRecordSessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;


    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public EjbTimerSessionBean() {
    }
    
    @Schedule(hour = "2", minute = "0", second = "0", info = "allocateCarsToCurrentDayReservations")
    @Override
    public void triggerCarAllocation() throws OutletNotFoundException, RentalReservationNotFoundException, NoAllocatableCarClientException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException {
        Date date = new Date();
        allocateCarsToCurrentDayReservations(date);
    }
    
    @Override
    public void allocateCarsToCurrentDayReservations(Date date) throws OutletNotFoundException, RentalReservationNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException {
        
        LocalDateTime startOfDayDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        startOfDayDate.withHour(2).withMinute(0).withSecond(0);
        Date startDate = Date.from(startOfDayDate.atZone(ZoneId.systemDefault()).toInstant());
        LocalDateTime endOfDayDate = startOfDayDate.plusDays(1);
        Date endDate = Date.from(endOfDayDate.atZone(ZoneId.systemDefault()).toInstant());
        
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.startDate >= :inStartDate AND r.startDate <= :inEndDate AND r.isCancelled = FALSE");
        query.setParameter("inStartDate", startDate);
        query.setParameter("inEndDate", endDate);
        List<RentalReservation> rentalReservationsToBeAllocated = query.getResultList();
        List<RentalReservation> rentalReservationsThatRequiresTransit = new ArrayList<>();
        
        for (RentalReservation rentalReservation : rentalReservationsToBeAllocated) {
            boolean isAllocated = false;
            if (rentalReservation.getCarModel() != null) {
                List<Car> cars = carSessionBeanLocal.retrieveCarsByCarModelId(rentalReservation.getCarModel().getCarModelId());
                
                for (Car car : cars) {
                    if ( (car.getCarStatus() == CarStatusEnum.AVAILABLE && car.getRentalReservation() == null)
                            && car.getOutlet().getOutletId().equals(rentalReservation.getPickUpOutlet().getOutletId())) {
                        rentalReservation.setCar(car);
                        car.setRentalReservation(rentalReservation);
                        isAllocated = true;
                        break;
                    }
                }
                if (isAllocated) {
                    continue;
                }
                
                // current outlet has no cars to fulfill the rental reservation
                for (Car car : cars) {
                    if (car.getCarStatus() == CarStatusEnum.AVAILABLE && car.getRentalReservation() == null) {
                        rentalReservation.setCar(car);
                        car.setRentalReservation(rentalReservation);
                        isAllocated = true;
                        rentalReservationsThatRequiresTransit.add(rentalReservation);
                        break;
                    }
                }
                if (isAllocated) {
                    continue;
                }
                
                // then check those currently on rental returning to same outlet
                for (Car car : cars) {
                    if ( (car.getCarStatus() == CarStatusEnum.ON_RENTAL && car.getRentalReservation() != null) // relook at getRentalReservation == null
                            && car.getRentalReservation().getReturnOutlet().getOutletName().equals(rentalReservation.getPickUpOutlet().getOutletName())) {
                        if (car.getRentalReservation().getEndDate().before(rentalReservation.getStartDate())) {
                            rentalReservation.setCar(car);
                            isAllocated = true;
                            break;
                        }
                    }
                }
                if (isAllocated) {
                    continue;
                }
                
                // check those currently on rental returning to a different outlet
                for (Car car : cars) {
                    if ((car.getCarStatus() == CarStatusEnum.ON_RENTAL) && car.getRentalReservation() == null
                            && !car.getRentalReservation().getReturnOutlet().getOutletName().equals(rentalReservation.getPickUpOutlet().getOutletName())) {
                        Date returnDateFromCurrentRental = car.getRentalReservation().getEndDate();
                        LocalDateTime returnDateTimeFromCurrentRental = LocalDateTime.ofInstant(returnDateFromCurrentRental.toInstant(), ZoneId.systemDefault());
                        returnDateTimeFromCurrentRental.plusHours(2);
                        Date transitDateAfterReturnFromPreviousRental = Date.from(returnDateTimeFromCurrentRental.atZone(ZoneId.systemDefault()).toInstant());
                        if (rentalReservation.getStartDate().after(transitDateAfterReturnFromPreviousRental)) {
                            rentalReservation.setCar(car);
                            isAllocated = true;
                            rentalReservationsThatRequiresTransit.add(rentalReservation);
                            break;
                        }
                    }
                }
                if (isAllocated) {
                    continue;
                }
            } else { // rental reservation booked by car category
                List<Car> cars = carSessionBeanLocal.retrieveCarsByCarCategoryId(rentalReservation.getCarCategory().getCarCategoryId());
                for (Car car : cars) {
                    if (car.getCarModel().getCarCategory().getCarCategoryName().equals(
                            rentalReservation.getCarCategory().getCarCategoryName())
                            && car.getRentalReservation() == null
                            && car.getOutlet().getOutletId().equals(rentalReservation.getPickUpOutlet().getOutletId())) {
                        rentalReservation.setCar(car);
                        car.setRentalReservation(rentalReservation);
                        isAllocated = true;
                        break;
                    }
                }
                if (isAllocated) {
                    continue;
                }
                
                // current outlet has no cars to fulfill the current rental reservation
                Long carCategoryId = rentalReservation.getCarCategory().getCarCategoryId();
                List<Car> carsOfSameCategory = carSessionBeanLocal.retrieveCarsByCarCategoryId(carCategoryId);
                for (Car car : carsOfSameCategory) {
                    if ((car.getCarStatus() == CarStatusEnum.AVAILABLE) && car.getRentalReservation() == null) { // already available in outlet
                        rentalReservation.setCar(car);
                        car.setRentalReservation(rentalReservation);
                        isAllocated = true;
                        rentalReservationsThatRequiresTransit.add(rentalReservation);
                        break;
                    }
                }
                if (isAllocated) {
                    continue;
                }
                
                // check returning cars to same outlet
                for (Car car : carsOfSameCategory) {
                    if ((car.getCarStatus() == CarStatusEnum.ON_RENTAL) && car.getRentalReservation().getReturnOutlet().getOutletName()
                            .equals(rentalReservation.getPickUpOutlet().getOutletName())) {
                        if (car.getRentalReservation().getEndDate().before(rentalReservation.getStartDate())) {
                            rentalReservation.setCar(car);
                            isAllocated = true;
                            break;
                        }
                    }
                }
                if (isAllocated) {
                    continue;
                }
                // then check those currently on rental returning to a different outlet
                for (Car car : carsOfSameCategory) {
                    if ((car.getCarStatus() == CarStatusEnum.ON_RENTAL) && !car.getRentalReservation().getReturnOutlet().getOutletName().equals(rentalReservation.getPickUpOutlet().getOutletName())) {
                        Date returnDateFromCurrentRental = car.getRentalReservation().getEndDate();
                        LocalDateTime returnDateTimeFromCurrentRental = LocalDateTime.ofInstant(returnDateFromCurrentRental.toInstant(), ZoneId.systemDefault());
                        returnDateTimeFromCurrentRental.plusHours(2);
                        Date transitDateAfterReturnFromPreviousRental = Date.from(returnDateTimeFromCurrentRental.atZone(ZoneId.systemDefault()).toInstant());
                        if (rentalReservation.getStartDate().after(transitDateAfterReturnFromPreviousRental)) {
                            rentalReservation.setCar(car);
                            isAllocated = true;
                            rentalReservationsThatRequiresTransit.add(rentalReservation);
                            break;
                        }
                    }
                }
                if (isAllocated) {
                    continue;
                }
            }
        }
        generateTransitDriverDispatchRecords(rentalReservationsThatRequiresTransit);
    }
    
    @Override
    public void generateTransitDriverDispatchRecords(List<RentalReservation> rentalReservationsToBeAllocated) throws RentalReservationNotFoundException, OutletNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException {
        try {
            for (RentalReservation rentalReservation : rentalReservationsToBeAllocated) {
                Date pickUpDate = rentalReservation.getStartDate();
                LocalDateTime pickUpDateTime = LocalDateTime.ofInstant(pickUpDate.toInstant(), ZoneId.systemDefault());
                LocalDateTime transitDateTime = pickUpDateTime.minusHours(2);
                Date transitDate = Date.from(transitDateTime.atZone(ZoneId.systemDefault()).toInstant());
                
                transitDriverDispatchRecordSessionBeanLocal.createNewTransitDriverDispatchRecord(rentalReservation.getPickUpOutlet().getOutletId(), rentalReservation.getRentalReservationId(), transitDate);
            }
        } catch (RentalReservationNotFoundException | OutletNotFoundException | TransitDriverDispatchRecordAlreadyRegisteredWithOutletException | InputDataValidationException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
