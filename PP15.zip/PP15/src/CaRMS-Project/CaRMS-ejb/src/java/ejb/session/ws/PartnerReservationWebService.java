/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.ws;

import ejb.session.stateless.CarCategorySessionBeanLocal;
import ejb.session.stateless.CarModelSessionBeanLocal;
import ejb.session.stateless.OutletSessionBeanLocal;
import ejb.session.stateless.PartnerCustomerSessionBeanLocal;
import ejb.session.stateless.PartnerSessionBeanLocal;
import ejb.session.stateless.RentalRateSessionBeanLocal;
import ejb.session.stateless.RentalReservationSessionBeanLocal;
import entity.CarCategory;
import entity.CarModel;
import entity.Outlet;
import entity.Partner;
import entity.PartnerCustomer;
import entity.RentalRate;
import entity.RentalReservation;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelNotFoundException;
import util.exception.CustomerNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.NoAvailableRentalRateException;
import util.exception.OutletNotFoundException;
import util.exception.PartnerCustomerAlreadyRegisteredWithPartnerException;
import util.exception.PartnerCustomerEmailExistException;
import util.exception.PartnerNotFoundException;
import util.exception.PartnerUsernameExistException;
import util.exception.RentalRateNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author jeantay
 */
@WebService(serviceName = "PartnerReservationWebService")
@Stateless()
public class PartnerReservationWebService {

    @EJB(name = "RentalRateSessionBeanLocal")
    private RentalRateSessionBeanLocal rentalRateSessionBeanLocal;

    @EJB(name = "CarCategorySessionBeanLocal")
    private CarCategorySessionBeanLocal carCategorySessionBeanLocal;
    
    @EJB(name = "CarModelSessionBeanLocal")
    private CarModelSessionBeanLocal carModelSessionBeanLocal;

    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;

    @EJB(name = "PartnerSessionBeanLocal")
    private PartnerSessionBeanLocal partnerSessionBeanLocal;

    @EJB(name = "PartnerCustomerSessionBeanLocal")
    private PartnerCustomerSessionBeanLocal partnerCustomerSessionBeanLocal;

    @EJB(name = "RentalReservationSessionBeanLocal")
    private RentalReservationSessionBeanLocal rentalReservationSessionBeanLocal;
    
    
    
    //Helper Methods
    //PARTNERCUSTOMER METHODS 
    @WebMethod(operationName = "createNewPartnerCustomer")
    public Long createNewPartnerCustomer(
            @WebParam(name = "newPartnerCustomer") PartnerCustomer newPartnerCustomer,
            @WebParam(name = "partnerId") Long partnerId) 
            throws PartnerNotFoundException, PartnerCustomerAlreadyRegisteredWithPartnerException, PartnerCustomerEmailExistException, UnknownPersistenceException, InputDataValidationException {
        return partnerCustomerSessionBeanLocal.createNewPartnerCustomer(newPartnerCustomer, partnerId);
    }
    
    //PARTNER METHODS
    
    @WebMethod(operationName = "createNewPartner")
    public Long createNewPartner(
            @WebParam(name = "newPartner") Partner newPartner) 
            throws PartnerUsernameExistException, UnknownPersistenceException, InputDataValidationException {
        return partnerSessionBeanLocal.createNewPartner(newPartner);
    }
    
    @WebMethod(operationName = "retrievePartnerByPartnerId")
    public Partner retrievePartnerByPartnerId(
            @WebParam(name = "partnerId") Long partnerId) 
            throws PartnerNotFoundException {
        return partnerSessionBeanLocal.retrievePartnerByPartnerId(partnerId);
    }
    
    //OUTLET METHODS
    @WebMethod(operationName = "retrieveOutletByOutletId")
    public Outlet retrieveOutletByOutletId(
            @WebParam(name = "outletId") Long outletId) 
            throws OutletNotFoundException {
        return outletSessionBeanLocal.retrieveOutletByOutletId(outletId);
    }
    
    @WebMethod(operationName = "retrieveAllOutlets")
    public List<Outlet> retrieveAllOutlets(){
        return outletSessionBeanLocal.retrieveAllOutlets();
    }

    //CAR CATEGORY METHODS
    @WebMethod(operationName = "retrieveCarCategoryByCarCategoryId")
    public CarCategory retrieveCarCategoryByCarCategoryId(
            @WebParam(name = "carCategoryId") Long carCategoryId) 
            throws CarCategoryNotFoundException {
        return carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId);

    }
    
    @WebMethod(operationName = "calculateTotalRentalPrice")
    public BigDecimal calculateTotalRentalPrice(
            @WebParam(name = "carCategoryId") Long carCategoryId,
            @WebParam(name = "pickUpDateTime") Date pickUpDateTime,
            @WebParam(name = "returnDateTime") Date returnDateTime) 
            throws NoAvailableRentalRateException {
        return carCategorySessionBeanLocal.calculateTotalRentalPrice(carCategoryId, pickUpDateTime, returnDateTime);
    }   
    
    @WebMethod(operationName = "retrieveAllCarCategories")
    public List<CarCategory> retrieveAllCarCategories(){
        return carCategorySessionBeanLocal.retrieveAllCarCategories();
    }
    
    @WebMethod(operationName = "retrieveRentalRatesUsed")
    public List<RentalRate> retrieveRentalRatesUsed(
            @WebParam(name = "carCategoryId") Long carCategoryId,
            @WebParam(name = "pickUpDateTime") Date pickUpDateTime,
            @WebParam(name = "returnDateTime") Date returnDateTime) 
            throws NoAvailableRentalRateException {
        return carCategorySessionBeanLocal.retrieveRentalRatesUsed(carCategoryId, pickUpDateTime, returnDateTime); 
    }

    

    //CAR MODEL METHODS 
    @WebMethod(operationName = "retrieveCarModelByCarModelId")
    public CarModel retrieveCarModelByCarModelId(
            @WebParam(name = "carModelId") Long carModelId) 
            throws CarModelNotFoundException {
        return carModelSessionBeanLocal.retrieveCarModelByCarModelId(carModelId);
    }
    
    @WebMethod(operationName = "retrieveAllCarModels")
    public List<CarModel> retrieveAllCarModels(){
        return retrieveAllCarModels();
    }

    
    //RENTALRESERVATION METHODS
    @WebMethod(operationName = "retrieveAllRentalReservations")
    public List<RentalReservation> retrieveAllRentalReservations() {
        return rentalReservationSessionBeanLocal.retrieveAllRentalReservations();
    }
    
    
    //1: Partner Login
    @WebMethod(operationName = "partnerLogin")
    public Long partnerLogin(
            @WebParam(name = "username") String username, 
            @WebParam(name = "password") String password) 
            throws PartnerNotFoundException, InvalidLoginCredentialException {
                System.out.println("********** PartnerReservationWebService: You are login as " + username + " **********");
        return partnerSessionBeanLocal.partnerLogin(username, password); 
    }
    
    //2: Partner Search Car
    //2a Search by category
    @WebMethod(operationName = "partnerSearchCarCategory")
    //Search by category
    public Boolean areThereAvailableCarsByCarCategory(
            @WebParam(name = "carCategoryId") Long carCategoryId, 
            @WebParam(name = "pickUpDateTime") Date pickUpDateTime, 
            @WebParam(name = "returnDateTime") Date returnDateTime, 
            @WebParam(name = "pickUpOutletId") Long pickUpOutletId, 
            @WebParam(name = "returnOutletId") Long returnOutletId) 
            throws NoAvailableRentalRateException, CarCategoryNotFoundException, OutletNotFoundException {
        System.out.println("********** PartnerReservationWebService.areThereAvailableCarsByCarCategory() **********");
              
        return rentalReservationSessionBeanLocal.areThereAvailableCarsByCarCategory(carCategoryId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId);
    }
    
    //2b Search by model    
    @WebMethod(operationName = "partnerSearchCarModel")
    public Boolean areThereAvailableCarsByCarModel(
            @WebParam(name = "carModelId") Long carModelId, 
            @WebParam(name = "pickUpDateTime") Date pickUpDateTime, 
            @WebParam(name = "returnDateTime") Date returnDateTime, 
            @WebParam(name = "pickUpOutletId") Long pickUpOutletId, 
            @WebParam(name = "returnOutletId") Long returnOutletId) 
            throws CarCategoryNotFoundException, OutletNotFoundException, CarModelNotFoundException {
        System.out.println("********** PartnerReservationWebService.areThereAvailableCarsByCarModel() **********");
        return rentalReservationSessionBeanLocal.areThereAvailableCarsByCarModel(carModelId, pickUpDateTime, returnDateTime, pickUpOutletId, returnOutletId);
    }
    
    
    //3: Partner Reserve Car
    //3a: Reserve by Car Category
    //takes in the user login, check if its correct
    @WebMethod(operationName = "partnerCreateNewRentalReservationUsingCarCategory")
    public Long partnerCreateNewRentalReservationUsingCarCategory(
            @WebParam(name = "newRentalReservation")RentalReservation newRentalReservation,
            @WebParam(name = "partnerId") Long partnerId,
            @WebParam(name = "customerId")Long customerId,
            @WebParam(name = "carCategoryId")Long carCategoryId,
            @WebParam(name = "pickupOutletId")Long pickupOutletId, 
            @WebParam(name = "returnOutletId")Long returnOutletId, 
            @WebParam(name = "rentalRatesUsed") List<RentalRate> rentalRatesUsed) 
            throws InvalidLoginCredentialException, CustomerNotFoundException, PartnerNotFoundException, CarCategoryNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
        //check that partner is login
        System.out.println("********** PartnerReservationWebService.partnerCreateNewRentalReservationUsingCarCategory() **********");
        //then reserve
        return rentalReservationSessionBeanLocal.partnerCreateNewRentalReservationUsingCarCategory(newRentalReservation, customerId, partnerId, carCategoryId, pickupOutletId, returnOutletId, rentalRatesUsed);
    }

    
    //3b: Reserve By Car Model
    //takes in the user login, check if that is correct...
    @WebMethod(operationName = "partnerCreateNewRentalReservationUsingCarModel")
    public Long partnerCreateNewRentalReservationUsingCarModel(
            @WebParam(name = "newRentalReservation")RentalReservation newRentalReservation,
            @WebParam(name = "customerId")Long customerId,
            @WebParam(name = "carModelId")Long carModelId, 
            @WebParam(name = "pickupOutletId")Long pickupOutletId, 
            @WebParam(name = "returnOutletId")Long returnOutletId, 
            @WebParam(name = "rentalRatesUsed") List<RentalRate> rentalRatesUsed) 
            throws InvalidLoginCredentialException, CustomerNotFoundException, PartnerNotFoundException, CarModelNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
            //check that partner is login
        System.out.println("********** PartnerReservationWebService.partnerCreateNewRentalReservationUsingCarCategory() **********");

        return rentalReservationSessionBeanLocal.customerCreateNewRentalReservationUsingCarModel(newRentalReservation, customerId, carModelId, pickupOutletId, returnOutletId, rentalRatesUsed);
            
        
    }

   
    //4: Partner Cancel Reservation
    @WebMethod(operationName = "cancelReservation")
    public BigDecimal cancelReservation(
            @WebParam(name = "rentalReservationId") Long rentalReservationId)
            throws RentalReservationNotFoundException {
        System.out.println("********** PartnerReservationWebService.cancelReservation() **********");
        return rentalReservationSessionBeanLocal.cancelReservation(rentalReservationId);
    }


    //5: Partner View Reservation Details
    @WebMethod(operationName = "retrievePartnerRentalReservationsById")
    public RentalReservation retrieveRentalReservationByRentalReservationId(
            @WebParam(name = "rentalReservationId") Long rentalReservationId) 
            throws RentalReservationNotFoundException {
        System.out.println("********** PartnerReservationWebService.retrieveRentalReservationByRentalReservationId() **********");
        return rentalReservationSessionBeanLocal.retrieveRentalReservationByRentalReservationId(rentalReservationId);
    }
    
    //6: View All Partner Reservation
    @WebMethod(operationName = "retrievePartnerRentalReservations")
    public List<RentalReservation> retrievePartnerRentalReservations(
            @WebParam(name = "partnerId") Long partnerId){
        System.out.println("********** PartnerReservationWebService.retrievePartnerRentalReservations() **********"); 
        return rentalReservationSessionBeanLocal.retrievePartnerRentalReservations(partnerId);
    }
   
   
}
