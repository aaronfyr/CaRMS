/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.CarCategory;
import entity.CarModel;
import entity.Customer;
import entity.Outlet;
import entity.Partner;
import entity.RentalRate;
import entity.RentalReservation;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.enumeration.CarStatusEnum;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarHasNotTransitToOutletException;
import util.exception.CarIsNotPickedUpException;
import util.exception.CarIsPickedUpException;
import util.exception.CarModelNotFoundException;
import util.exception.CustomerNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.OutletNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.RentalRateNotFoundException;
import util.exception.RentalReservationCompletedException;
import util.exception.RentalReservationIsCancelledException;
import util.exception.RentalReservationNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class RentalReservationSessionBean implements RentalReservationSessionBeanRemote, RentalReservationSessionBeanLocal {

    @EJB(name = "CarSessionBeanLocal")
    private CarSessionBeanLocal carSessionBeanLocal;

    @EJB(name = "RentalRateSessionBeanLocal")
    private RentalRateSessionBeanLocal rentalRateSessionBeanLocal;

    @EJB(name = "PartnerSessionBeanLocal")
    private PartnerSessionBeanLocal partnerSessionBeanLocal;

    @EJB(name = "CustomerSessionBeanLocal")
    private CustomerSessionBeanLocal customerSessionBeanLocal;

    @EJB(name = "CarCategorySessionBeanLocal")
    private CarCategorySessionBeanLocal carCategorySessionBeanLocal;

    @EJB(name = "CarModelSessionBeanLocal")
    private CarModelSessionBeanLocal carModelSessionBeanLocal;

    @EJB(name = "OutletSessionBeanLocal")
    private OutletSessionBeanLocal outletSessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;
    private static final BigDecimal AT_LEAST_SEVEN_DAYS_LESS_THAN_FOURTEEN_DAYS_PENALTY = new BigDecimal(0.2);
    private static final BigDecimal AT_LEAST_THREE_DAYS_LESS_THAN_SEVEN_DAYS_PENALTY = new BigDecimal(0.5);
    private static final BigDecimal LESS_THAN_THREE_DAYS_PENALTY = new BigDecimal(0.7);

    public RentalReservationSessionBean() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public Long customerCreateNewRentalReservationUsingCarCategory(RentalReservation newRentalReservation, Long customerId, Long carCategoryId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, CarCategoryNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);

        if (constraintViolations.isEmpty()) {
            try {
                Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerId(customerId);
                CarCategory carCategory = carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId);
                Outlet pickupOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(pickupOutletId);
                Outlet returnOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(returnOutletId);
                newRentalReservation.setCustomer(customer);
                customerSessionBeanLocal.addRentalReservationToCustomer(customer, newRentalReservation);
                newRentalReservation.setCarCategory(carCategory);
                newRentalReservation.setPickUpOutlet(pickupOutlet);
                newRentalReservation.setReturnOutlet(returnOutlet);
                for (RentalRate rentalRate : rentalRatesUsed) {
                    RentalRate currentRentalRate = rentalRateSessionBeanLocal.retrieveRentalRateByRentalRateId(rentalRate.getRentalRateId());
                    currentRentalRate.getRentalReservations().add(newRentalReservation);
                }
                em.persist(newRentalReservation);
                em.flush();
                return newRentalReservation.getRentalReservationId();
            } catch (CustomerNotFoundException ex) {
                throw new CustomerNotFoundException("Customer ID: " + customerId + " does not exist!");
            } catch (CarCategoryNotFoundException ex) {
                throw new CarCategoryNotFoundException("Car Category ID: " + carCategoryId + " does not exist!");
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Either one of both of the Outlet IDs: " + pickupOutletId + " and " + returnOutletId + " does not exist!");
            } catch (RentalRateNotFoundException ex) {
                throw new RentalRateNotFoundException("One of the Rental Rate ID is not found!");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        // throw new RentalReservationNameExistException();
                        throw new UnknownPersistenceException(ex.getMessage());
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }

        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public Long customerCreateNewRentalReservationUsingCarModel(RentalReservation newRentalReservation, Long customerId, Long carModelId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, CarModelNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);

        if (constraintViolations.isEmpty()) {
            try {
                Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerId(customerId);
                CarModel carModel = carModelSessionBeanLocal.retrieveCarModelByCarModelId(carModelId);
                Outlet pickupOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(pickupOutletId);
                Outlet returnOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(returnOutletId);
                newRentalReservation.setCustomer(customer);
                customerSessionBeanLocal.addRentalReservationToCustomer(customer, newRentalReservation);
                newRentalReservation.setCarModel(carModel);
                newRentalReservation.setCarCategory(carModel.getCarCategory());
                newRentalReservation.setPickUpOutlet(pickupOutlet);
                newRentalReservation.setReturnOutlet(returnOutlet);
                for (RentalRate rentalRate : rentalRatesUsed) {
                    RentalRate currentRentalRate = rentalRateSessionBeanLocal.retrieveRentalRateByRentalRateId(rentalRate.getRentalRateId());
                    currentRentalRate.getRentalReservations().add(newRentalReservation);
                }
                em.persist(newRentalReservation);
                em.flush();
                return newRentalReservation.getRentalReservationId();
            } catch (CustomerNotFoundException ex) {
                throw new CustomerNotFoundException("Customer ID: " + customerId + " does not exist!");
            } catch (CarModelNotFoundException ex) {
                throw new CarModelNotFoundException("Car Model ID: " + carModelId + " does not exist!");
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Either one of both of the Outlet IDs: " + pickupOutletId + " and " + returnOutletId + " does not exist!");
            } catch (RentalRateNotFoundException ex) {
                throw new RentalRateNotFoundException("One of the Rental Rate ID is not found!");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        // throw new RentalReservationNameExistException();
                        throw new UnknownPersistenceException(ex.getMessage());
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }

        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public Long partnerCreateNewRentalReservationUsingCarCategory(RentalReservation newRentalReservation, Long customerId, Long partnerId, Long carCategoryId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, PartnerNotFoundException, CarCategoryNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);

        if (constraintViolations.isEmpty()) {
            try {
                Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerId(customerId);
                Partner partner = partnerSessionBeanLocal.retrievePartnerByPartnerId(partnerId);
                CarCategory carCategory = carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId);
                Outlet pickupOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(pickupOutletId);
                Outlet returnOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(returnOutletId);
                newRentalReservation.setCustomer(customer);
                newRentalReservation.setPartner(partner);
                customerSessionBeanLocal.addRentalReservationToCustomer(customer, newRentalReservation);
                partnerSessionBeanLocal.addRentalReservationToPartner(partner, newRentalReservation);
                newRentalReservation.setCarCategory(carCategory);
                newRentalReservation.setPickUpOutlet(pickupOutlet);
                newRentalReservation.setReturnOutlet(returnOutlet);
                for (RentalRate rentalRate : rentalRatesUsed) {
                    RentalRate currentRentalRate = rentalRateSessionBeanLocal.retrieveRentalRateByRentalRateId(rentalRate.getRentalRateId());
                    currentRentalRate.getRentalReservations().add(newRentalReservation);
                }
                em.persist(newRentalReservation);
                em.flush();
                return newRentalReservation.getRentalReservationId();
            } catch (CustomerNotFoundException ex) {
                throw new CustomerNotFoundException("Customer ID: " + customerId + " does not exist!");
            } catch (PartnerNotFoundException ex) {
                throw new CustomerNotFoundException("Partner ID: " + partnerId + " does not exist!");
            } catch (CarCategoryNotFoundException ex) {
                throw new CarCategoryNotFoundException("Car Category ID: " + carCategoryId + " does not exist!");
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Either one of both of the Outlet IDs: " + pickupOutletId + " and " + returnOutletId + " does not exist!");
            } catch (RentalRateNotFoundException ex) {
                throw new RentalRateNotFoundException("One of the Rental Rate ID is not found!");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        // throw new RentalReservationNameExistException();
                        throw new UnknownPersistenceException(ex.getMessage());
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }

        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public Long partnerCreateNewRentalReservationUsingCarModel(RentalReservation newRentalReservation, Long customerId, Long partnerId, Long carModelId, Long pickupOutletId, Long returnOutletId, List<RentalRate> rentalRatesUsed) throws CustomerNotFoundException, PartnerNotFoundException, CarModelNotFoundException, OutletNotFoundException, RentalRateNotFoundException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<RentalReservation>> constraintViolations = validator.validate(newRentalReservation);

        if (constraintViolations.isEmpty()) {
            try {
                Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerId(customerId);
                Partner partner = partnerSessionBeanLocal.retrievePartnerByPartnerId(partnerId);
                CarModel carModel = carModelSessionBeanLocal.retrieveCarModelByCarModelId(carModelId);
                Outlet pickupOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(pickupOutletId);
                Outlet returnOutlet = outletSessionBeanLocal.retrieveOutletByOutletId(returnOutletId);
                newRentalReservation.setCustomer(customer);
                newRentalReservation.setPartner(partner);
                customerSessionBeanLocal.addRentalReservationToCustomer(customer, newRentalReservation);
                partnerSessionBeanLocal.addRentalReservationToPartner(partner, newRentalReservation);
                newRentalReservation.setCarModel(carModel);
                newRentalReservation.setCarCategory(carModel.getCarCategory());
                newRentalReservation.setPickUpOutlet(pickupOutlet);
                newRentalReservation.setReturnOutlet(returnOutlet);
                for (RentalRate rentalRate : rentalRatesUsed) {
                    RentalRate currentRentalRate = rentalRateSessionBeanLocal.retrieveRentalRateByRentalRateId(rentalRate.getRentalRateId());
                    currentRentalRate.getRentalReservations().add(newRentalReservation);
                }
                em.persist(newRentalReservation);
                em.flush();
                return newRentalReservation.getRentalReservationId();
            } catch (CustomerNotFoundException ex) {
                throw new CustomerNotFoundException("Customer ID: " + customerId + " does not exist!");
            } catch (PartnerNotFoundException ex) {
                throw new CustomerNotFoundException("Partner ID: " + partnerId + " does not exist!");
            } catch (CarModelNotFoundException ex) {
                throw new CarModelNotFoundException("Car Model ID: " + carModelId + " does not exist!");
            } catch (OutletNotFoundException ex) {
                throw new OutletNotFoundException("Either one of both of the Outlet IDs: " + pickupOutletId + " and " + returnOutletId + " does not exist!");
            } catch (RentalRateNotFoundException ex) {
                throw new RentalRateNotFoundException("One of the Rental Rate ID is not found!");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        // throw new RentalReservationNameExistException();
                        throw new UnknownPersistenceException(ex.getMessage());
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }

        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }

    @Override
    public RentalReservation retrieveRentalReservationByRentalReservationId(Long rentalReservationId) throws RentalReservationNotFoundException {
        RentalReservation rentalReservation = em.find(RentalReservation.class, rentalReservationId);

        if (rentalReservation != null) {
            return rentalReservation;
        } else {
            throw new RentalReservationNotFoundException("Rental Reservation ID " + rentalReservationId + " does not exist!");
        }
    }

    @Override
    public List<RentalReservation> retrieveCustomerRentalReservations(Long customerId) {
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.customer.customerId = :inCustomerId");
        query.setParameter("inCustomerId", customerId);
        return query.getResultList();
    }

    @Override
    public List<RentalReservation> retrievePartnerRentalReservations(Long partnerId) {
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.partner.partnerId = :inPartnerId");
        query.setParameter("inPartnerId", partnerId);
        return query.getResultList();
    }

    @Override
    public List<RentalReservation> retrieveAllRentalReservations() {
        Query query = em.createQuery("SELECT r FROM RentalReservation r");
        return query.getResultList();
    }

    @Override
    public List<RentalReservation> retrieveCustomerRentalReservationsByPickupOutletId(Long outletId) {
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.isPickedUp = FALSE AND r.isCompleted = FALSE AND r.car IS NOT NULL AND r.pickUpOutlet.outletId = :inOutletId");
        query.setParameter("inOutletId", outletId);
        return query.getResultList();
    }

    @Override
    public List<RentalReservation> retrieveCustomerRentalReservationsByReturnOutletId(Long outletId) {
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.isPickedUp = TRUE AND r.isCompleted = FALSE AND r.car IS NOT NULL AND r.returnOutlet.outletId = :inOutletId");
        query.setParameter("inOutletId", outletId);
        return query.getResultList();
    }

    @Override
    public void pickUpCar(Long rentalReservationId) throws RentalReservationNotFoundException, CarHasNotTransitToOutletException, RentalReservationCompletedException, CarIsPickedUpException, RentalReservationIsCancelledException {
        try {
            RentalReservation rentalReservation = retrieveRentalReservationByRentalReservationId(rentalReservationId);
            if (!rentalReservation.getIsCompleted()) {
                if (!rentalReservation.getIsCancelled()) {
                    if (!rentalReservation.getIsPickedUp()) {
                        if ((rentalReservation.getTransitDriverDispatchRecord() != null && rentalReservation.getTransitDriverDispatchRecord().getIsCompleted())
                                || rentalReservation.getTransitDriverDispatchRecord() == null) {
                            Outlet pickUpOutlet = rentalReservation.getPickUpOutlet();
                            Car car = rentalReservation.getCar();
                            pickUpOutlet.getCars().remove(car);
                            car.setOutlet(null);
                            car.setCarStatus(CarStatusEnum.ON_RENTAL);
                            car.setRentalReservation(rentalReservation);
                            rentalReservation.setIsPaid(true);
                            rentalReservation.setIsPickedUp(true);
                        } else {
                            throw new CarHasNotTransitToOutletException();
                        }
                    } else {
                        throw new CarIsPickedUpException();
                    }
                } else {
                    throw new RentalReservationIsCancelledException();
                }
            } else {
                throw new RentalReservationCompletedException();
            }
        } catch (RentalReservationNotFoundException ex) {
            throw new RentalReservationNotFoundException("Rental Reservation ID: " + rentalReservationId + " not found!");
        } catch (CarHasNotTransitToOutletException ex) {
            throw new CarHasNotTransitToOutletException("Rental Reservation ID: " + rentalReservationId + " must have completed transit driver dispatch record! Please wait for the Operations Manager to update transit as completed!");
        } catch (RentalReservationCompletedException ex) {
            throw new RentalReservationCompletedException("Rental Reservation ID: " + rentalReservationId + " has already been completed and car has been returned! Please try another reservation!");
        } catch (CarIsPickedUpException ex) {
            throw new CarIsPickedUpException("Rental Reservation ID: " + rentalReservationId + "'s car has been picked up! You might have entered the wrong reservation ID!");
        } catch (RentalReservationIsCancelledException ex) {
            throw new RentalReservationIsCancelledException("Rental Reservation ID: " + rentalReservationId + " was cancelled! Car unable to be pick up! You might have entered the wrong reservation ID!");
        }
    }

    @Override
    public void returnCar(Long rentalReservationId) throws CarAlreadyExistInOutletException, RentalReservationNotFoundException, RentalReservationCompletedException, CarIsNotPickedUpException, RentalReservationIsCancelledException, RentalRateNotFoundException {
        try {
            RentalReservation rentalReservation = retrieveRentalReservationByRentalReservationId(rentalReservationId);
            if (!rentalReservation.getIsCancelled()) {
                if (rentalReservation.getIsPickedUp()) {
                    if (!rentalReservation.getIsCompleted()) {
                        Outlet returnOutlet = rentalReservation.getReturnOutlet();
                        Car car = rentalReservation.getCar();
                        car.setCarStatus(CarStatusEnum.AVAILABLE);
                        car.setOutlet(returnOutlet);
                        car.setRentalReservation(null);
                        outletSessionBeanLocal.addCarToOutlet(returnOutlet, car);
                        List<Long> rentalRateIds = new ArrayList<>();
                        for (RentalRate rentalRate : rentalReservation.getRentalRates()) {
                            rentalRateIds.add(rentalRate.getRentalRateId());
                        }
                        
                        for (Long rentalRateId : rentalRateIds) {
                            RentalRate currentRentalRate = rentalRateSessionBeanLocal.retrieveRentalRateByRentalRateId(rentalRateId);
                            rentalReservation.getRentalRates().remove(currentRentalRate);
                            currentRentalRate.getRentalReservations().remove(rentalReservation);
                        }
                        rentalReservation.setIsCompleted(true);
                    } else {
                        throw new RentalReservationCompletedException();
                    }
                } else {
                    throw new CarIsNotPickedUpException();
                }
            } else {
                throw new RentalReservationIsCancelledException();
            }
        } catch (CarAlreadyExistInOutletException ex) {
            throw new CarAlreadyExistInOutletException("Car already exists in outlet");
        } catch (RentalReservationNotFoundException ex) {
            throw new RentalReservationNotFoundException("Rental Reservation ID: " + rentalReservationId + " not found!");
        } catch (RentalReservationCompletedException ex) {
            throw new RentalReservationCompletedException("Rental Reservation ID: " + rentalReservationId + " has already been completed and car has been returned! Please try another reservation!");
        } catch (CarIsNotPickedUpException ex) {
            throw new CarIsNotPickedUpException("Rental Reservation ID: " + rentalReservationId + "'s car has not been picked up! You might have entered the wrong reservation ID!");
        } catch (RentalReservationIsCancelledException ex) {
            throw new RentalReservationIsCancelledException("Rental Reservation ID: " + rentalReservationId + " was cancelled! Car unable to be returned! You might have entered the wrong reservation ID!");
        } catch (RentalRateNotFoundException ex) {
            throw new RentalRateNotFoundException("Rental Rate was not found!");
        }
    }

    @Override
    public BigDecimal cancelReservation(Long rentalReservationId) throws RentalReservationNotFoundException {
        try {
            RentalReservation rentalReservation = retrieveRentalReservationByRentalReservationId(rentalReservationId);
            rentalReservation.setIsCancelled(true);
            // convert Date to LocalDateTime with system's timezone
            LocalDateTime startDateLocalDateTime = rentalReservation.getStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            LocalDateTime todayLocalDateTime = new Date().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            Long noOfDaysBeforeReservation = ChronoUnit.DAYS.between(todayLocalDateTime, startDateLocalDateTime);
            BigDecimal rentalPrice = rentalReservation.getRentalPrice();
            BigDecimal penalty = new BigDecimal(0);

            if (noOfDaysBeforeReservation >= 14) {
                penalty = new BigDecimal(0);
            } else if (noOfDaysBeforeReservation >= 7 && noOfDaysBeforeReservation < 14) {
                penalty = rentalPrice.multiply(AT_LEAST_SEVEN_DAYS_LESS_THAN_FOURTEEN_DAYS_PENALTY);
            } else if (noOfDaysBeforeReservation >= 3 && noOfDaysBeforeReservation < 7) {
                penalty = rentalPrice.multiply(AT_LEAST_THREE_DAYS_LESS_THAN_SEVEN_DAYS_PENALTY);
            } else if (noOfDaysBeforeReservation < 3) {
                penalty = rentalPrice.multiply(LESS_THAN_THREE_DAYS_PENALTY);
            }

            return penalty;

        } catch (RentalReservationNotFoundException ex) {
            throw new RentalReservationNotFoundException("Rental Reservation ID: " + rentalReservationId + " not found!");
        }
    }

    // HELP TO SEE IF THERE'S AVAILABLE CARS FROM A CAR CATEGORY FOR RENTAL BY REMOVING RENTAL RESERVATIONS THAT CLASHES WITH PICKUP DATE AND RETURN DATE
    @Override
    public Boolean areThereAvailableCarsByCarCategory(Long carCategoryId, Date pickUpDateTime,
             Date returnDateTime, Long pickUpOutletId,
             Long returnOutletId) throws CarCategoryNotFoundException, OutletNotFoundException {
        List<RentalReservation> conflictRentalReservations = new ArrayList<>();

        // Check for availability for the SAME A.return outlet and B.pickup outlet
        // Thought process example:
        // Current Booking is 15/02/2022 00:00 to 16/02/2022 00:00
        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.carCategory.carCategoryId = :inCategoryId AND r.startDate <= :inReturnDate AND r.endDate > :inPickUpDate AND r.returnOutlet.outletId = :inPickUpOutletId AND r.isCancelled = FALSE");
        query.setParameter("inCategoryId", carCategoryId);
        query.setParameter("inPickUpDate", pickUpDateTime);
        query.setParameter("inReturnDate", returnDateTime);
        query.setParameter("inPickUpOutletId", pickUpOutletId);
        conflictRentalReservations.addAll(query.getResultList());

        // Check for availability for the DIFFERENT A.return outlet and B.pickup outlet
        // Thought process example:
        // Current Booking is 15/02/2022 00:00 to 16/02/2022 00:00
        // Earliest Next Booking is 16/02/2022 02:00 to 18/02/2022 00:00 due to transit
        LocalDateTime pickUpDate = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
        LocalDateTime transitDate = pickUpDate.minusHours(2);
        Date transitDateTime = Date.from(transitDate.atZone(ZoneId.systemDefault()).toInstant());

        query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.carCategory.carCategoryId = :inCategoryId AND r.startDate <= :inReturnDate AND r.endDate > :inTransitDate AND r.returnOutlet.outletId <> :inPickUpOutletId AND r.isCancelled = FALSE");
        query.setParameter("inCategoryId", carCategoryId);
        query.setParameter("inReturnDate", returnDateTime);
        query.setParameter("inTransitDate", transitDateTime);
        query.setParameter("inPickUpOutletId", pickUpOutletId);
        conflictRentalReservations.addAll(query.getResultList());
        
//        // retrieve all cars belonging to car category
        CarCategory carCategory = carCategorySessionBeanLocal.retrieveCarCategoryByCarCategoryId(carCategoryId);
        int carsBelongingToCarCategory = 0;
        for (CarModel carModel : carCategory.getCarModels()) {
            for (Car car : carModel.getCars()) {
                if (car.getCarStatus() != CarStatusEnum.REPAIR) {
                    carsBelongingToCarCategory++;
                }
            }
        }
        System.out.println("Total cars : " + carsBelongingToCarCategory);
        System.out.println("Cars in use : " + conflictRentalReservations.size());

        return carsBelongingToCarCategory > conflictRentalReservations.size();
    }

    @Override
    public Boolean areThereAvailableCarsByCarModel(Long carModelId, Date pickUpDateTime,
             Date returnDateTime, Long pickUpOutletId,
             Long returnOutletId) throws CarCategoryNotFoundException, OutletNotFoundException, CarModelNotFoundException {
        List<RentalReservation> conflictRentalReservations = new ArrayList<>();

        Query query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.carModel.carModelId = :inCarModelId AND r.startDate <= :inReturnDate AND r.endDate > :inPickUpDate AND r.returnOutlet.outletId = :inPickUpOutletId AND r.isCancelled = FALSE");
        query.setParameter("inCarModelId", carModelId);
        query.setParameter("inPickUpDate", pickUpDateTime);
        query.setParameter("inReturnDate", returnDateTime);
        query.setParameter("inPickUpOutletId", pickUpOutletId);
        conflictRentalReservations.addAll(query.getResultList());

        LocalDateTime pickUpDate = LocalDateTime.ofInstant(pickUpDateTime.toInstant(), ZoneId.systemDefault());
        LocalDateTime transitDate = pickUpDate.minusHours(2);
        Date transitDateTime = Date.from(transitDate.atZone(ZoneId.systemDefault()).toInstant());

        query = em.createQuery("SELECT r FROM RentalReservation r WHERE r.carModel.carModelId = :inCarModelId AND r.startDate <= :inReturnDate AND r.endDate > :inTransitDate AND r.returnOutlet.outletId <> :inPickUpOutletId AND r.isCancelled = FALSE");
        query.setParameter("inCarModelId", carModelId);
        query.setParameter("inReturnDate", returnDateTime);
        query.setParameter("inTransitDate", transitDateTime);
        query.setParameter("inPickUpOutletId", pickUpOutletId);
        conflictRentalReservations.addAll(query.getResultList());

        CarModel carModel = carModelSessionBeanLocal.retrieveCarModelByCarModelId(carModelId);
        int carsBelongingToCarModel = 0;
        for (Car car : carModel.getCars()) {
            if (car.getCarStatus() != CarStatusEnum.REPAIR) {
                    carsBelongingToCarModel++;
                }
        }
        System.out.println("Total cars : " + carsBelongingToCarModel);
        System.out.println("Cars in use : " + conflictRentalReservations.size());
        return carsBelongingToCarModel > conflictRentalReservations.size();
    }

    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<RentalReservation>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }
    
}
