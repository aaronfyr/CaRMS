/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Customer;
import entity.RentalReservation;
import javax.ejb.Local;
import util.exception.CustomerNotFoundException;
import util.exception.RentalReservationAlreadyExistInCustomerException;

/**
 *
 * @author aaronf
 */
@Local
public interface CustomerSessionBeanLocal {

    public Customer retrieveCustomerByCustomerId(Long customerId) throws CustomerNotFoundException;

    public void addRentalReservationToCustomer(Customer customer, RentalReservation rentalReservation);
    
}
