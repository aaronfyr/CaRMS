/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Car;
import entity.CarModel;
import java.util.List;
import javax.ejb.Local;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelNameExistException;
import util.exception.CarModelNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Local
public interface CarModelSessionBeanLocal {

    public Long createNewCarModel(CarModel newCarModel, Long carCategoryId) throws CarCategoryNotFoundException, CarModelNameExistException, UnknownPersistenceException, InputDataValidationException;

    public CarModel retrieveCarModelByCarModelId(Long carModelId) throws CarModelNotFoundException;

    public List<CarModel> retrieveAllCarModels();

    public void updateModel(CarModel carModel, Long carCategoryId) throws CarCategoryNotFoundException, CarModelNotFoundException, InputDataValidationException;

    public Boolean deleteCarModel(Long carModelId) throws CarModelNotFoundException;

    public void addCarToCarModel(CarModel carModel, Car car) throws CarAlreadyRegisteredWithCarModelException;
    
}
