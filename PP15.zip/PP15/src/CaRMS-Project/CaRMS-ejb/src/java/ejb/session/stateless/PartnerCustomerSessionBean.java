/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Partner;
import entity.PartnerCustomer;
import java.util.Set;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.EmployeeNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.PartnerCustomerAlreadyRegisteredWithPartnerException;
import util.exception.PartnerCustomerEmailExistException;
import util.exception.PartnerCustomerNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class PartnerCustomerSessionBean implements PartnerCustomerSessionBeanRemote, PartnerCustomerSessionBeanLocal {

    @EJB(name = "PartnerSessionBeanLocal")
    private PartnerSessionBeanLocal partnerSessionBeanLocal;

    @PersistenceContext(unitName = "CaRMS-ejbPU")
    private EntityManager em;

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    public PartnerCustomerSessionBean() {
        validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.getValidator();
    }
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Long createNewPartnerCustomer(PartnerCustomer newPartnerCustomer, Long partnerId) throws PartnerNotFoundException, PartnerCustomerAlreadyRegisteredWithPartnerException, PartnerCustomerEmailExistException, UnknownPersistenceException, InputDataValidationException {
        Set<ConstraintViolation<PartnerCustomer>> constraintViolations = validator.validate(newPartnerCustomer);

        if (constraintViolations.isEmpty()) {
            try {
                Partner partner = partnerSessionBeanLocal.retrievePartnerByPartnerId(partnerId);
                partnerSessionBeanLocal.addPartnerCustomerToPartner(partner, newPartnerCustomer);
                newPartnerCustomer.setPartner(partner);
                em.persist(newPartnerCustomer);
                em.flush();
                return newPartnerCustomer.getCustomerId();
            } catch (PartnerNotFoundException ex) {
                throw new PartnerNotFoundException("Partner not found for ID: " + partnerId);
            } catch (PartnerCustomerAlreadyRegisteredWithPartnerException ex) {
                throw new PartnerCustomerAlreadyRegisteredWithPartnerException("Partner customer with email: " + newPartnerCustomer.getEmail() + " already registered with partner!");
            } catch (PersistenceException ex) {
                if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                    if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                        throw new PartnerCustomerEmailExistException();
                    } else {
                        throw new UnknownPersistenceException(ex.getMessage());
                    }
                } else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
        } else {
            throw new InputDataValidationException(prepareInputDataValidationErrorsMessage(constraintViolations));
        }
    }
    
    private String prepareInputDataValidationErrorsMessage(Set<ConstraintViolation<PartnerCustomer>> constraintViolations) {
        String msg = "Input data validation error!:";

        for (ConstraintViolation constraintViolation : constraintViolations) {
            msg += "\n\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + "; " + constraintViolation.getMessage();
        }

        return msg;
    }
}
