/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carmsmanagementclient;

import ejb.session.stateless.CarCategorySessionBeanRemote;
import ejb.session.stateless.CarModelSessionBeanRemote;
import ejb.session.stateless.CarSessionBeanRemote;
import ejb.session.stateless.EjbTimerSessionBeanRemote;
import ejb.session.stateless.EmployeeSessionBeanRemote;
import ejb.session.stateless.OutletSessionBeanRemote;
import ejb.session.stateless.RentalRateSessionBeanRemote;
import ejb.session.stateless.RentalReservationSessionBeanRemote;
import ejb.session.stateless.TransitDriverDispatchRecordSessionBeanRemote;
import entity.Employee;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.exception.EmployeeNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InvalidAccessRightException;
import util.exception.InvalidLoginCredentialException;
import util.exception.NoAllocatableCarClientException;
import util.exception.OutletNotFoundException;
import util.exception.RentalReservationNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithOutletException;
import util.exception.UnpaidRentalReservationException;

/**
 *
 * @author aaronf
 */
public class MainApp {

    private final ValidatorFactory validatorFactory;
    private final Validator validator;

    private TransitDriverDispatchRecordSessionBeanRemote transitDriverDispatchRecordSessionBeanRemote;

    private RentalReservationSessionBeanRemote rentalReservationSessionBeanRemote;

    private RentalRateSessionBeanRemote rentalRateSessionBeanRemote;

    private OutletSessionBeanRemote outletSessionBeanRemote;

    private EmployeeSessionBeanRemote employeeSessionBeanRemote;

    private EjbTimerSessionBeanRemote ejbTimerSessionBeanRemote;

    private CarModelSessionBeanRemote carModelSessionBeanRemote;

    private CarCategorySessionBeanRemote carCategorySessionBeanRemote;

    private CarSessionBeanRemote carSessionBeanRemote;

    private Employee currentEmployee;

    private SalesManagementModule salesManagementModule;

    private CustomerServiceModule customerServiceModule;

    public MainApp() {
        this.validatorFactory = Validation.buildDefaultValidatorFactory();
        this.validator = validatorFactory.getValidator();
    }

    public MainApp(TransitDriverDispatchRecordSessionBeanRemote transitDriverDispatchRecordSessionBeanRemote, RentalReservationSessionBeanRemote rentalReservationSessionBeanRemote, RentalRateSessionBeanRemote rentalRateSessionBeanRemote, OutletSessionBeanRemote outletSessionBeanRemote, EmployeeSessionBeanRemote employeeSessionBeanRemote, EjbTimerSessionBeanRemote ejbTimerSessionBeanRemote, CarModelSessionBeanRemote carModelSessionBeanRemote, CarCategorySessionBeanRemote carCategorySessionBeanRemote, CarSessionBeanRemote carSessionBeanRemote) {
        this();

        this.transitDriverDispatchRecordSessionBeanRemote = transitDriverDispatchRecordSessionBeanRemote;
        this.rentalReservationSessionBeanRemote = rentalReservationSessionBeanRemote;
        this.rentalRateSessionBeanRemote = rentalRateSessionBeanRemote;
        this.outletSessionBeanRemote = outletSessionBeanRemote;
        this.employeeSessionBeanRemote = employeeSessionBeanRemote;
        this.ejbTimerSessionBeanRemote = ejbTimerSessionBeanRemote;
        this.carModelSessionBeanRemote = carModelSessionBeanRemote;
        this.carCategorySessionBeanRemote = carCategorySessionBeanRemote;
        this.carSessionBeanRemote = carSessionBeanRemote;
    }

    public void runApp() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("\n*** Welcome to CaRMS Management Client ***\n");
            System.out.println("1: Login");
            System.out.println("2: Exit\n");

            response = 0;

            // remember to change response boundaries when removing evaluation test
            while (response < 1 || response > 2) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    try {
                        doLogin();
                        System.out.println("Login successful\n");
                        menuMain();
                    } catch (EmployeeNotFoundException ex) {
                        System.out.println("\nEmployee not found: " + ex.getMessage());
                    } catch (InvalidLoginCredentialException ex) {
                        System.out.println("Invalid login credential: " + ex.getMessage() + "\n");
                    }
                } else if (response == 2) {
                    break;
                } else {
                    System.out.println("Invalid option, please try again!\n");
                }
            }
            if (response == 2) {
                break;
            }
        }
    }

    private void doLogin() throws EmployeeNotFoundException, InvalidLoginCredentialException {
        Scanner scanner = new Scanner(System.in);
        String username = "";
        String password = "";

        System.out.println("*** CarMS Management Client :: Login ***\n");
        System.out.print("Enter username> ");
        username = scanner.nextLine().trim();
        System.out.print("Enter password> ");
        password = scanner.nextLine().trim();

        if (username.length() > 0 && password.length() > 0) {
            currentEmployee = employeeSessionBeanRemote.employeeLogin(username, password);
        } else {
            throw new InvalidLoginCredentialException("Missing login credential!");
        }
    }

    private void menuMain() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("*** CarMS Reservation Client ***\n");
            System.out.println("You are login as " + currentEmployee.getFirstName() + " " + currentEmployee.getLastName() + " with " + currentEmployee.getEmployeeRole().toString() + " rights\n");
            System.out.println("1: Sales Management");
            System.out.println("2: Customer Service");
            System.out.println("3: Manually Allocate Cars");
            System.out.println("4: Logout\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();

                try {
                    if (response == 1) {
                        salesManagementModule = new SalesManagementModule(currentEmployee,
                                transitDriverDispatchRecordSessionBeanRemote, rentalRateSessionBeanRemote, outletSessionBeanRemote,
                                carModelSessionBeanRemote, carCategorySessionBeanRemote, carSessionBeanRemote);
                        salesManagementModule.menuSalesManagement();
                    } else if (response == 2) {
                        customerServiceModule = new CustomerServiceModule(currentEmployee, rentalReservationSessionBeanRemote);
                        customerServiceModule.menuCustomerService();
                    } else if (response == 3) {
                        try {
                            doAllocateCarReservations();
                        } catch (NoAllocatableCarClientException ex) {
                            System.out.println("There are no allocatable cars for today");
                        } catch (RentalReservationNotFoundException ex) {
                            System.out.println("There are no rental reservations to be allocated");
                        } catch (OutletNotFoundException ex) {
                            System.out.println("Outlet not found");
                        } catch (TransitDriverDispatchRecordAlreadyRegisteredWithOutletException ex) {
                            System.out.println("Transit Driver Dispatch Record is already registered with the outlet");
                        } catch (InputDataValidationException ex) {
                            System.out.println("InputDataValidationException: " + ex.getMessage());;
                        }
                    } else if (response == 4) {
                        break;
                    } else {
                        System.out.println("Invalid option, please try again!\n");
                    }
                } catch (InvalidAccessRightException ex) {
                    System.out.println("\nInvalid option, please try again!: " + ex.getMessage() + "\n");
                } catch (UnpaidRentalReservationException ex) {
                    System.out.println("\nCustomer has not paid for the car rental reservation!");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void doAllocateCarReservations() throws RentalReservationNotFoundException, NoAllocatableCarClientException, OutletNotFoundException, TransitDriverDispatchRecordAlreadyRegisteredWithOutletException, InputDataValidationException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Reservation Client :: Allocating Cars to Reservation of a certain date ***\n");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.print("Enter Date(DD/MM/YYYY)> ");
        String inputDate = scanner.nextLine().trim();
        try {
            Date date = sdf.parse(inputDate);
            System.out.println(ejbTimerSessionBeanRemote);
            ejbTimerSessionBeanRemote.allocateCarsToCurrentDayReservations(date);
            System.out.println("*** CarMS Reservation Client :: Completed Allocation of Cars for reservations on " + inputDate + " ***\n");
        } catch (ParseException ex) {
            System.out.println("Invalid date input!\n");
        }
    }
}
