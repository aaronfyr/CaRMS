/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carmsmanagementclient;

import ejb.session.stateless.CarCategorySessionBeanRemote;
import ejb.session.stateless.CarModelSessionBeanRemote;
import ejb.session.stateless.CarSessionBeanRemote;
import ejb.session.stateless.OutletSessionBeanRemote;
import ejb.session.stateless.RentalRateSessionBeanRemote;
import ejb.session.stateless.TransitDriverDispatchRecordSessionBeanRemote;
import entity.Car;
import entity.CarCategory;
import entity.CarModel;
import entity.Employee;
import entity.Outlet;
import entity.RentalRate;
import entity.TransitDriverDispatchRecord;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.enumeration.CarStatusEnum;
import util.enumeration.EmployeeRoleEnum;
import util.enumeration.RentalRateTypeEnum;
import util.exception.CarAlreadyExistInOutletException;
import util.exception.CarAlreadyRegisteredWithCarModelException;
import util.exception.CarCategoryNotFoundException;
import util.exception.CarModelDisabledException;
import util.exception.CarModelNameExistException;
import util.exception.CarModelNotFoundException;
import util.exception.CarNotFoundException;
import util.exception.DriverNotWorkingInSameOutletException;
import util.exception.EmployeeNotFoundException;
import util.exception.EndDateBeforeStartDateException;
import util.exception.InputDataValidationException;
import util.exception.InsufficientCarsForRentalReservationException;
import util.exception.InvalidAccessRightException;
import util.exception.LicensePlateExistException;
import util.exception.OutletNotFoundException;
import util.exception.RentalRateExistException;
import util.exception.RentalRateExistInCarCategoryException;
import util.exception.RentalRateNotFoundException;
import util.exception.TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException;
import util.exception.TransitDriverDispatchRecordIsNotAssignedException;
import util.exception.TransitDriverDispatchRecordNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
public class SalesManagementModule {

    private TransitDriverDispatchRecordSessionBeanRemote transitDriverDispatchRecordSessionBeanRemote;
    private RentalRateSessionBeanRemote rentalRateSessionBeanRemote;
    private OutletSessionBeanRemote outletSessionBeanRemote;
    private CarModelSessionBeanRemote carModelSessionBeanRemote;
    private CarCategorySessionBeanRemote carCategorySessionBeanRemote;
    private CarSessionBeanRemote carSessionBeanRemote;
    private Employee currentEmployee;

    public SalesManagementModule() {
    }

    public SalesManagementModule(Employee currentEmployee, TransitDriverDispatchRecordSessionBeanRemote transitDriverDispatchRecordSessionBeanRemote,
            RentalRateSessionBeanRemote rentalRateSessionBeanRemote, OutletSessionBeanRemote outletSessionBeanRemote,
            CarModelSessionBeanRemote carModelSessionBeanRemote,
            CarCategorySessionBeanRemote carCategorySessionBeanRemote, CarSessionBeanRemote carSessionBeanRemote) {
        this();

        this.currentEmployee = currentEmployee;
        this.rentalRateSessionBeanRemote = rentalRateSessionBeanRemote;
        this.carModelSessionBeanRemote = carModelSessionBeanRemote;
        this.carSessionBeanRemote = carSessionBeanRemote;
        this.transitDriverDispatchRecordSessionBeanRemote = transitDriverDispatchRecordSessionBeanRemote;
        this.carCategorySessionBeanRemote = carCategorySessionBeanRemote;
        this.outletSessionBeanRemote = outletSessionBeanRemote;
    }

    public void menuSalesManagement() throws InvalidAccessRightException {
        System.out.println("\n*** CarMS Management Client :: Sales Management ***\n");
        if (currentEmployee.getEmployeeRole() == EmployeeRoleEnum.SALES_MANAGER) {
            menuSalesManager();
        } else if (currentEmployee.getEmployeeRole() == EmployeeRoleEnum.OPERATIONS_MANAGER) {
            menuOperationsManager();
        } else {
            throw new InvalidAccessRightException("You don't have sales or operations MANAGER rights to access the sales management module.");
        }
    }

    private void menuSalesManager() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        while (true) {
            System.out.println("\n*** CarMS Management Client :: Sales Manager Menu ***\n");
            System.out.println("1: Create Rental Rate");
            System.out.println("2: View All Rental Rates");
            System.out.println("3: View Rental Rate Details");
            System.out.println("4: Exit\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    doCreateRentalRate();
                } else if (response == 2) {
                    doViewAllRentalRates();
                } else if (response == 3) {
                    doViewRentalRateDetails();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void menuOperationsManager() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        while (true) {
            System.out.println("\n*** CarMS Management Client :: Operations Manager Menu ***\n");
            System.out.println("1: Car Model Menu");
            System.out.println("2: Car Menu");
            System.out.println("3: Transit Menu");
            System.out.println("4: Exit\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    menuCarModel();
                } else if (response == 2) {
                    menuCar();
                } else if (response == 3) {
                    menuTransit();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.println("Invalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void menuCarModel() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        while (true) {
            System.out.println("\n*** CarMS Management Client :: Car Model Menu ***\n");
            System.out.println("1: Create New Car Model");
            System.out.println("2: View All Car Models");
            System.out.println("3: Update Car Model");
            System.out.println("4: Delete Car Model");
            System.out.println("5: Back\n");
            response = 0;

            while (response < 1 || response > 5) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    doCreateNewCarModel();
                } else if (response == 2) {
                    doViewAllCarModels();
                } else if (response == 3) {
                    doUpdateCarModel();
                } else if (response == 4) {
                    doDeleteCarModel();
                } else if (response == 5) {
                    break;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }
            if (response == 5) {
                break;
            }
        }
    }

    private void menuCar() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        while (true) {
            System.out.println("*** CarMS Management Client :: Car Menu ***\n");
            System.out.println("1: Create New Car");
            System.out.println("2: View All Cars");
            System.out.println("3: View Car Details");
            System.out.println("4: Exit\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    doCreateNewCar();
                } else if (response == 2) {
                    doViewAllCars();
                } else if (response == 3) {
                    doViewCarDetails();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void menuTransit() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        while (true) {
            System.out.println("*** CarMS Management Client :: Transit Menu ***\n");
            System.out.println("1: View Transit Driver Dispatch Records for Current Day Reservations");
            System.out.println("2: Assign Transit Driver");
            System.out.println("3: Update Transit As Completed");
            System.out.println("4: Exit\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    doViewTransitDriverDispatchRecordsForCurrentDayReservations();
                } else if (response == 2) {
                    doAssignTransitDriver();
                } else if (response == 3) {
                    doUpdateTransitAsCompleted();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }

    private void doCreateRentalRate() {
        Scanner scanner = new Scanner(System.in);
        RentalRate newRentalRate = new RentalRate();
        System.out.println("*** CarMS Management Client :: Sales Management :: Create Rental Rate***\n");

        while (true) {
            System.out.print("Enter Rental Rate Name> ");
            newRentalRate.setRentalRateName(scanner.nextLine().trim());
            RentalRateTypeEnum rentalRateType = RentalRateTypeEnum.DEFAULT;
            System.out.println("Choose your rental rate type:");
            System.out.println("1: Default");
            System.out.println("2: Peak");
            System.out.println("3: Promo\n");
            int response = 0;

            while (response < 1 || response > 3) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    rentalRateType = RentalRateTypeEnum.DEFAULT;
                } else if (response == 2) {
                    rentalRateType = RentalRateTypeEnum.PEAK;
                } else if (response == 3) {
                    rentalRateType = RentalRateTypeEnum.PROMO;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }

            newRentalRate.setRentalRateType(rentalRateType);

            List<CarCategory> carCategories = carCategorySessionBeanRemote.retrieveAllCarCategories();
            System.out.printf("\n%4s%64s\n", "ID", "Car Category Name");

            for (CarCategory carCategory : carCategories) {
                System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
            }

            System.out.print("Enter Car Category ID > ");
            Long carCategoryId = scanner.nextLong();
            try {
                CarCategory carCategory = carCategorySessionBeanRemote.retrieveCarCategoryByCarCategoryId(carCategoryId);
                newRentalRate.setCarCategory(carCategory);
                System.out.print("Enter rate per day> ");
                newRentalRate.setRatePerDay(scanner.nextBigDecimal());
                scanner.nextLine();
                System.out.print("Enter validity period? (Enter 'Y' to set validity period> ");
                String input = scanner.nextLine().trim();
                if (input.equals("Y")) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    System.out.print("Enter start date (DD/MM/YYYY HH:MM)> ");
                    Date startDate = sdf.parse(scanner.nextLine().trim());
                    System.out.print("Enter end date (DD/MM/YYYY HH:MM)> ");
                    Date endDate = sdf.parse(scanner.nextLine().trim());
                    if (endDate.before(startDate)) {
                        throw new EndDateBeforeStartDateException();
                    }
                    newRentalRate.setStartDate(startDate);
                    newRentalRate.setEndDate(endDate);
                } else {
                    System.out.println("Validity period not entered!");
                }
                Long rentalRateId = rentalRateSessionBeanRemote.createNewRentalRate(newRentalRate, carCategoryId);
                System.out.println("Rental Rate ID: " + rentalRateId + " successfully created!");
                break;
            } catch (ParseException ex) {
                System.out.println("Invalid Date/Time Format!");
            } catch (CarCategoryNotFoundException ex) {
                System.out.println("No such Car Category of ID: " + carCategoryId);
            } catch (EndDateBeforeStartDateException ex) {
                System.out.println("End date is before start date!");
            } catch (RentalRateExistInCarCategoryException ex) {
                System.out.println("Rental rate with name: " + newRentalRate.getRentalRateName() + " already exists in the car category!");
            } catch (RentalRateExistException ex) {
                System.out.println("Rental rate with name: " + newRentalRate.getRentalRateName() + " already exists!");
            } catch (UnknownPersistenceException ex) {
                System.out.println("UnknownPersistenceException when creating new Rental Rate");
            } catch (InputDataValidationException ex) {
                System.out.println("Invalid fields for the rental rate");
            }
            System.out.print("Press any key to continue...> ");
            scanner.nextLine();
        }
    }

    private void doViewAllRentalRates() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** CarMS Management Client :: Sales Management :: View All Rental Rates***\n");
        List<RentalRate> rentalRates = rentalRateSessionBeanRemote.retrieveAllRentalRates();
        System.out.printf("%4s%16s%32s%32s%16s%16s%20s%20s\n", "ID", "Rental Rate Name", "Rental Rate Type", "Car Category", "Rate Per Day", "Is Enabled?", "Start Period", "End Period");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        for (RentalRate rentalRate : rentalRates) {
            String startDate = "";
            if (rentalRate.getStartDate() != null) {
                startDate = sdf.format(rentalRate.getStartDate());
            }
            String endDate = "";
            if (rentalRate.getEndDate() != null) {
                endDate = sdf.format(rentalRate.getEndDate());
            }
            System.out.printf("%4s%16s%32s%32s%16s%16s%20s%20s\n", rentalRate.getRentalRateId(), rentalRate.getRentalRateType(),
                    rentalRate.getRentalRateName(), rentalRate.getCarCategory().getCarCategoryName(),
                    rentalRate.getRatePerDay(), rentalRate.getIsEnabled().toString(), startDate, endDate);
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doViewRentalRateDetails() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        System.out.println("\n*** CarMS Management Client :: Sales Management :: View Rental Rate Details***\n");
        System.out.print("Enter Rental Rate ID> ");
        Long rentalRateId = scanner.nextLong();
        try {
            RentalRate rentalRate = rentalRateSessionBeanRemote.retrieveRentalRateByRentalRateId(rentalRateId);

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            String startDate = "";
            if (rentalRate.getStartDate() != null) {
                startDate = sdf.format(rentalRate.getStartDate());
            }
            String endDate = "";
            if (rentalRate.getEndDate() != null) {
                endDate = sdf.format(rentalRate.getEndDate());
            }
            System.out.printf("%4s%32s%32s%16s%16s%20s%20s\n", "ID", "Rental Rate Name", "Rental Rate Type", "Car Category", "Rate Per Day", "Is Enabled?", "Start Period", "End Period");
            System.out.printf("%4s%32s%32s%16s%16s%20s%20s\n", rentalRate.getRentalRateId(), rentalRate.getRentalRateType(),
                    rentalRate.getRentalRateName(), rentalRate.getCarCategory().getCarCategoryName(),
                    rentalRate.getRatePerDay(), rentalRate.getIsEnabled().toString(), startDate, endDate);
            System.out.println("------------------------");
            if (rentalRate.getIsEnabled()) {
                System.out.println("1: Update Rental Rate");
                System.out.println("2: Delete Rental Rate");
                System.out.println("3: Back\n");

                while (response < 1 || response > 3) {
                    System.out.print("> ");
                    response = scanner.nextInt();
                    if (response == 1) {
                        doUpdateRentalRate(rentalRate);
                    } else if (response == 2) {
                        doDeleteRentalRate(rentalRate);
                    } else if (response == 3) {
                        break;
                    } else {
                        System.out.println("Invalid option, please try again!\n");
                    }
                }

            } else {
                System.out.println("1: Delete Rental Rate");
                System.out.println("2: Back\n");

                while (response < 1 || response > 2) {
                    System.out.print("> ");
                    response = scanner.nextInt();
                    if (response == 1) {
                        doDeleteRentalRate(rentalRate);
                    } else if (response == 2) {
                        break;
                    } else {
                        System.out.println("Invalid option, please try again!\n");
                    }
                }
            }
        } catch (RentalRateNotFoundException ex) {
            System.out.println("Rental Rate not found for ID: " + rentalRateId);
        }
        scanner.nextLine();
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doUpdateRentalRate(RentalRate rentalRate) {
        Scanner scanner = new Scanner(System.in);
        RentalRate newRentalRate = new RentalRate();
        System.out.println("*** CarMS Management Client :: Sales Management :: Update Rental Rate***\n");
        Long rentalRateId = rentalRate.getRentalRateId();
        newRentalRate.setRentalRateId(rentalRateId);
        System.out.print("Enter new Rental Rate Name> ");
        newRentalRate.setRentalRateName(scanner.nextLine().trim());
        RentalRateTypeEnum rentalRateType = RentalRateTypeEnum.DEFAULT;

        while (true) {
            System.out.println("Choose your rental rate type:");
            System.out.println("1: Default");
            System.out.println("2: Peak");
            System.out.println("3: Promo\n");
            int response = 0;

            while (response < 1 || response > 3) {
                System.out.print("> ");
                response = scanner.nextInt();
                if (response == 1) {
                    rentalRateType = RentalRateTypeEnum.DEFAULT;
                } else if (response == 2) {
                    rentalRateType = RentalRateTypeEnum.PEAK;
                } else if (response == 3) {
                    rentalRateType = RentalRateTypeEnum.PROMO;
                } else {
                    System.out.print("Invalid option, please try again!\n");
                }
            }

            newRentalRate.setRentalRateType(rentalRateType);

            List<CarCategory> carCategories = carCategorySessionBeanRemote.retrieveAllCarCategories();
            System.out.printf("%4s%64s\n", "ID", "Car Category Name");

            for (CarCategory carCategory : carCategories) {
                System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
            }
            System.out.print("Enter Car Category ID > ");
            Long carCategoryId = scanner.nextLong();
            try {
                CarCategory carCategory = carCategorySessionBeanRemote.retrieveCarCategoryByCarCategoryId(carCategoryId);
                newRentalRate.setCarCategory(carCategory);
                System.out.print("Enter rate per day> ");
                newRentalRate.setRatePerDay(scanner.nextBigDecimal());
                scanner.nextLine();
                System.out.print("Enter validity period? (Enter 'Y' to set validity period> ");
                String input = scanner.nextLine().trim();
                if (input.equals("Y")) {
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    System.out.print("Enter start date (DD/MM/YYYY HH:MM)> ");
                    Date startDate = sdf.parse(scanner.nextLine().trim());
                    newRentalRate.setStartDate(startDate);
                    System.out.print("Enter end date (DD/MM/YYYY HH:MM)> ");
                    Date endDate = sdf.parse(scanner.nextLine().trim());
                    newRentalRate.setEndDate(endDate);
                } else {
                    System.out.println("Validity period not entered!");
                }
                rentalRateSessionBeanRemote.updateRentalRate(newRentalRate);
                System.out.println("Rental Rate ID: " + rentalRateId + " updated!");
                break;
            } catch (ParseException ex) {
                System.out.println("Invalid Date/Time Format!");
            } catch (CarCategoryNotFoundException ex) {
                System.out.println("No such Car Category of ID: " + carCategoryId);
            } catch (InputDataValidationException ex) {
                System.out.println("Rental Rate name already exists in the database! " + newRentalRate.getRentalRateName());
            } catch (RentalRateNotFoundException ex) {
                System.out.println("Rental Rate not found for ID: " + newRentalRate.getRentalRateId());
            }
        }
    }

    private void doDeleteRentalRate(RentalRate rentalRate) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: Delete Rental Rate***\n");
        Long rentalRateId = rentalRate.getRentalRateId();
        try {
            Boolean isPhysicalDeletion = rentalRateSessionBeanRemote.deleteRentalRate(rentalRateId);
            if (isPhysicalDeletion) {
                System.out.println("Rental Rate ID: " + rentalRateId + " successfully deleted!");
            } else {
                System.out.println("Rental Rate ID: " + rentalRateId + " cannot be deleted and has been marked as disabled due to ongoing reservations!");
            }
        } catch (RentalRateNotFoundException ex) {
            System.out.println("Rental Rate not found for ID: " + rentalRateId);
        }

    }

    private void doCreateNewCarModel() {
        Scanner scanner = new Scanner(System.in);
        CarModel newCarModel = new CarModel();
        System.out.println("*** CarMS Management Client :: Sales Management :: Create new Car Model***\n");
        System.out.print("Enter Make name> ");
        newCarModel.setMakeName(scanner.nextLine().trim());
        System.out.print("Enter Model name> ");
        newCarModel.setModelName(scanner.nextLine().trim());
        List<CarCategory> carCategories = carCategorySessionBeanRemote.retrieveAllCarCategories();
        System.out.printf("%4s%64s\n", "ID", "Car Category Name");

        for (CarCategory carCategory : carCategories) {
            System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
        }
        System.out.print("Enter Car Category ID> ");
        Long carCategoryId = scanner.nextLong();
        scanner.nextLine();
        try {
            Long carModelId = carModelSessionBeanRemote.createNewCarModel(newCarModel, carCategoryId);
            System.out.println("New Car Model successfully created with ID " + carModelId);
        } catch (CarCategoryNotFoundException ex) {
            System.out.println("Car Category ID: " + carCategoryId + " not found!");
        } catch (CarModelNameExistException ex) {
            System.out.println("Car model name already exists in the database! " + newCarModel.getModelName());
        } catch (InputDataValidationException ex) {
            System.out.println("Input Data Validation Exception");
        } catch (UnknownPersistenceException ex) {
            System.out.println("Unknown persistence exception");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doViewAllCarModels() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: View All Car Models***\n");
        List<CarModel> carModels = carModelSessionBeanRemote.retrieveAllCarModels();
        System.out.printf("%4s%32s%32s%32s%16s\n", "ID", "Car Category", "Make Name", "Model Name", "Is Enabled?");
        for (CarModel carModel : carModels) {
            System.out.printf("%4s%32s%32s%32s%16s\n", carModel.getCarModelId(), carModel.getCarCategory().getCarCategoryName(),
                    carModel.getMakeName(), carModel.getModelName(), carModel.getIsEnabled().toString());
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doUpdateCarModel() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: Update Car Model***\n");
        CarModel newCarModel = new CarModel();
        System.out.print("Enter Car Model ID> ");
        Long carModelId = scanner.nextLong();
        scanner.nextLine();
        newCarModel.setCarModelId(carModelId);
        System.out.print("Enter new Make name> ");
        newCarModel.setMakeName(scanner.nextLine().trim());
        System.out.print("Enter new Model name> ");
        newCarModel.setModelName(scanner.nextLine().trim());

        List<CarCategory> carCategories = carCategorySessionBeanRemote.retrieveAllCarCategories();
        System.out.printf("%4s%64s\n", "ID", "Car Category Name");

        for (CarCategory carCategory : carCategories) {
            System.out.printf("%4s%64s\n", carCategory.getCarCategoryId(), carCategory.getCarCategoryName());
        }

        System.out.print("Enter new Car Category ID> ");
        Long carCategoryId = scanner.nextLong();
        scanner.nextLine();
        try {
            carModelSessionBeanRemote.updateModel(newCarModel, carCategoryId);
            System.out.println("Model ID: " + newCarModel.getCarModelId() + " successfully updated!");
        } catch (CarModelNotFoundException ex) {
            System.out.println("Car Model not found for ID: " + carModelId);
        } catch (InputDataValidationException ex) {
            System.out.println("Model name: " + newCarModel.getModelName() + " already exists in the database!");
        } catch (CarCategoryNotFoundException ex) {
            System.out.println("Car Category not found for ID: " + carCategoryId);
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doDeleteCarModel() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: Delete Model***\n");
        System.out.print("Enter Car Model ID> ");
        Long carModelId = scanner.nextLong();
        scanner.nextLine();
        try {
            Boolean isPhysicalDeletion = carModelSessionBeanRemote.deleteCarModel(carModelId);
            if (isPhysicalDeletion) {
                System.out.println("Car Model ID: " + carModelId + " successfully deleted!");
            } else {
                System.out.println("Car Model ID: " + carModelId + " cannot be deleted and has been marked as disabled due to ongoing reservations!");
            }
        } catch (CarModelNotFoundException ex) {
            System.out.print("Car Model not found for ID: " + carModelId + "\n");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doCreateNewCar() {
        Scanner scanner = new Scanner(System.in);
        Car newCar = new Car();
        System.out.println("*** CarMS Management Client :: Sales Management :: Create new Car ***\n");
        System.out.print("Enter license plate number> ");
        newCar.setLicensePlate(scanner.nextLine().trim());
        System.out.print("Enter colour> ");
        newCar.setColour(scanner.nextLine().trim());

        List<CarModel> carModels = carModelSessionBeanRemote.retrieveAllCarModels();
        System.out.printf("%4s%32s%32s%32s%16s\n", "ID", "Car Category", "Make Name", "Model Name", "Is Enabled?");

        for (CarModel carModel : carModels) {
            System.out.printf("%4s%32s%32s%32s%16s\n", carModel.getCarModelId(), carModel.getCarCategory().getCarCategoryName(),
                    carModel.getMakeName(), carModel.getModelName(), carModel.getIsEnabled().toString());
        }

        System.out.print("Enter Car Model ID> ");
        Long carModelId = scanner.nextLong();

        List<Outlet> outlets = outletSessionBeanRemote.retrieveAllOutlets();
        System.out.printf("%4s%64s%20s%20s\n", "ID", "Outlet Name", "Opening Hour", "Closing Hour");

        SimpleDateFormat operatingHours = new SimpleDateFormat("HH:mm");

        for (Outlet outlet : outlets) {
            String openingHours = "";
            String closingHours = "";

            if (outlet.getOpeningHours() != null) {
                openingHours = operatingHours.format(outlet.getOpeningHours());
            }

            if (outlet.getClosingHours() != null) {
                closingHours = operatingHours.format(outlet.getClosingHours());
            }
            System.out.printf("%4s%64s%20s%20s\n", outlet.getOutletId(), outlet.getOutletName(),
                    openingHours, closingHours);
        }

        System.out.print("Enter Outlet ID> ");
        Long outletId = scanner.nextLong();
        scanner.nextLine();
        try {
            Long carId = carSessionBeanRemote.createNewCar(newCar, outletId, carModelId);
            System.out.println("New Car successfully created with ID " + carId);
        } catch (CarModelNotFoundException ex) {
            System.out.println("Car Model ID: " + carModelId + " not found!");
        } catch (OutletNotFoundException ex) {
            System.out.println("Outlet ID: " + outletId + " not found!");
        } catch (LicensePlateExistException ex) {
            System.out.println("License Plate : + " + newCar.getLicensePlate() + " already exists!");
        } catch (CarModelDisabledException ex) {
            System.out.println("Car Model is disabled and new car record should not be created with the disabled model!");
        } catch (CarAlreadyExistInOutletException ex) {
            System.out.println("Car already exist in the outlet!");
        } catch (CarAlreadyRegisteredWithCarModelException ex) {
            System.out.println("Car has already registered with the car model!");
        } catch (UnknownPersistenceException ex) {
            System.out.println("Unknown persistence exception");
        } catch (InputDataValidationException ex) {
            System.out.println("Input data validation exception");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doViewAllCars() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: View All Cars***\n");
        List<Car> cars = carSessionBeanRemote.retrieveAllCars();
        System.out.printf("%4s%32s%16s%16s%26s%16s%16s\n", "ID", "Car Category", "Make", "Model", "License Plate Number", "Car Status", "Is Enabled?");
        for (Car car : cars) {
            System.out.printf("%4s%32s%16s%16s%26s%16s%16s\n", car.getCarId(),
                    car.getCarModel().getCarCategory().getCarCategoryName(),
                    car.getCarModel().getMakeName(), car.getCarModel().getModelName(),
                    car.getLicensePlate(), car.getCarStatus(), car.getIsEnabled().toString());
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doViewCarDetails() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        System.out.println("*** CarMS Management Client :: Sales Management :: View Car Details***\n");
        System.out.print("Enter Car ID> ");
        Long carId = scanner.nextLong();
        scanner.nextLine();
        try {
            Car car = carSessionBeanRemote.retrieveCarByCarId(carId);
            System.out.printf("%4s%32s%16s%16s%26s%16s%16s\n", "ID", "Car Category", "Make", "Model", "License Plate Number", "Car Status", "Is Enabled?");
            System.out.printf("%4s%32s%16s%16s%26s%16s%16s\n", car.getCarId(),
                    car.getCarModel().getCarCategory().getCarCategoryName(),
                    car.getCarModel().getMakeName(), car.getCarModel().getModelName(),
                    car.getLicensePlate(), car.getCarStatus(), car.getIsEnabled().toString());
            System.out.println("------------------------");
            if (car.getIsEnabled()) {
                System.out.println("1: Update Car");
                System.out.println("2: Delete Car");
                System.out.println("3: Back\n");

                while (response < 1 || response > 3) {
                    System.out.print("> ");
                    response = scanner.nextInt();
                    if (response == 1) {
                        doUpdateCar(car);
                    } else if (response == 2) {
                        doDeleteCar(car);
                    } else if (response == 3) {
                        break;
                    } else {
                        System.out.println("Invalid option, please try again!\n");
                    }
                }

            } else {
                System.out.println("1: Delete Car");
                System.out.println("2: Back\n");

                while (response < 1 || response > 2) {
                    System.out.print("> ");
                    response = scanner.nextInt();
                    if (response == 1) {
                        doDeleteCar(car);
                    } else if (response == 2) {
                        break;
                    } else {
                        System.out.println("Invalid option, please try again!\n");
                    }
                }
            }
        } catch (CarNotFoundException ex) {
            System.out.println("Car not found for ID: " + carId);
        }
        scanner.nextLine();
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doUpdateCar(Car car) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: Update Car***\n");
        Car newCar = new Car();
        Long carId = car.getCarId();
        newCar.setCarId(carId);
        System.out.print("Enter new license plate> ");
        newCar.setLicensePlate(scanner.nextLine().trim());
        System.out.print("Enter new colour> ");
        newCar.setColour(scanner.nextLine().trim());
        try {
            carSessionBeanRemote.updateCar(newCar);
            System.out.println("Car ID: " + car.getCarId() + " successfully updated!\n");
        } catch (CarNotFoundException ex) {
            System.out.println("Car not found for ID: " + carId);
        } catch (InputDataValidationException ex) {
            System.out.println("License plate: " + newCar.getLicensePlate() + " already exists in the database!");
        }
    }

    private void doDeleteCar(Car car) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: Delete Car***\n");
        Long carId = car.getCarId();
        try {
            CarStatusEnum carStatus = car.getCarStatus();
            Boolean isPhysicalDeletion = carSessionBeanRemote.deleteCar(carId);
            if (isPhysicalDeletion) {
                System.out.println("Car ID: " + carId + " successfully deleted!");
            } else {
                System.out.println("Car ID: " + carId + " cannot be deleted and has been marked as disabled due to being used!");
            }
        } catch (CarNotFoundException ex) {
            System.out.println("Car not found for ID: " + carId);
        } catch (InsufficientCarsForRentalReservationException ex) {
            System.out.println("Car cannot be deleted for ID: " + carId + " " + ex.getMessage());
        }
    }

    private void doViewTransitDriverDispatchRecordsForCurrentDayReservations() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CarMS Management Client :: Sales Management :: View Transit Driver Dispatch Records for Current Day Reservations***\n");
        System.out.print("Enter Date (DD/MM/YYYY) > ");
        String inputDate = scanner.nextLine().trim();
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date date = inputFormat.parse(inputDate);
            System.out.println("Dispatch records for " + currentEmployee.getOutlet().getOutletName() + " on " + inputDate + "\n");
            List<TransitDriverDispatchRecord> transitDriverDispatchRecords = transitDriverDispatchRecordSessionBeanRemote.
                    retrieveTransitDriverDispatchRecordByOutletId(date, currentEmployee.getOutlet().getOutletId());
            System.out.printf("%12s%32s%32s%20s%20s\n",
                    "Record ID", "Destination Outlet", "Driver", "Status", "Transit Time");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            for (TransitDriverDispatchRecord transitDriverDispatchRecord : transitDriverDispatchRecords) {
                String isCompleted = "Not Completed";
                if (transitDriverDispatchRecord.getIsCompleted()) {
                    isCompleted = "Completed";
                }
                String dispatchDriverName = "Unassigned";
                if (transitDriverDispatchRecord.getTransitDispatchDriver() != null) {
                    dispatchDriverName = transitDriverDispatchRecord.getTransitDispatchDriver().getFirstName() + transitDriverDispatchRecord.getTransitDispatchDriver().getLastName();
                }
                String transitDate = sdf.format(transitDriverDispatchRecord.getTransitDate());
                System.out.printf("%12s%32s%32s%20s%20s\n",
                        transitDriverDispatchRecord.getTransitDriverDispatchRecordId(),
                        transitDriverDispatchRecord.getDestinationOutlet().getOutletName(),
                        dispatchDriverName, isCompleted, transitDate);
            }
        } catch (ParseException ex) {
            System.out.println("Invalid date input!");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doAssignTransitDriver() {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("*** CarMS Management Client :: Sales Management :: Assign Transit Driver***\n");
            System.out.print("Enter Date (DD/MM/YYYY) > ");
            String inputDate = scanner.nextLine().trim();
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date date = inputFormat.parse(inputDate);
            System.out.println("\nDispatch records for " + currentEmployee.getOutlet().getOutletName() + " on " + inputDate + "\n");
            List<TransitDriverDispatchRecord> transitDriverDispatchRecords = transitDriverDispatchRecordSessionBeanRemote.
                    retrieveTransitDriverDispatchRecordByOutletId(date, currentEmployee.getOutlet().getOutletId());
            if (transitDriverDispatchRecords.isEmpty()) {
                System.out.println("No dispatch records to be assigned!");
            } else {
                System.out.printf("%12s%32s%32s%20s%20s\n",
                        "Record ID", "Destination Outlet", "Driver", "Status", "Transit Time");
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                for (TransitDriverDispatchRecord transitDriverDispatchRecord : transitDriverDispatchRecords) {
                    String isCompleted = "Not Completed";
                    if (transitDriverDispatchRecord.getIsCompleted()) {
                        isCompleted = "Completed";
                    }
                    String dispatchDriverName = "Unassigned";
                    if (transitDriverDispatchRecord.getTransitDispatchDriver() != null) {
                        dispatchDriverName = transitDriverDispatchRecord.getTransitDispatchDriver().getFirstName() + transitDriverDispatchRecord.getTransitDispatchDriver().getLastName();
                    }
                    String transitDate = sdf.format(transitDriverDispatchRecord.getTransitDate());
                    System.out.printf("%12s%32s%32s%20s%20s\n",
                            transitDriverDispatchRecord.getTransitDriverDispatchRecordId(),
                            transitDriverDispatchRecord.getDestinationOutlet().getOutletName(),
                            dispatchDriverName, isCompleted, transitDate);
                }
                System.out.print("Enter Transit Driver Dispatch Record ID> ");
                Long transitDriverDispatchRecordId = scanner.nextLong();
                System.out.print("Enter Dispatch Driver ID> ");
                Long dispatchDriverId = scanner.nextLong();
                scanner.nextLine();
                transitDriverDispatchRecordSessionBeanRemote.assignDriver(dispatchDriverId, transitDriverDispatchRecordId);
                System.out.println("Successfully assigned transit driver " + dispatchDriverId + " to a dispatch record " + transitDriverDispatchRecordId);
            }
        } catch (DriverNotWorkingInSameOutletException ex) {
            System.out.println("Driver is not working in the same outlet as the car is currently at!");
        } catch (EmployeeNotFoundException ex) {
            System.out.println("Employee not found!");
        } catch (TransitDriverDispatchRecordNotFoundException ex) {
            System.out.println("Transit driver dispatch record not found! Please enter the correct Transit Driver Dispatch Record ID!");
        } catch (TransitDriverDispatchRecordAlreadyRegisteredWithEmployeeException ex) {
            System.out.println("Employee has already taken up this transit driver dispatch!");
        } catch (ParseException ex) {
            System.out.println("Invalid Date Format");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }

    private void doUpdateTransitAsCompleted() {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("*** CarMS Management Client :: Sales Management :: Update Transit As Completed***\n");
            System.out.print("Enter Date (DD/MM/YYYY) > ");
            String inputDate = scanner.nextLine().trim();
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date date = inputFormat.parse(inputDate);
            System.out.println("\nDispatch records for " + currentEmployee.getOutlet().getOutletName() + " on " + inputDate + "\n");
            List<TransitDriverDispatchRecord> transitDriverDispatchRecords = transitDriverDispatchRecordSessionBeanRemote.
                    retrieveTransitDriverDispatchRecordByOutletId(date, currentEmployee.getOutlet().getOutletId());
            if (transitDriverDispatchRecords.isEmpty()) {
                System.out.println("No dispatch records to be completed!");
            } else {
                System.out.printf("%12s%32s%32s%20s%20s\n",
                        "Record ID", "Destination Outlet", "Driver", "Status", "Transit Time");
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                for (TransitDriverDispatchRecord transitDriverDispatchRecord : transitDriverDispatchRecords) {
                    String isCompleted = "Not Completed";
                    if (transitDriverDispatchRecord.getIsCompleted()) {
                        isCompleted = "Completed";
                    }
                    String dispatchDriverName = "Unassigned";
                    if (transitDriverDispatchRecord.getTransitDispatchDriver() != null) {
                        dispatchDriverName = transitDriverDispatchRecord.getTransitDispatchDriver().getFirstName() + transitDriverDispatchRecord.getTransitDispatchDriver().getLastName();
                    }
                    String transitDate = sdf.format(transitDriverDispatchRecord.getTransitDate());
                    System.out.printf("%12s%32s%32s%20s%20s\n",
                            transitDriverDispatchRecord.getTransitDriverDispatchRecordId(),
                            transitDriverDispatchRecord.getDestinationOutlet().getOutletName(),
                            dispatchDriverName, isCompleted, transitDate);
                }
                System.out.print("Enter Transit Dispatch Record ID> ");
                Long transitDriverDispatchRecordId = scanner.nextLong();
                scanner.nextLine();
                transitDriverDispatchRecordSessionBeanRemote.updateTransitAsCompleted(transitDriverDispatchRecordId);
                System.out.println("Successfully updated transit record id: " + transitDriverDispatchRecordId + " as completed!");
            }
        } catch (TransitDriverDispatchRecordNotFoundException ex) {
            System.out.println("Transit driver dispatch record not found!");
        } catch (TransitDriverDispatchRecordIsNotAssignedException ex) {
            System.out.println(ex.getMessage());
        } catch (ParseException ex) {
            System.out.println("Invalid date format!");
        }
        System.out.print("Press any key to continue...> ");
        scanner.nextLine();
    }
}
